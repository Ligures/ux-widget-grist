# Guide d'administration — UX widget grist

<img src="aia.png" alt="AIA" width="40" align="left" /> **AIA — Assisté par l'intelligence artificielle.** Ce widget et sa documentation ont été réalisés avec l'assistance d'une IA, sous la direction et avec la validation de leur auteur. Icône : [Martine Peters](https://mpeters.uqo.ca/utilisation-transparente-de-lintelligence-artificielle/), CC BY-NC-SA 4.0.
<br clear="left" />

Ce guide s'adresse aux **administrateurs**, qui composent les pages. Il n'est affiché dans l'aide qu'aux personnes qui peuvent configurer le widget. Pour l'utilisation courante, voir l'onglet **Guide** ; pour l'installation et le fonctionnement technique, l'onglet **À propos** (README).

---

## Sommaire

1. [Composer une page](#1-composer-une-page)
   - [Ouvrir la configuration](#ouvrir-la-configuration)
   - [Choisir et régler les vues](#choisir-et-régler-les-vues)
   - [Disposition](#disposition)
   - [Filtre rapide](#filtre-rapide)
   - [Listes de sélection](#listes-de-sélection)
   - [Cartes : réglages](#cartes--réglages)
   - [Graphiques : couleurs](#graphiques--couleurs)
   - [Bloc-notes](#bloc-notes)
   - [Message d'accueil](#message-daccueil)
   - [Maintenance et accès fermé](#maintenance-et-accès-fermé)
   - [Menu de navigation](#menu-de-navigation)
   - [Apparence](#apparence)
   - [Enregistrer](#enregistrer)
   - [Distancier routier](#distancier-routier)
2. [Questions fréquentes](#2-questions-fréquentes)

---

## 1. Composer une page

Le bouton **⚙ Configurer** n'apparaît qu'aux administrateurs : les personnes qui lisent au moins une ligne de la table `W_Admin`. Eux seuls voient aussi, en bas de chaque page, la ligne **Vues natives** : un lien vers chaque page Grist qui contient les vues affichées (leurs titres en infobulle ; clic du milieu : nouvel onglet).

### Ouvrir la configuration

Le bouton **⚙ Configurer** ouvre un panneau sur la moitié droite de l'écran :
- l'**aperçu de la disposition** reste affiché en haut ;
- chaque option est expliquée au **survol** de son libellé (soulignement en pointillés) ;
- rien n'est appliqué avant **Enregistrer**, et **Annuler** ferme le panneau sans rien changer.

**Général**
- **Page réglée** : la page dont on règle la composition. Par défaut, c'est la page affichée (marquée « — affichée »). On peut en choisir une autre : l'affichage du widget ne change pas.
- **＋ Nouvelle page** : crée une page vide, sans toucher à la page affichée. **Dupliquer** crée une nouvelle page à partir de celle en cours de réglage (mêmes blocs, mêmes réglages).
- Quand la page réglée n'est pas la page affichée, un encadré jaune le signale. L'enregistrement range alors la page dans `W_Composition` sans changer l'affichage. Deux options :
  - **L'afficher dans ce widget après l'enregistrement** : le widget affichera désormais cette page ;
  - **L'ajouter au menu de navigation** (mode « Changer de page dans le widget ») : un lien vers la page est ajouté au menu commun.
- **Nom de la page** : identifie la page dans `W_Composition`. Si le nom existe déjà, le widget demande confirmation avant de remplacer l'autre page. Un nom ne peut pas commencer par « _ » (réservé).
- **Liens vers des formulaires Grist** (facultatif) : « + Ajouter un lien vers un formulaire », puis un libellé (ex. « Signaler un problème »), un commentaire au survol facultatif (affiché dans une infobulle sur le bouton) et l'adresse du formulaire. Pour obtenir l'adresse : dans Grist, ouvrir la vue Formulaire, cliquer sur « Publier », puis « Partager » et copier le lien. Chaque lien devient un bouton dans l'en-tête de la page, à gauche du menu ☰. Le formulaire s'ouvre dans une fenêtre au-dessus de la page, ou dans un nouvel onglet si la case « nouvel onglet » est cochée. La fenêtre se ferme avec ✕, Échap ou un clic à côté, et toute seule après l'envoi du formulaire ; la page est alors rechargée pour montrer la nouvelle réponse. La fermeture automatique fonctionne si l'utilisateur peut lire la table du formulaire ; sinon, réglez dans Grist une redirection après l'envoi (n'importe quelle adresse). Le bouton ↗ de la fenêtre ouvre le formulaire dans un nouvel onglet. Seules les adresses en https sont acceptées.
- **Titre affiché** : laissé vide, il libère de la place en haut de page.

### Choisir et régler les vues

1. **Vues disponibles** : choisir une page Grist, puis cocher ses vues. On peut combiner des vues de plusieurs pages.
2. **Vues retenues** : chaque vue cochée devient un bloc.
   - Les flèches ↑ ↓ règlent l'ordre ; ✕ retire le bloc (la vue Grist n'est pas supprimée).
   - **+ Ajouter un séparateur** (0.9.7.0) : titre de partie, avec une ligne de commentaire facultative et une largeur (6 : toute la largeur). Placez-le avec ↑ ↓ devant les vues qu'il annonce. Il commence toujours une nouvelle rangée, et il est masqué quand aucune vue n'est affichée entre lui et le séparateur suivant (droits, blocs vides). Avec « Combler automatiquement les espaces libres » (3. Disposition), une vue peut remonter dans un espace libre au-dessus d'un séparateur : décochez l'option si c'est gênant.
   - Les réglages de chaque bloc sont **repliés par défaut** : restent visibles son titre, ses flèches, sa largeur, sa colonne et son nombre de lignes. ▸ / ▾ déplie ou replie un bloc ; **Tout déplier** et **Tout replier** agissent sur tous. Une vue que l'on vient d'ajouter s'ouvre dépliée.
   - Déplié, un bloc présente ses réglages dans des encadrés titrés, toujours dans le même ordre :
     - **Affichage**, commun à toutes les vues : niveau du titre, sous-titre, taille, état à l'ouverture, « À la ligne », « Figer à l'écran », « Seulement si la page a d'autres données », « Liste de sélection » ;
     - puis les encadrés propres au type de vue, s'il y a lieu : **Tableau**, **Fiches**, **Édition**, **Liste de sélection**, **Filtre rapide**, et pour les cartes **Points**, **Contour des points**, **QPV**, **Zones sous les points**.
   - Chaque bloc a ses réglages :

| Réglage | Effet |
|---|---|
| Largeur, Colonne, Hauteur (lignes) | Place du bloc dans la grille de 6 colonnes |
| Titre | Niveau du titre du bloc : **H3** (habituel) ou **H2** (plus grand, pour les blocs principaux) |
| Sous-titre | Case « afficher la description » : la description du widget saisie dans Grist s'affiche en gris sous le titre, à la place du ⓘ |
| Taille | Hauteur maximale ; au-delà, le contenu défile dans le bloc |
| À l'ouverture | Bloc replié ou déplié à l'arrivée sur la page |
| À la ligne | Le bloc commence une nouvelle rangée |
| Figer à l'écran | Le bloc reste visible pendant le défilement d'un bloc voisin. Plusieurs blocs figés d'une même colonne s'empilent. Un bloc déplié trop haut défile à l'intérieur de son cadre ; un bloc dont même l'en-tête ne tient plus défile normalement, sous les autres |
| Seulement si la page a d'autres données | Quand le bloc n'a aucune ligne (par exemple un tableau de saisie encore vide, avec « + Ajouter une ligne »), il n'apparaît que si au moins un autre bloc de la page en a. Une page entièrement vide ne le montre pas |
| Édition des champs | Autorise la modification des valeurs (droits Grist respectés) |
| Ajout et suppression de lignes | Tableaux et listes de fiches, avec « Édition des champs » : boutons « + Ajouter une ligne » et « − Supprimer la ligne » en bas du bloc. Si le bloc est lié à une sélection, la nouvelle ligne y est rattachée. Le bloc reste affiché même vide. Droits de création et de suppression Grist requis : sinon l'action est refusée avec un message |
| Masquer les noms des champs | Fiches et listes de fiches : seules les valeurs sont affichées ; le nom du champ apparaît au survol de la valeur |
| Afficher les champs vides | Pour les fiches de ce bloc |
| Largeur des colonnes | Ajustées (sans ascenseur horizontal), celles de Grist, ou automatiques |
| Afficher toutes les fiches | Une vue fiche affichée en liste |
| Liste de sélection | Le bloc devient une liste déroulante dans l'en-tête |
| **Filtre rapide**, **Filtre à l'ouverture** | Voir ci-dessous |

### Disposition

- **Section « Disposition » du panneau** :
  - **Mode ultracompact** : les blocs prennent la largeur de leurs données.
  - **Combler automatiquement les espaces libres** : un petit bloc peut remonter dans un trou.
  - **Empiler les blocs sans trous** : chaque colonne s'empile indépendamment.
- L'ordre des blocs se règle par les flèches ↑ ↓ de chaque vue, leur largeur, leur colonne et leur hauteur en lignes par les listes de la vue ; l'aperçu en haut du panneau montre le résultat.

### Filtre rapide

Dans les réglages du bloc, chaque filtre a son encadré : **Filtre rapide**, puis **2ᵉ filtre rapide** (proposé une fois le premier choisi). Chacun contient :
1. **Champ** : le champ filtré (par exemple *Réseau*). Les champs de la vue sont proposés d'abord, puis les autres colonnes de la table : un champ non affiché peut donc servir de filtre.
2. **À l'ouverture** : *Tous*, ou la valeur à présélectionner.
3. **Valeurs exclues** (facultatif) : cocher les valeurs à retirer. Elles disparaissent des boutons du filtre **et** des lignes du bloc, même sur « Tous » (par exemple un établissement « Fermé »). Pour le 1er filtre, **(SO)** (lignes sans valeur) peut aussi être exclu.

Les deux filtres se cumulent : *Public* et *Ecole*.

Le filtre est disponible pour les tableaux, les listes de fiches, les graphiques et les cartes.

**Filtre libre** (encadré du même nom) : la case **Proposer un filtre libre** ajoute, sur une seconde ligne de l'en-tête du bloc, une liste « Filtrer sur… » où l'utilisateur choisit lui-même une colonne de la table (pièces jointes exceptées), puis coche une ou plusieurs de ses valeurs. Il se cumule avec les filtres rapides ; il n'est pas mémorisé. Une fois la case cochée, **Colonnes proposées** permet de limiter la liste aux colonnes cochées (aucune cochée : toutes). Il n'est pas proposé sur smartphone.

### Listes de sélection

Pour une vue affichée en **Liste de sélection** :
- **Colonne affichée** : le texte proposé dans la liste.
- **Ordre** : alphabétique, ou celui de la vue Grist.
- **Regrouper par** : intertitres dans la liste (par exemple les écoles par commune).
- **Ordre des groupes** (si « Regrouper par » est choisi) : intertitres en ordre alphabétique (A → Z) ou inverse (Z → A). Les nombres et les années sont classés par valeur : en ordre inverse, la rentrée la plus récente vient en premier.
- **ID de synchronisation** : les listes qui portent le même identifiant gardent la même sélection d'une page à l'autre (pages du widget comme autres pages Grist du même onglet).
  - Seules les listes **sur la même table** se synchronisent : deux listes de tables différentes (par exemple Circonscriptions et Écoles) peuvent porter le même identifiant sans interférer.
  - La sélection partagée est propre au **document** : elle ne passe pas d'un document à un autre (par exemple d'une copie de développement au document en service).
  - Elle dure le temps de l'onglet du navigateur ; un nouvel onglet repart de la première valeur.

### Cartes : réglages

Les réglages d'une carte sont regroupés en quatre encadrés.

**Points**

| Réglage | Effet |
|---|---|
| Étiquette | Colonne affichée au survol (par défaut celle de la carte Grist) |
| Étiquettes toujours visibles | Affiche toutes les étiquettes en permanence |
| Export réservé aux administrateurs | Le bouton d'export de la carte (fichier HTML interactif) n'apparaît qu'aux administrateurs. Par défaut, tout utilisateur peut exporter la carte qu'il voit |
| Zoom à la molette sans Ctrl | La molette et un doigt agissent directement sur la carte (ancien comportement). Par défaut, ils font défiler la page : Ctrl + molette ou deux doigts pour la carte |
| Couleur selon | Couleur des points selon une colonne |
| … sinon selon | Pour les points dont la colonne « Couleur selon » est vide : couleur selon une 2ᵉ colonne (teintes différentes, légende à part, sous le nom de la colonne). Les autres points gardent leur couleur |

**Contour des points**

| Réglage | Effet |
|---|---|
| Contour selon | Cercle autour des points : selon une colonne, avec jusqu'à 3 couleurs et conditions (`=`, `≠`, `<`, `≤`, `>`, `≥`, `contient`), ou **situation QPV (calculée)** |

**Quartiers prioritaires (QPV)**

| Réglage | Effet |
|---|---|
| Afficher les périmètres | Dessine les périmètres des QPV en pointillés rouges |
| Proximité d'un QPV | Distance retenue pour « à proximité » (0 à 500 m) |
| Fichier des QPV | Fichier GeoJSON des périmètres (par défaut `qpv-bretagne.geojson`) |

**Zones sous les points**

| Réglage | Effet |
|---|---|
| Zonage | Communes, EPCI, IRIS, circonscriptions législatives, secteurs de collège ou regroupements de communes, dessinés sous les points |
| Regroupement 1 à 3 : table, code INSEE, colonne, libellé | Jusqu'à trois regroupements par carte (un de plus est proposé quand le précédent est complet). Chacun : table avec une ligne par commune (ex. `P_Communes`), colonne du code INSEE (ex. `CODE_COM`), colonne qui réunit les communes (ex. `CODE_RP`, réseau pédagogique ; une référence est lue par sa colonne d'affichage) et nom du zonage (ex. *Réseaux pédagogiques*). Chaque regroupement complet est proposé dans la liste « Zonage » de la carte et dans les réglages *Zonage* / *Second zonage* ; ses zones qui contiennent des points sont dessinées en entier, communes sans point comprises. Table « — » : regroupement retiré. La table peut avoir plusieurs lignes par commune (ex. `REF_ETAB`, une ligne par établissement, avec `CODE_COM` et `CODE_CIRCO`) : la commune prend la valeur la plus fréquente parmi ses lignes non vides ; une référence vers la table des communes est lue par son code INSEE. Une commune partagée entre deux zones est rattachée à une seule |
| Second zonage (contours) | Un autre découpage tracé en fins pointillés noirs par-dessus le premier, pour croiser deux fonds (ex. secteurs de collège colorés + circonscriptions législatives). Nom au survol du trait |
| Étiquette au survol | Avec un second zonage : zonage dont le nom s'affiche au survol. *Zonage principal* (par défaut) ; ou *second zonage* : son nom s'affiche partout à l'intérieur de ses contours, et le principal n'a plus d'étiquette |
| Rattachement : circonscriptions / secteurs de collège | « position des points » (défaut) : la zone dont le contour contient le point. Ou une colonne de code (ex. `2201`, UAI) : la zone désignée par vos données, même si le point est hors de son contour (commune partagée entre deux zones, commune nouvelle…) |
| Rattachement : quartiers IRIS | *Tous les IRIS des communes des points* (défaut) ; *IRIS qui contiennent des points* (d'après leur position) ; ou une colonne de code IRIS à 9 caractères (ex. `290190101`, commune non découpée : INSEE + `0000`) : seulement les quartiers des points visibles, d'après vos données. Les points sans code reconnu sont signalés |
| Fichier : circonscriptions / secteurs de collège | Fichier GeoJSON déposé à côté du widget, ou plusieurs séparés par des virgules (ex. `secteurs-colleges-bretagne.geojson, secteurs-colleges-22.geojson`). Vide : `circonscriptions-bretagne.geojson`, `secteurs-colleges-bretagne.geojson`. Préparation : voir le README |
| Code INSEE | Colonne du code commune ; ou « position des points » pour le déduire des coordonnées |
| Couleur des zones | Une couleur par zone, aucune (contours seuls, sans fond), nombre de points, somme d'une colonne, ou valeur d'une table Grist reliée par code |

**Colorer les zones avec vos propres données** (par exemple la population des 3-10 ans par IRIS) :
1. Importer une table dans Grist, avec une colonne de code :
   - code IRIS à 9 caractères pour les IRIS (commune non découpée : code INSEE suivi de `0000`) ;
   - code INSEE pour les communes ;
   - SIREN pour les EPCI ;
   - code de la circonscription (ex. `2901`) pour les circonscriptions législatives ;
   - UAI du collège pour les secteurs de collège ;
   - valeur du regroupement (ex. nom du réseau) pour les regroupements de communes.
2. Couleur des zones → *selon une table Grist* : choisir la table, la colonne du code et la colonne de la valeur.

### Graphiques : couleurs

Le widget ne règle plus les couleurs (0.9.7.0) :
- **graphiques avancés** : couleurs réglées dans l'éditeur du graphique, dans Grist, reprises telles quelles ;
- **graphiques natifs** : palette du widget, dans l'ordre d'apparition des catégories ou des séries. Pour des couleurs fixes, utilisez un graphique avancé.

### Bloc-notes

Un widget **Markdown** de Grist peut servir de bloc-notes modifiable depuis la page :
1. Dans Grist, ajouter à la page un widget personnalisé *Markdown* sur une table de notes (par exemple `Notes`, une colonne texte `Texte`, une ligne par page ou par sujet), et associer sa colonne *Content*.
2. Dans la configuration du widget, encadré **Texte (Markdown)** du bloc : cocher **Bloc-notes modifiable**. La **taille du texte** reste réglable.

Le texte s'affiche sur un fond de papier jaune pâle. Le bouton ✎ (ou un double-clic) ouvre le texte Markdown brut ; **Enregistrer** (ou Ctrl+Entrée) l'écrit dans la colonne, pour la ligne affichée, et **Annuler** (ou Échap) l'abandonne.
- La colonne doit être une colonne de données, pas une formule.
- Les règles d'accès de Grist s'appliquent : une modification interdite est refusée et signalée ; les lecteurs voient le bloc-notes sans le bouton ✎.
- Si le bloc est lié à une sélection, chaque élément sélectionné a sa propre note (la ligne affichée change avec la sélection).
- Table vide, ou aucune note pour l'élément sélectionné : le bloc-notes s'affiche vide, et le premier enregistrement crée la ligne (rattachée à la sélection liée). Inutile de créer des lignes vides à l'avance.
- Case décochée : le texte est affiché en lecture seule, sans l'aspect bloc-notes.

### Message d'accueil

Section **Message d'accueil** de la configuration : un texte en Markdown (titres `##`, gras `**…**`, listes `-`, liens `[texte](https://…)`) affiché dans une fenêtre à l'ouverture du widget, pour tous les utilisateurs et sur toutes les pages. Le bouton **Aperçu** le montre tel qu'il apparaîtra.

**Parties repliables** : une ligne `+++ Titre` ouvre une partie repliée, affichée au clic sur son titre ; une ligne `+++` seule la ferme. Avec `+++! Titre`, la partie est dépliée au départ. Le contenu reste du Markdown, et les parties peuvent s'imbriquer.

```
## Bienvenue
Ce tableau de bord présente la carte scolaire.

+++ Comment filtrer ?
Choisir une circonscription dans la liste en haut de la page.
+++
```

Chaque personne voit le message **une fois** : à sa fermeture, le navigateur mémorise l'empreinte du texte. Il ne revient que si le texte est modifié — pas après une mise à jour du widget ni un enregistrement de la configuration. Aide → **Message d'accueil** le réaffiche à la demande. Laisser le texte vide supprime le message.

**Écran de chargement** (même section) : affiché à l'ouverture du widget et quand Grist le recharge (par exemple après une modification des droits), si le chargement dure plus de 0,4 s ; il reste alors visible au moins 0,8 s, pour ne pas clignoter.
- **Image** : GIF animé, PNG, JPEG ou WebP, **300 Ko au plus**. Elle est enregistrée dans le document (ligne `_Navigation` de `W_Composition`) et relue à chaque ouverture ; d'où la limite de taille. **Retirer** l'enlève.
- **Titre** et **Texte** : affichés sous l'image (le texte garde ses retours à la ligne).
- Dessous, l'étape en cours (« Lecture des données : 7 / 12 », « Mise en forme : … ») et une barre de progression.
- **Aperçu** montre l'écran 4 secondes (un clic le ferme).

Le navigateur de chaque personne garde une copie de l'image et des textes : dès la deuxième ouverture, ils s'affichent dès le début du chargement. À la toute première, l'écran commence sans eux et les montre dès que la configuration est lue. Sans réglage, l'écran ne montre que l'étape et la barre.

### Maintenance et accès fermé

Le widget lit une petite table **`W_Messages`**, à créer une fois, avec une seule ligne :

| Colonne | Type | Rôle |
|---|---|---|
| `Maintenance` | Booléen | Cochée : les utilisateurs voient l'écran de maintenance |
| `Message_maintenance` | Texte (Markdown possible) | Texte de l'écran de maintenance |
| `Fin_prevue` | Date et heure (facultatif) | Affichée : « Retour prévu : vendredi 13 novembre 2026 à 20:00 » |
| `Message_sans_acces` | Texte (Markdown possible) | Texte affiché aux personnes qui ne peuvent lire aucune page (ex. qui contacter) |

**Règle d'accès** : `W_Messages` doit rester **lisible par tous**, même pendant la maintenance. Donnez-lui une règle propre (lecture pour tous, modification réservée aux propriétaires), placée **avant** la règle de maintenance.

**Pendant une maintenance** : cochez `Maintenance`, écrivez le message, puis activez votre règle habituelle. Les utilisateurs voient « Maintenance en cours », le message et l'heure de retour prévue. Les administrateurs voient le site normalement, avec un bandeau jaune « Maintenance active ». À la fin, décochez `Maintenance` et retirez la règle : la page normale revient quand Grist recharge le widget (changement des droits), à la prochaine ouverture ou au clic sur ⟳ Actualiser.

**Accès non ouvert** : une personne à qui le document est partagé, mais qui ne peut lire aucune page configurée (par exemple parce que son email ne figure pas dans la table des utilisateurs), voit « Accès non ouvert » et `Message_sans_acces`. Une personne à qui le document n'est pas partagé n'atteint pas le widget : Grist l'arrête avant.

Sans `W_Messages`, un texte par défaut s'affiche seulement quand rien n'est lisible du tout.

### Menu de navigation

Section **5. Navigation entre pages**. Ce réglage est commun à toutes les configurations.

- **Adresse du document** : adresse de base du document Grist (https).
- **Changer de page dans le widget** : le menu bascule de configuration sans recharger Grist. Recommandé quand toutes les configurations sont réunies dans une seule page Grist.
- **Page d'accueil** : page affichée à l'ouverture, pour tous les utilisateurs. Avec « Changer de page dans le widget », elle s'impose à l'ouverture de l'onglet (si Grist recharge ensuite le widget, par exemple après une modification de droits, il revient sur la page où l'on était) ; sinon, elle sert quand le widget n'a pas de configuration enregistrée. Si le widget ne sait pas quelle configuration afficher, seul un administrateur se voit poser la question, et sa réponse devient la page d'accueil ; les utilisateurs ne sont jamais interrogés.
- **Ouvrir les pages en mode page unique** : les liens ouvrent Grist sans ses menus. Proposé seulement sans « Changer de page dans le widget » ; sinon, utiliser le bouton **Plein écran** de la barre d'outils, ouvert à tous.
- **Pour chaque lien** :
  - icône (facultative), affichée devant le lien et en tête de la page elle-même (devant son titre s'il est affiché, sinon avant les listes de sélection, et dans l'en-tête imprimé) : code d'un fichier SVG collé dans le champ « Icône (code SVG) » — ouvrir le fichier .svg dans un éditeur de texte (Bloc-notes…), tout sélectionner, copier. L'aperçu s'affiche à gauche du champ (« ? » rouge : code non reconnu). L'icône prend la couleur du lien ; scripts, styles et images externes sont retirés ;
  - libellé ;
  - infobulle (facultative) : texte affiché au survol du lien ; sans infobulle, le survol montre l'adresse de la page, sauf avec « Changer de page dans le widget » ;
  - page Grist, ou **— ce widget —** ;
  - configuration à afficher ;
  - visibilité : *tous*, ou *si accès à* une table (le lien n'apparaît qu'aux personnes qui voient au moins une ligne de cette table, quelle qu'en soit la raison : table vide, règles d'accès par ligne, lignes pas encore créées). Exemple : une page de suivi qui n'apparaît qu'une fois que l'utilisateur a créé sa première ligne dans une autre page ; le lien apparaît dès cette création, sans recharger le widget.
  - **Bouton** (facultatif) : le lien quitte le menu des pages et devient un bouton de la barre d'outils, à côté de l'Aide (sur smartphone, dans le menu ☰). Il porte l'icône du lien (icône de pages si aucune) et, au survol, l'infobulle ou le libellé. La visibilité ci-dessus s'applique : pratique pour des pages d'administration ou de paramétrage réservées à certains utilisateurs.

### Apparence

Section **4. Affichage**, **Apparence (tout le document)** :
- **Style État (DSFR)** : police Marianne et bleu France. Réservé aux **services de l'État** par les conditions d'utilisation du Système de design de l'État.
- **Style neutre** : police du système et rouge bordeaux (couleur distincte du bleu de l'État, repérable d'un coup d'œil), pour toute autre structure (collectivité, association, entreprise…).

Sans choix, le widget s'affiche en style État. Le choix vaut pour toutes les pages du document ; il n'est jamais proposé aux utilisateurs.

**Mode clair / sombre** (même section) :
- **Comme le système de chaque utilisateur** (par défaut) : le widget passe en mode sombre quand l'ordinateur ou le téléphone de la personne est réglé en sombre, et bascule aussitôt si ce réglage change. C'est le réglage du système qui compte, pas le thème choisi dans Grist.
- **Toujours clair** / **Toujours sombre** : impose un mode à tous.

En mode sombre, les couleurs choisies dans Grist (pastilles, mises en forme conditionnelles, couleurs des graphiques) sont reprises telles quelles ; le fond de carte reste clair, légèrement assombri. L'impression est toujours en couleurs claires.

### Enregistrer

**Enregistrer** applique la configuration et l'écrit dans la table `W_Composition` du document. Les filtres rapides reviennent alors à leur valeur à l'ouverture.


### Distancier routier

Outil séparé, à installer dans une page d'administration : vue **Widget personnalisé**, adresse `https://ligures.github.io/ux-widget-grist/outils/distancier.html`, accès **complet**.

1. Créer la table des distances (`REF_DISTANCES`) : `Depart`, `Arrivee` (références à `REF_ETAB`), `Km`, `Minutes` (numériques), `Statut` (texte), `Calcule_le` (date).
2. Vérifier les **Paramètres** : noms de tables et de colonnes, **Restreindre à** (par défaut les écoles dont `Statut_public_prive` contient « Public » ; vide : toutes), **Service** (Metric-OSRM de l'Insee par défaut, ou IGN), **Sans bateaux** (coché : les îles ne sont reliées qu'à leurs propres écoles). Le bandeau indique le nombre d'écoles retenues, celles dont le collège de secteur est localisé, et les distances déjà connues ; en rouge, il signale un collège renseigné mais introuvable ou sans coordonnées.
3. Cliquer sur **Tester un appel** : le journal montre la réponse du service pour une école et ses voisines.
4. Faire un essai : « Écoles à traiter » = 5, puis **Calculer les distances manquantes**. Contrôler quelques lignes dans `REF_DISTANCES`.
5. Régler **Lignes conservées par école** : nombre de distances enregistrées par école (les plus courtes par la route), en plus du trajet vers le collège. Les autres trajets calculés servent au calcul exact mais ne sont pas écrits : la table reste petite (environ 6 lignes par école avec 5).
6. Remettre 0 (toutes les écoles) et relancer. Laisser l'onglet ouvert : avec Metric-OSRM, compter environ 1 appel par école, soit une vingtaine de minutes pour 1 400 écoles. **Arrêter** est sans risque : on reprend où l'on en était.

**Nettoyer la table** : apparaît quand des écoles ont plus de lignes que le nombre conservé (calcul d'une version précédente, ou nombre réduit). Premier clic : nombre de lignes à supprimer ; second clic : suppression des distances les plus longues de chaque école, le trajet vers le collège étant toujours gardé. Aucun appel au service. À la relance, une école qui a déjà ses lignes est passée.

Le distancier écrit dans le document à chaque lot de 25 lignes : les formules qui lisent `REF_DISTANCES` se recalculent alors. Lancez-le de préférence quand personne d'autre ne travaille sur le document, et placez-le seul sur une page d'administration (il lit les tables entières à son ouverture). Les colonnes de formule de `REF_DISTANCES` (un résumé du trajet, par exemple) peuvent être des formules d'initialisation, recalculées seulement si `Depart` ou `Arrivee` change.

Les distances calculées ne bougent plus. Après le déplacement d'une école (nouvelles coordonnées), supprimer ses lignes dans `REF_DISTANCES` (en départ et en arrivée), puis relancer. Après l'ajout d'une école, relancer simplement.

Formules à placer dans `REF_ETAB` :
- 5 écoles les plus proches par la route (Liste de références vers `REF_ETAB`) :
  ```python
  lignes = [d for d in REF_DISTANCES.lookupRecords(Depart=$id)
            if d.Km is not None and "Ecole" in (d.Arrivee.Type_etablissement or "")]
  return [d.Arrivee for d in sorted(lignes, key=lambda d: d.Km)[:5]]
  ```
- distance et durée vers le collège de secteur (Numérique) :
  ```python
  d = REF_DISTANCES.lookupOne(Depart=$id, Arrivee=$UAI_College)
  return d.Km if d else None
  ```
  (même formule avec `d.Minutes` pour la durée).

---

## 2. Questions fréquentes

**Un éditeur voit le bouton Configurer.**
Il lit une ligne de `W_Admin`. Réservez la lecture de cette table aux administrateurs par une règle d'accès, puis vérifiez avec *Règles d'accès → Voir en tant que*.

**Les onglets n'apparaissent pas pour certains utilisateurs.**
Le menu des onglets est enregistré dans la ligne `_Navigation` de `W_Composition` : ces utilisateurs doivent pouvoir **lire** cette table (seule la modification est à réserver aux administrateurs). Vérifiez aussi les liens réglés sur « si accès à <table> ».

**J'ai renommé une colonne ou une vue dans Grist.**
Le panneau **Configurer** relit la structure à chaque ouverture : les nouveaux noms y apparaissent. Les colonnes déjà choisies dans les réglages suivent automatiquement leur renommage, pour les configurations enregistrées depuis la version 0.8.5. Pour l'affichage des pages, cliquez sur **⟳ Actualiser**.

**Une carte reste vide.**
- Vérifiez que les colonnes de latitude et de longitude sont renseignées.
- Pour les contours des communes, la colonne **Code INSEE** doit contenir un code à 5 chiffres, et non le nom de la commune. Sinon, choisissez « position des points ».

**Où voir la version du widget ?**
Au survol du bouton Aide, dans l'onglet **Nouveautés**, et en bas du panneau **Configurer**.
