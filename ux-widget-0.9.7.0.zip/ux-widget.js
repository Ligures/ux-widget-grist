/* UX widget grist — script principal (version 0.9.7.0). Développeur : Ligures. Licence MIT (voir LICENSE).
   Chargé par index.html, à la fin du corps de la page. Voir le sommaire ci-dessous.
   Depuis 0.9.5, deux parties sont chargées à la demande (loadPart), dans le même espace global :
     ux-carte.js  : cartes (Leaflet, zonages, QPV, impression et export d'une carte), si la page a une carte ;
     ux-config.js : panneau de configuration ⚙, à son ouverture (charge aussi ux-carte.js). */
"use strict";
/* ════════════════════════════════════════════════════════════════════════════
   SOMMAIRE DU SCRIPT
   ────────────────────────────────────────────────────────────────────────────
   État et constantes ........ objet S (tout l'état du widget), valeurs par défaut
   Utilitaires ............... esc, parseJSON, toRows, fetchRows (cache des tables)
   Métadonnées ............... loadMeta, getInfo : lecture des vues Grist
   Mise en forme ............. textOf, htmlOf, styles et règles conditionnelles
   Filtres, tri, liaisons .... rowsFor, selectedRowId, linkFor
   Rendu des blocs ........... blockShell, renderTable, renderSingle, renderCards,
                         renderChart (Chart.js), renderAdvChart (Plotly),
                         renderMap (ux-carte.js : Leaflet, points, QPV, zonages)
   Édition ................... startEdit, saveValue (droits Grist respectés)
   Listes de sélection ....... renderSelectors, synchronisation entre pages
   Rendu principal ........... render() — point central, appelé via scheduleRender()
   Interactions .............. clics, sélection de ligne, plein écran
   Export .................... impression / PDF
   Configuration ............. panneau ⚙ (ux-config.js : renderConfig), enregistrement
   Démarrage ................. init(), applyOptions(), abonnements grist.on…

   CYCLE DE VIE
     grist.ready → onOptions → applyOptions → init :
 loadMeta (tables _grist_*) → configurations de W_Composition → menu
 → droits (W_Admin) → render().
     Tout changement (sélection, données, options) passe par scheduleRender(),
     qui regroupe les demandes ; render() abandonne s'il est doublé par un rendu
     plus récent (S.renderSeq). Les dessins lourds (cartes, graphiques, grands
     tableaux) sont différés dans des « jobs » exécutés après l'affichage.

   STOCKAGE DANS LE DOCUMENT GRIST
     W_Composition (Nom, Config JSON) : une ligne par configuration de page,
 + ligne « _Navigation » (menu commun) et « _Securite » (témoin de protection).
     W_Admin : table réservée aux propriétaires par une règle d'accès ; qui en voit
 une ligne peut configurer (bouton ⚙).

   CONFIGURATION D'UNE PAGE (S.cfg)
     { name, title, blocks: [...], flux, dense, masonry, hideEmptyFields,
 hideEmptyBlocks, tableMaxHeight, chartHeight, dataTable }
     Bloc (blocks[i]) : id = identifiant de la vue Grist (_grist_Views_section)
 Séparateur (0.9.7.0) : { id: "sepN", sep: true, name, note, width } dans la liste des blocs
 Disposition : width (1-6), start, rows, fw (flux), newLine, height, sticky, startFold, needOthers, subDesc (description de la vue en sous-titre), hLevel (2 : titre en h2 ; sinon h3)
 Tableaux/fiches : colWidths, rowCount, asList, cardW, editable, addable, showEmpty, hideLabels
 Texte (Markdown) : mdSize, mdEdit (modifiable depuis la page), mdNote (aspect bloc-notes)
 Liste de sélection : asSelect, selCol, selOrder, selGroup, selGroupOrder, syncId
 Carte : mapLabel, mapWheel (molette sans Ctrl), mapExportAdmin, qfFree (filtre libre, tous blocs), mapColor, mapRing + mapRules (contour), mapQpv, qpvDist,
         qpvUrl, mapZone (communes|epci|iris|legis|college|groupe|groupe2|groupe3), mapZone2 (contours croisés), zoneHover, legisUrl, collegeUrl, legisCol, collegeCol, irisCol, mapCommune, zoneColor,
         zoneSum, zoneTable/zoneKey/zoneVal, grpTable/grpKey/grpCol/grpLabel (et grp2…, grp3…), mapLabelsOn

   RÈGLES À RESPECTER
     • Toute valeur issue des données ou de la configuration insérée dans du HTML
 passe par esc() (ou safeHtml() pour le HTML voulu des étiquettes de carte).
     • Les bibliothèques externes sont figées en version et vérifiées (SRI, LIBS).
     • Les droits restent ceux de Grist : le widget ne contourne aucune règle d'accès.
   ════════════════════════════════════════════════════════════════════════════ */

/* ---------- État et constantes ---------- */
// DEFAULTS — options d'une page neuve. KIND — libellé des types de vues Grist (parentKey).
// SUPPORTED — types affichables. DEFAULT_WIDTH — largeur initiale (en sixièmes) d'un bloc ajouté.
const VERSION = "0.9.7.0"; // voir CHANGELOG.md
const DEFAULTS = {
  name: "Page composée",
  title: "",
  blocks: [],
  hideEmptyFields: true,
  hideEmptyBlocks: false,
  tableMaxHeight: 320,
  chartHeight: 260,
};
const KIND = {
  record: "Tableau",
  single: "Fiche",
  detail: "Fiches",
  chart: "Graphique",
  custom: "Widget personnalisé",
  form: "Formulaire",
};
const SUPPORTED = ["record", "single", "detail", "chart", "custom"];
// Icônes des types de vue (configuration) : tracés SVG 24×24, couleur du texte
const KIND_ICONS = {
  table: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M3 9h18M3 14.5h18M9.5 4v16"/>',
  card: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  cards: '<rect x="3" y="4" width="8" height="7" rx="1"/><rect x="13" y="4" width="8" height="7" rx="1"/><rect x="3" y="13" width="8" height="7" rx="1"/><rect x="13" y="13" width="8" height="7" rx="1"/>',
  bar: '<path d="M4 20h16"/><rect x="6" y="11" width="3" height="9"/><rect x="11" y="6" width="3" height="14"/><rect x="16" y="14" width="3" height="6"/>',
  pie: '<path d="M12 3a9 9 0 1 0 9 9h-9z"/><path d="M14.5 2.5v7h7a7 7 0 0 0-7-7z"/>',
  line: '<path d="M4 20h16M4 16l5-6 4 3 6-8"/>',
  scatter: '<path d="M4 20h16"/><circle cx="7" cy="15" r="1.3"/><circle cx="11" cy="10" r="1.3"/><circle cx="15" cy="13" r="1.3"/><circle cx="18" cy="6" r="1.3"/>',
  map: '<path d="M12 21s-6-5.3-6-11a6 6 0 0 1 12 0c0 5.7-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/>',
  select: '<rect x="3" y="7" width="18" height="10" rx="2"/><path d="M14 11l2 2 2-2"/>',
  form: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8 8h8M8 13h3M13 13h3M8 17h8"/>',
  text: '<path d="M4 5h16M4 10h16M4 15h10M4 20h7"/>',
  widget: '<path d="M10 4h4v3a2 2 0 1 0 4 0V4h2v6h-3a2 2 0 1 0 0 4h3v6h-6v-3a2 2 0 1 0-4 0v3H4v-6h3a2 2 0 1 0 0-4H4V4z"/>',
};
// viewKind — Type d'une vue : [clé d'icône, libellé] (tableau, fiche, graphique en barres / secteurs…, carte, liste de sélection…).
function viewKind(s, b) {
  let k = "widget",
    t = KIND[s.parentKey] || s.parentKey;
  if (b && isSelector(b)) [k, t] = ["select", "Liste de sélection"];
  else if (s.parentKey === "record") k = "table";
  else if (s.parentKey === "single") k = "card";
  else if (s.parentKey === "detail") k = "cards";
  else if (s.parentKey === "form") k = "form";
  else if (s.parentKey === "chart") {
    const ct = s.chartType || "bar";
    k = ["pie", "donut"].includes(ct) ? "pie" : ["line", "area", "kaplan_meier"].includes(ct) ? "line" : ct === "scatter" ? "scatter" : "bar";
    t = `Graphique (${{ pie: "secteurs", donut: "anneau", line: "courbe", area: "aires", scatter: "nuage de points", kaplan_meier: "courbe" }[ct] || "barres"})`;
  } else if (s.parentKey === "custom") {
    if (isMapSection(s)) [k, t] = ["map", "Carte"];
    else if (isMarkdownSection(s)) [k, t] = ["text", "Texte (Markdown)"];
    else {
      const data = advChartSpec(s)?.data;
      if (data) [k, t] = [data.some((x) => x?.type === "pie") ? "pie" : "bar", "Graphique avancé"];
    }
  }
  return [k, t];
}
// kindIcon — Icône SVG du type d'une vue.
function kindIcon(s, b) {
  const [k, t] = viewKind(s, b);
  return `<svg class="kico" viewBox="0 0 24 24" aria-hidden="true"><title>${esc(t)}</title>${KIND_ICONS[k]}</svg>`;
}
// kindTitle — Icône, type puis titre d'une vue (configuration).
function kindTitle(s, b) {
  return `${kindIcon(s, b)}<b class="ctype">${esc(viewKind(s, b)[1])}</b> <span class="ctitle">${esc(getInfo(s.id)?.title || `#${s.id}`)}</span>`;
}
const DEFAULT_WIDTH = { record: 6, single: 2, detail: 6, chart: 3, custom: 3 };
// BRAND — couleur principale des graphiques et cartes : bleu France (DSFR) ou rouge bordeaux du style neutre (voir applyTheme)
const BRAND = { c: "#000091" };
const PALETTE = [
  "#000091",
  "#009081",
  "#E18B76",
  "#68A532",
  "#A558A0",
  "#C8AA39",
  "#465F9D",
  "#E4794A",
  "#009099",
  "#D1B781",
  "#6A6AF4",
  "#CE614A",
];

// S — tout l'état du widget (un seul objet, pour savoir où chercher).
//   cfg : configuration de la page   meta : métadonnées Grist (loadMeta)   info : cache de getInfo
//   cache/byId : données des tables  sel : ligne sélectionnée par vue       search : texte « Filtrer… »
//   collapsed : blocs repliés        usort/ufilt : tri et filtres choisis dans les en-têtes
//   charts/maps : objets à détruire avant chaque rendu   mapViews : centre/zoom conservés par carte
const S = {
  cfg: { ...DEFAULTS },
  qf: {}, // filtre rapide : valeur choisie par bloc ("" = tous)
  meta: null,
  info: new Map(),
  cache: {},
  byId: {}, // données des tables
  sel: {},
  search: {},
  collapsed: {},
  usort: {},
  ufilt: {},
  fieldOpts: new Map(),
  ext: { tableId: null, rowId: null }, // sélection transmise au widget par Grist
  extSel: new Map(), // sélection déduite pour les widgets natifs (listes déroulantes…)
  charts: [],
  maps: [],
  mapViews: {},
  geoCache: {},
  ready: false,
  optsApplied: false,
  renderTimer: null,
};

/* ---------- Utilitaires ---------- */
const $ = (s) => document.querySelector(s);
// esc — Échappe un texte pour l'insérer dans du HTML. À utiliser pour TOUTE valeur venant des données ou de la configuration.
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
// parseJSON — Lit du JSON sans planter : renvoie `fallback` si le texte est vide ou invalide (les options Grist sont du JSON en texte).
const parseJSON = (s, def = {}) => {
  if (!s) return def;
  if (typeof s === "object") return s;
  try {
    return JSON.parse(s);
  } catch {
    return def;
  }
};
// isList — Valeur de liste Grist (RefList, ChoiceList) : tableau commençant par le marqueur "L".
const isList = (v) => Array.isArray(v) && v[0] === "L";
// isErr — Erreur de formule Grist : tableau commençant par le marqueur "E".
const isErr = (v) => Array.isArray(v) && v[0] === "E";
// isEmpty — Cellule vide au sens de Grist (null, chaîne vide, liste vide).
const isEmpty = (v) => v === null || v === undefined || v === "" || (isList(v) && v.length === 1);
// baseType — Type de colonne sans sa cible : "Ref:Ecoles" → "Ref".
const baseType = (col) => String(col?.type || "Any").split(":")[0];
// refTarget — Table cible d'une colonne Ref/RefList : "Ref:Ecoles" → "Ecoles".
const refTarget = (col) => String(col?.type || "").split(":")[1];
// groupBy — Regroupe un tableau d'objets par la valeur d'une clé → Map(clé → liste).
const groupBy = (arr, key) => {
  const m = new Map();
  for (const x of arr) {
    const k = x[key];
    if (!m.has(k)) m.set(k, []);
    m.get(k).push(x);
  }
  return m;
};
// status — Affiche un message dans la zone d'état sous l'en-tête (err = en rouge).
// Bulle flottante : un message en cours (« … ») reste affiché jusqu'à la fin ; une information s'efface
// seule après 4 s, une erreur après 12 s (ou au clic).
let statusTimer = null,
  statusErrUntil = 0;
function status(msg, err = false, force = false) {
  const el = $("#status");
  // une erreur (modification refusée…) reste lisible au moins 4 s : le réaffichage de la page, qui efface la
  // ligne d'état ou affiche « Calcul en cours… », ne la remplace pas avant (seule une autre erreur le peut)
  if (!force && !err && Date.now() < statusErrUntil) return;
  if (err) statusErrUntil = Date.now() + 4000;
  clearTimeout(statusTimer);
  el.textContent = msg || "";
  el.className = err ? "err" : "";
  el.title = msg && err ? `${msg} (cliquer pour fermer)` : msg || "";
  if (!msg || (!err && /…$/.test(msg))) return;
  statusTimer = setTimeout(
    () => {
      el.classList.add("fade");
      statusTimer = setTimeout(() => (el.textContent = ""), 400);
    },
    err ? 8000 : 4000,
  );
}
$("#status").addEventListener("click", () => {
  statusErrUntil = 0;
  status("", false, true);
});

// toRows — Convertit le format colonnes de fetchTable ({col: [valeurs]}) en tableau de lignes [{id, col…}].
function toRows(tbl) {
  const ids = tbl.id || [],
    cols = Object.keys(tbl);
  return ids.map((id, i) => {
    const r = {};
    for (const c of cols) r[c] = tbl[c][i];
    return r;
  });
}
// fetchRows — Charge une table (une seule fois, mise en cache) et indexe ses lignes par id dans S.byId.
function fetchRows(tableId) {
  if (!S.cache[tableId]) {
    S.cache[tableId] = grist.docApi
      .fetchTable(tableId)
      .then((t) => {
        const rows = toRows(t);
        S.byId[tableId] = new Map(rows.map((r) => [r.id, r]));
        noteRefDisplays(tableId, rows);
        return rows;
      })
      .catch((e) => {
        // table interdite par les règles d'accès : le refus est mémorisé jusqu'au prochain « Actualiser »
        // (sinon elle serait redemandée au serveur à chaque sélection, ce qui peut prendre plusieurs secondes)
        if (!/access|acc[eè]s|permission|denied|blocked/i.test(String(e?.message || e))) delete S.cache[tableId];
        throw e;
      });
  }
  return S.cache[tableId];
}

/* Texte des références vers des lignes que l'utilisateur ne peut pas lire (règles d'accès par ligne) :
   Grist calcule pour chaque colonne Référence une colonne cachée « gristHelper_Display » dans la table qui
   référence, lisible même quand la ligne visée ne l'est pas. On note ces textes par colonne Référence et par id
   (0.8.10.5 : par colonne, et non par table visée — deux colonnes vers la même table peuvent afficher des champs
   différents, par exemple l'UAI et le nom). */
S.refDisp = {};
function noteRefDisplays(tableId, rows) {
  const m = S.meta;
  if (!m) return;
  const tref = [...m.tables.values()].find((t) => t.tableId === tableId)?.id;
  for (const c of m.colsByTable.get(tref) || []) {
    const bt = baseType(c);
    if ((bt !== "Ref" && bt !== "RefList") || !c.displayCol) continue;
    const disp = m.cols.get(c.displayCol)?.colId;
    if (!disp) continue;
    const map = (S.refDisp[c.id] ||= new Map());
    for (const r of rows) {
      const v = r[c.colId],
        d = r[disp];
      if (bt === "Ref" && v && d != null && !isErr(d)) map.set(v, String(d));
      else if (bt === "RefList" && isList(v) && isList(d)) v.slice(1).forEach((id, i) => d[i + 1] != null && map.set(id, String(d[i + 1])));
    }
  }
}

/* ---------- Métadonnées de mise en page ---------- */
/* Diagnostic de lenteur : chaque lecture de table (fetchTable) est chronométrée ; les lectures de plus de
   200 ms sont signalées dans la console du navigateur (F12), avec le total au premier affichage. */
S.fetchLog = [];
{
  const orig = grist.docApi.fetchTable.bind(grist.docApi);
  grist.docApi.fetchTable = async (tableId, ...rest) => {
    const t0 = performance.now();
    try {
      return await orig(tableId, ...rest);
    } finally {
      const ms = Math.round(performance.now() - t0);
      S.fetchLog.push([tableId, ms]);
      if (ms > 200) console.info(`[UX widget] lecture de ${tableId} : ${ms} ms`);
    }
  };
}
async function loadMeta() {
  const names = [
    "_grist_Tables",
    "_grist_Tables_column",
    "_grist_Views",
    "_grist_Pages",
    "_grist_Views_section",
    "_grist_Views_section_field",
    "_grist_Filters",
  ];
  const [tables, cols, views, pages, sections, fields, filters] = await Promise.all(
    names.map((n) => grist.docApi.fetchTable(n).then(toRows)),
  );
  if (!sections.length || !cols.length) {
    throw new Error(
      "Les métadonnées des vues sont vides. Vérifier que le widget a l'accès « complet au document ».",
    );
  }
  const m = {};
  m.tables = new Map(tables.map((t) => [t.id, t]));
  m.cols = new Map(cols.map((c) => [c.id, c]));
  m.colsByTable = groupBy(cols, "parentId");
  m.views = new Map(views.map((v) => [v.id, v]));
  m.sections = new Map(sections.map((s) => [s.id, s]));
  m.sectionsByView = groupBy(
    sections.filter((s) => s.parentId),
    "parentId",
  );
  // Nom de page : nom de la vue, sinon titres de ses widgets, sinon numéro
  const pageName = (vid) =>
    m.views.get(vid)?.name ||
    (m.sectionsByView.get(vid) || [])
      .map((s) => s.title)
      .filter(Boolean)
      .slice(0, 2)
      .join(" / ") ||
    `Page n°${vid}`;
  const viewOf = (p) => Number(p.view ?? p.viewRef ?? p.View ?? 0);
  m.pages = pages
    .slice()
    .sort((a, b) => a.pagePos - b.pagePos)
    .map((p) => ({ viewId: viewOf(p), indent: p.indentation || 0 }))
    .filter((p) => p.viewId)
    .map((p) => ({ ...p, name: pageName(p.viewId) }));
  if (!m.pages.length) {
    // repli : vues possédant des widgets
    m.pages = [...m.sectionsByView.keys()]
      .sort((a, b) => a - b)
      .map((vid) => ({ viewId: vid, indent: 0, name: pageName(vid) }));
  }
  m.pageOfView = new Map(m.pages.map((p) => [p.viewId, p.name]));
  // Tables lisibles par l'utilisateur : une table entièrement interdite n'apparaît pas dans listTables
  // (et Grist vide son tableId dans les métadonnées)
  try {
    m.visibleTables = new Set(await grist.docApi.listTables());
  } catch {
    m.visibleTables = null;
  }
  m.loadedAt = new Date().toLocaleTimeString("fr-FR"); // heure de lecture de la structure (diagnostic)
  m.diag =
    `Structure lue à ${m.loadedAt} · ${cols.length} colonnes · ` +
    `Diagnostic — _grist_Pages : ${pages.length} lignes, colonnes [${Object.keys(pages[0] || {}).join(", ")}] · ` +
    `_grist_Views : ${views.length} · widgets : ${sections.length} · pages reliées à des widgets : ` +
    `${m.pages.filter((p) => m.sectionsByView.has(p.viewId)).length}`;
  m.fieldsBySection = groupBy(
    fields.slice().sort((a, b) => a.parentPos - b.parentPos),
    "parentId",
  );
  m.filtersBySection = groupBy(filters, "viewSectionRef");
  S.meta = m;
  S.info = new Map();
}

function groupCols(tableRef) {
  // colonnes de regroupement d'une table de synthèse : Map(colRef source -> colId)
  const t = S.meta.tables.get(tableRef);
  if (!t?.summarySourceTable) return null;
  return new Map(
    (S.meta.colsByTable.get(tableRef) || [])
      .filter((c) => c.summarySourceCol)
      .map((c) => [c.summarySourceCol, c.colId]),
  );
}
// tableLabel — Libellé lisible d'une table (nom de la page qui l'affiche, sinon son identifiant).
function tableLabel(tableRef) {
  const t = S.meta.tables.get(tableRef);
  if (!t) return "?";
  if (t.summarySourceTable) {
    const src = S.meta.tables.get(t.summarySourceTable)?.tableId || "?";
    return `${src} [${[...(groupCols(tableRef)?.values() || [])].join(", ") || "total"}]`;
  }
  return t.tableId;
}

// getInfo — Description complète d'une vue Grist (section) : table, type, champs affichés, tri, filtres, options. Mise en cache.
function getInfo(secId) {
  if (S.info.has(secId)) return S.info.get(secId);
  const m = S.meta,
    sec = m.sections.get(secId);
  if (!sec) return null;
  const table = m.tables.get(sec.tableRef);
  const fields = (m.fieldsBySection.get(secId) || [])
    .map((f) => {
      const col = m.cols.get(f.colRef);
      if (!col || col.colId.startsWith("gristHelper_")) return null;
      const opts = { ...parseJSON(col.widgetOptions), ...parseJSON(f.widgetOptions) };
      S.fieldOpts.set(f.id, opts);
      return { col, field: f, colId: col.colId, label: col.label || col.colId, opts };
    })
    .filter(Boolean);
  const filters = (m.filtersBySection.get(secId) || [])
    .map((f) => {
      const col = m.cols.get(f.colRef);
      const spec = parseJSON(f.filter, null);
      return col && spec && Object.keys(spec).length ? { col, spec } : null;
    })
    .filter(Boolean);
  const sort = parseJSON(sec.sortColRefs, [])
    .map((x) => {
      const n = parseInt(String(x), 10);
      const col = m.cols.get(Math.abs(n));
      return col ? { col, desc: n < 0, opts: parseJSON(col.widgetOptions) } : null;
    })
    .filter(Boolean);
  const info = {
    sec,
    secId,
    table,
    tableId: table?.tableId,
    kind: sec.parentKey,
    fields,
    filters,
    sort,
    opts: parseJSON(sec.options),
    title: sec.title || tableLabel(sec.tableRef),
  };
  S.info.set(secId, info);
  return info;
}

/* ---------- Mise en forme des valeurs ---------- */
function fmtNum(v, o, t) {
  const min = Math.min(20, Math.max(0, o.decimals ?? 0));
  const max = Math.min(20, Math.max(min, o.maxDecimals ?? (t === "Int" ? 0 : 10)));
  const f = { minimumFractionDigits: min, maximumFractionDigits: max, useGrouping: !!o.numMode };
  if (o.numMode === "percent") f.style = "percent";
  if (o.numMode === "currency") {
    f.style = "currency";
    f.currency = o.currency || "EUR";
  }
  try {
    return new Intl.NumberFormat("fr-FR", f).format(v);
  } catch {
    return String(v);
  }
}
// refText — Texte affiché pour une référence : valeur de la colonne d'affichage (visibleCol) de la ligne ciblée.
function refText(col, id, depth) {
  if (!id) return "";
  const row = S.byId[refTarget(col)]?.get(id);
  if (!row) return S.refDisp[col.id]?.get(id) ?? String(id); // ligne non lisible : texte calculé par Grist
  const vis = col.visibleCol ? S.meta.cols.get(col.visibleCol) : null;
  if (!vis) return `${refTarget(col)}[${id}]`;
  return depth > 2
    ? String(row[vis.colId] ?? "")
    : textOf(vis, parseJSON(vis.widgetOptions), row[vis.colId], depth + 1);
}
// textOf — Texte d'une cellule tel que Grist l'afficherait (références, listes, dates, nombres, choix…).
function textOf(col, opts, v, depth = 0) {
  if (isErr(v)) return "#" + (v[1] || "ERREUR");
  if (isEmpty(v)) return "";
  const t = baseType(col);
  switch (t) {
    case "Ref":
      return refText(col, v, depth);
    case "RefList":
      return isList(v)
        ? v
            .slice(1)
            .map((id) => refText(col, id, depth))
            .join(", ")
        : "";
    case "ChoiceList":
      return isList(v) ? v.slice(1).join(", ") : String(v);
    case "Attachments": {
      const n = isList(v) ? v.length - 1 : 0;
      return n ? `${n} pièce${n > 1 ? "s" : ""} jointe${n > 1 ? "s" : ""}` : "";
    }
    case "Bool":
      return v ? "Oui" : "Non";
    case "Date":
      return typeof v === "number"
        ? new Date(v * 1000).toLocaleDateString("fr-FR", { timeZone: "UTC" })
        : String(v);
    case "DateTime":
      return typeof v === "number"
        ? new Date(v * 1000).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })
        : String(v);
    case "Numeric":
    case "Int":
      return typeof v === "number" ? fmtNum(v, opts, t) : String(v);
    default:
      if (isList(v)) return v.slice(1).join(", ");
      if (typeof v === "object") return JSON.stringify(v);
      return String(v);
  }
}
// chip — Pastille colorée d'un choix (Choice/ChoiceList), avec les couleurs définies dans Grist.
function chip(val, opts) {
  const o = opts.choiceOptions?.[val] || {};
  const st = (o.fillColor ? `background:${o.fillColor};` : "") + (o.textColor ? `color:${o.textColor};` : "");
  return `<span class="chip" style="${esc(st)}">${esc(val)}</span>`;
}
// htmlOf — HTML d'une cellule pour un champ : texte formaté + pastilles + lien vers la fiche des références.
function htmlOf(f, v) {
  const t = baseType(f.col);
  if (isErr(v)) return `<span style="color:var(--rouge)">${esc(textOf(f.col, f.opts, v))}</span>`;
  // booléen : interrupteur si la colonne est réglée ainsi dans Grist (0.9.5.8), sinon coche
  if (t === "Bool")
    return f.opts?.widget === "Switch"
      ? `<span class="sw${v ? " on" : ""}" role="img" aria-label="${v ? "Oui" : "Non"}"><i></i></span>`
      : v
        ? '<span class="ok">✔</span>'
        : '<span class="ko">—</span>';
  // lien hypertexte (widget « HyperLink » de Grist, 0.9.6.5) : « texte adresse », l'adresse étant le dernier mot
  if (f.opts?.widget === "HyperLink" && typeof v === "string" && v.trim()) {
    const s = v.trim(),
      i = s.lastIndexOf(" "),
      url = i < 0 ? s : s.slice(i + 1),
      label = i < 0 ? s : s.slice(0, i).trim() || url;
    if (/^(https?:\/\/|mailto:|tel:)/i.test(url))
      return `<a class="hlink" href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="${esc(url)}">${esc(label)}</a>`;
  }
  if (t === "Choice" && !isEmpty(v)) return chip(v, f.opts);
  if (t === "ChoiceList" && isList(v))
    return v
      .slice(1)
      .map((x) => chip(x, f.opts))
      .join("");
  if (t === "Ref" && v) return `${rlink(refTarget(f.col), v)}${esc(textOf(f.col, f.opts, v))}`;
  if (t === "RefList" && isList(v))
    return v
      .slice(1)
      .map((id) => `<span class="chip">${rlink(refTarget(f.col), id)}${esc(refText(f.col, id, 0))}</span>`)
      .join("");
  return esc(textOf(f.col, f.opts, v));
}
const LINK_SVG =
  '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M18.36 15.53 17 14.12l1.41-1.41a5 5 0 1 0-7.07-7.07L9.88 7.05 8.47 5.64l1.41-1.42a7 7 0 0 1 9.9 9.9l-1.42 1.41Zm-2.83 2.83-1.42 1.41a7 7 0 0 1-9.9-9.9l1.42-1.41L7.05 9.88 5.64 11.3a5 5 0 1 0 7.07 7.07l1.41-1.41 1.41 1.41Zm-.71-10.6 1.42 1.42-7.07 7.07-1.42-1.42 7.07-7.07Z"/></svg>';
// rlink — Petit lien qui ouvre la fiche de l'enregistrement référencé (fenêtre superposée).
const rlink = (table, id) =>
  table && id
    ? `<a class="rlink" data-rt="${esc(table)}" data-rr="${id}" title="Ouvrir la fiche" tabindex="0">${LINK_SVG}</a>`
    : "";

/* ---------- Fiche d'un enregistrement référencé (fenêtre superposée) ---------- */
const rcHist = [];
// openRecordCard — Ouvre la fiche (vue « carte d'enregistrement » de Grist) d'une ligne référencée, par-dessus la page.
async function openRecordCard(tableId, rowId, push = true) {
  const tbl = [...S.meta.tables.values()].find((t) => t.tableId === tableId);
  if (!tbl) return;
  await fetchRows(tableId);
  const row = S.byId[tableId]?.get(rowId);
  // fiche « Record card » définie dans Grist pour la table, sinon toutes ses colonnes
  let info = tbl.recordCardViewSectionRef ? getInfo(tbl.recordCardViewSectionRef) : null;
  if (!info || !info.fields.length) {
    const cols = (S.meta.colsByTable.get(tbl.id) || []).filter(
      (c) => !c.colId.startsWith("gristHelper_") && c.colId !== "manualSort",
    );
    info = {
      secId: -tbl.id,
      tableId,
      sec: {},
      opts: {},
      fields: cols.map((col) => ({
        col,
        colId: col.colId,
        label: col.label || col.colId,
        opts: parseJSON(col.widgetOptions),
      })),
    };
  }
  await ensureRefTables(info.fields.map((f) => f.col));
  if (push) rcHist.push([tableId, rowId]);
  const vis =
    (S.meta.colsByTable.get(tbl.id) || []).find((c) => /^(nom|name|libell|titre)/i.test(c.colId)) ||
    info.fields[0]?.col;
  const title = row && vis ? textOf(vis, parseJSON(vis.widgetOptions), row[vis.colId]) : `n°${rowId}`;
  $("#rc").innerHTML =
    `<div class="rch">${rcHist.length > 1 ? '<button class="icon-btn" data-rcback title="Fiche précédente">←</button>' : ""}
    <h3>${esc(title)} <small>· ${esc(tableId)}</small></h3><button class="icon-btn" data-rcclose title="Fermer (Échap)">✕</button></div>
    <div class="rcb">${row ? ficheHTML(info, row) : '<div class="msg">Enregistrement introuvable (supprimé ou non autorisé)</div>'}</div>`;
  $("#rc").classList.add("on");
  $("#rcBack").classList.add("on");
}
// closeRecordCard — Ferme la fiche superposée.
function closeRecordCard() {
  rcHist.length = 0;
  $("#rc").classList.remove("on");
  $("#rcBack").classList.remove("on");
}
// isNumCol — Colonne numérique (alignée à droite, triée comme un nombre).
const isNumCol = (col) => ["Numeric", "Int"].includes(baseType(col));

/* ---------- Mise en forme Grist (styles de cellule, règles conditionnelles) ---------- */
function refList(v) {
  if (isList(v)) return v.slice(1);
  if (Array.isArray(v)) return v;
  const a = parseJSON(v, []);
  return Array.isArray(a) ? (a[0] === "L" ? a.slice(1) : a) : [];
}
const STYLE_KEYS = ["textColor", "fillColor", "fontBold", "fontItalic", "fontUnderline", "fontStrikethrough"];
// styleSet — Valeur de style à appliquer ? (0.9.6.2) Gras, italique, souligné, barré : seulement s'ils sont actifs.
//   Grist enregistre « false » quand on décoche ; ce « false » ne doit pas annuler le style de la ligne.
const styleSet = (k, v) => v !== undefined && v !== null && v !== "" && (!k.startsWith("font") || v === true);
// applyRules — Applique les règles de mise en forme conditionnelle de Grist (colonne ou ligne) à une ligne donnée.
function applyRules(base, rules, rulesOptions, row) {
  const st = { ...base };
  // la règle la plus haute dans la liste l'emporte : on applique de bas en haut
  for (let i = rules.length - 1; i >= 0; i--) {
    const rc = S.meta.cols.get(rules[i]);
    if (rc && row[rc.colId] === true)
      for (const k of STYLE_KEYS)
        if (styleSet(k, rulesOptions?.[i]?.[k])) st[k] = rulesOptions[i][k];
  }
  return st;
}
// styleCss — Convertit les options de style Grist (couleurs, gras, italique…) en CSS en ligne.
function styleCss(st, bgOnly = false) {
  let c = "";
  if (st.fillColor) c += `background:${st.fillColor};`;
  if (bgOnly) return c;
  if (st.textColor) c += `color:${st.textColor};`;
  if (st.fontBold) c += "font-weight:700;";
  if (st.fontItalic) c += "font-style:italic;";
  const deco = [st.fontUnderline && "underline", st.fontStrikethrough && "line-through"]
    .filter(Boolean)
    .join(" ");
  if (deco) c += `text-decoration:${deco};`;
  return c;
}
// rowRulesOf — Règles de style de ligne d'une vue (0.9.6.4) : celles de la vue, sinon celles de la vue des données
//   brutes de la table (rawViewSectionRef), que Grist applique aussi aux autres vues ; [règles, options, origine].
function rowRulesOf(info) {
  const own = refList(info.sec.rules);
  if (own.length) return [own, info.opts.rulesOptions || [], "vue"];
  const t = S.meta.tables.get(info.sec.tableRef);
  const raw = t?.rawViewSectionRef && t.rawViewSectionRef !== info.secId ? S.meta.sections.get(t.rawViewSectionRef) : null;
  const rr = raw ? refList(raw.rules) : [];
  if (rr.length) return [rr, parseJSON(raw.options).rulesOptions || [], "données brutes"];
  return [[], [], ""];
}
// diagRowRules — Diagnostic (0.9.6.3), une fois par vue : règles de style de ligne trouvées et colonnes de calcul.
const rowRulesSeen = new Set();
function diagRowRules(info, rows) {
  if (rowRulesSeen.has(info.secId)) return;
  rowRulesSeen.add(info.secId);
  const [rules, ro, from] = rowRulesOf(info);
  if (!rules.length) {
    console.info(`[UX widget] style de ligne « ${info.title} » : aucune règle (ni sur la vue n°${info.secId}, ni sur les données brutes de ${info.tableId})`);
    return;
  }
  const parts = rules.map((id, i) => {
    const rc = S.meta.cols.get(id);
    if (!rc) return `règle ${i + 1} : colonne n°${id} introuvable dans la structure`;
    const has = rows.length && rc.colId in rows[0];
    const yes = has ? rows.filter((r) => r[rc.colId] === true).length : 0;
    return `règle ${i + 1} : ${rc.colId} ${has ? `vraie pour ${yes} ligne(s) sur ${rows.length}` : "absente des données lues"} ; style ${JSON.stringify(ro?.[i] || {})}`;
  });
  console.info(`[UX widget] style de ligne « ${info.title} » : ${rules.length} règle(s) (${from}) ; ${parts.join(" | ")}`);
}
// rowStyle — Style de toute une ligne (règles conditionnelles de ligne de la vue).
function rowStyle(info, row) {
  const base = {}; // style de ligne par défaut, s'il est défini sur le widget
  for (const k of STYLE_KEYS) if (styleSet(k, info.opts[k])) base[k] = info.opts[k];
  const [rules, ro] = rowRulesOf(info);
  return rules.length ? applyRules(base, rules, ro, row) : base;
}
// cellStyle — Style d'une cellule : style du champ, de la colonne, puis règles conditionnelles.
function cellStyle(f, row, rowSt = {}) {
  const o = f.opts;
  const base = { ...rowSt };
  for (const k of STYLE_KEYS) if (styleSet(k, o[k])) base[k] = o[k];
  const fRules = refList(f.field?.rules);
  const rules = fRules.length ? fRules : refList(f.col.rules);
  let css = styleCss(applyRules(base, rules, o.rulesOptions || [], row));
  if (o.alignment) css += `text-align:${o.alignment};`;
  if (o.wrap) css += "white-space:pre-line;"; // retour à la ligne de Grist : le texte s'enroule ET garde ses sauts de ligne
  return css;
}
// headerCss — Style de l'en-tête d'une colonne (couleurs d'en-tête définies dans Grist).
function headerCss(f) {
  const o = f.opts;
  return styleCss({
    textColor: o.headerTextColor,
    fillColor: o.headerFillColor,
    fontBold: o.headerFontBold,
    fontItalic: o.headerFontItalic,
    fontUnderline: o.headerFontUnderline,
    fontStrikethrough: o.headerFontStrikethrough,
  });
}

/* ---------- Filtres, tri, liaisons ---------- */
const same = (a, b) => (a ?? "") === (b ?? "");
// norm — null/undefined → "" pour comparer des valeurs.
const norm = (x) => x ?? "";
// passFilter — Vrai si une ligne passe le filtre enregistré d'une colonne (format _grist_Filters : included/excluded).
function passFilter(spec, v) {
  // listes de valeurs du filtre transformées une fois en ensembles (évite un coût lignes × valeurs)
  if (Array.isArray(spec.included) && !spec._inc) spec._inc = new Set(spec.included.map(norm));
  if (Array.isArray(spec.excluded) && !spec._exc) spec._exc = new Set(spec.excluded.map(norm));
  const vals = isList(v) ? (v.length > 1 ? v.slice(1) : [null]) : [v];
  if (spec._inc && !vals.some((x) => spec._inc.has(norm(x)))) return false;
  if (spec._exc && !vals.some((x) => !spec._exc.has(norm(x)))) return false;
  if (typeof spec.min === "number" && !(typeof v === "number" && v >= spec.min)) return false;
  if (typeof spec.max === "number" && !(typeof v === "number" && v <= spec.max)) return false;
  return true;
}
// cmp — Comparaison pour le tri : nombres, dates, puis texte en ordre alphabétique français (COLL).
function cmp(a, b) {
  const ea = isEmpty(a),
    eb = isEmpty(b);
  if (ea || eb) return ea === eb ? 0 : ea ? -1 : 1;
  if (typeof a === "number" && typeof b === "number") return a - b;
  return COLL.compare(String(a), String(b));
}
const COLL = new Intl.Collator("fr", { numeric: true });
// sortRows — Trie les lignes selon le tri de la vue Grist (sortColRefs, avec sens).
function sortRows(info, rows) {
  const pos = (r) => r.manualSort ?? r.id;
  if (!info.sort.length) return rows.slice().sort((a, b) => pos(a) - pos(b));
  const key = (k, r) => {
    const v = r[k.col.colId];
    return ["Ref", "RefList", "ChoiceList"].includes(baseType(k.col)) ? textOf(k.col, k.opts, v) : v;
  };
  return rows
    .map((r) => ({ r, k: info.sort.map((s) => key(s, r)) }))
    .sort((a, b) => {
      for (let i = 0; i < info.sort.length; i++) {
        const c = cmp(a.k[i], b.k[i]);
        if (c) return info.sort[i].desc ? -c : c;
      }
      return pos(a.r) - pos(b.r);
    })
    .map((x) => x.r);
}

// ensureRefTables — Charge les tables ciblées par des colonnes Ref/RefList (et leurs colonnes d'affichage, sur 2 niveaux).
async function ensureRefTables(cols, depth = 0) {
  const targets = [
    ...new Set(
      cols
        .filter((c) => ["Ref", "RefList"].includes(baseType(c)))
        .map(refTarget)
        .filter(Boolean),
    ),
  ];
  await Promise.all(targets.map((t) => fetchRows(t).catch(() => null)));
  if (depth < 2) {
    const vis = cols
      .filter((c) => ["Ref", "RefList"].includes(baseType(c)) && c.visibleCol)
      .map((c) => S.meta.cols.get(c.visibleCol))
      .filter(Boolean);
    if (vis.length) await ensureRefTables(vis, depth + 1);
  }
}
// prepareSection — Charge tout ce qu'il faut pour afficher une vue : sa table et les tables référencées.
async function prepareSection(info) {
  await fetchRows(info.tableId);
  await ensureRefTables([...info.fields.map((f) => f.col), ...info.sort.map((s) => s.col)]);
}

// isRendered — Vrai si la vue fait partie des blocs de la configuration courante.
const isRendered = (secId) => S.cfg.blocks.some((b) => b.id === secId);

// rowsFor — Lignes à afficher pour une vue : table filtrée par la liaison (sélection d'une autre vue), les filtres et le tri. Mis en cache dans ctx pour un rendu.
async function rowsFor(secId, ctx, depth = 0) {
  ctx.pending ??= new Set();
  if (ctx.pending.has(secId))
    return rowsFor(secId, { rows: (ctx.cycleRows ??= new Map()), pending: new Set(), noLink: true }, depth);
  if (ctx.rows.has(secId)) return ctx.rows.get(secId);
  ctx.pending.add(secId);
  const p = (async () => {
    const info = getInfo(secId);
    if (!info?.tableId) throw new Error("Table introuvable");
    await prepareSection(info);
    let rows = (await fetchRows(info.tableId)).filter((r) =>
      info.filters.every((f) => passFilter(f.spec, r[f.col.colId])),
    );
    let focus = null;
    const link = depth < 8 && !ctx.noLink ? await linkFor(info, ctx, depth) : null;
    if (link?.filter) rows = rows.filter(link.filter);
    if (!ctx.noLink) (S.linkSet ??= {})[secId] = link?.set || null;
    if (link && "focus" in link) focus = link.focus;
    return { rows: sortRows(info, rows), focus };
  })().finally(() => ctx.pending.delete(secId));
  ctx.rows.set(secId, p);
  return p;
}

// selectedRowId — Ligne « sélectionnée » d'une vue (curseur) : choix de l'utilisateur, sinon sélection reçue de Grist, sinon première ligne.
async function selectedRowId(secId, ctx, depth = 0) {
  const { rows, focus } = await rowsFor(secId, ctx, depth);
  if (focus) return focus;
  const sel = S.sel[secId];
  if (sel && rows.some((r) => r.id === sel)) return sel;
  if (!isRendered(secId) && S.extSel.has(secId)) return S.extSel.get(secId);
  return rows[0]?.id || 0;
}

// summaryPairs — Couples de colonnes qui relient une table de synthèse à sa table source (ou à une autre synthèse).
function summaryPairs(src, tgt) {
  const sT = src.sec.tableRef,
    tT = tgt.sec.tableRef;
  const sG = groupCols(sT);
  if (!sG) return [];
  const base = S.meta.tables.get(sT).summarySourceTable;
  let tMap;
  if (tT === base) tMap = new Map((S.meta.colsByTable.get(base) || []).map((c) => [c.id, c.colId]));
  else if (S.meta.tables.get(tT)?.summarySourceTable === base) tMap = groupCols(tT);
  else return [];
  const pairs = [];
  for (const [ref, sc] of sG) {
    const tc = tMap.get(ref);
    if (!tc) return [];
    pairs.push([sc, tc]);
  }
  return pairs;
}

// linkFor — Calcule le filtre imposé à une vue par sa vue source (liaison Grist : linkSrcSectionRef / colonnes de liaison).
async function linkFor(info, ctx, depth) {
  const sec = info.sec,
    srcId = sec.linkSrcSectionRef;
  if (!srcId) return null;
  const src = getInfo(srcId);
  if (!src?.tableId) return null;
  const srcRowId = await selectedRowId(srcId, ctx, depth + 1);
  const srcRow = S.byId[src.tableId]?.get(srcRowId);
  if (!srcRow) return { filter: () => false };
  const sCol = sec.linkSrcColRef ? S.meta.cols.get(sec.linkSrcColRef)?.colId : null;
  const tCol = sec.linkTargetColRef ? S.meta.cols.get(sec.linkTargetColRef)?.colId : null;

  if (tCol) {
    // filtrage : cible.col = source.col (ou = ligne source)
    const val = sCol ? srcRow[sCol] : srcRowId;
    const vset = isList(val) ? new Set(val.slice(1)) : null;
    // valeur donnée à une ligne ajoutée dans ce bloc, pour qu'elle reste liée à la sélection
    const tType = baseType(S.meta.cols.get(sec.linkTargetColRef));
    const set =
      vset || val == null || val === "" ? null : { [tCol]: tType === "RefList" || tType === "ChoiceList" ? ["L", val] : val };
    return {
      set,
      filter: (r) => {
        const tv = r[tCol];
        if (isList(tv)) {
          for (let k = 1; k < tv.length; k++) if (vset ? vset.has(tv[k]) : tv[k] === val) return true;
          return false;
        }
        if (vset) return vset.has(tv);
        return same(tv, val);
      },
    };
  }
  if (sCol) {
    // curseur : fiche de l'enregistrement référencé
    const v = srcRow[sCol];
    return isList(v) ? { filter: (r) => v.slice(1).includes(r.id) } : { focus: v || 0 };
  }
  if (src.tableId === info.tableId) return { focus: srcRowId }; // même table : même ligne
  const pairs = summaryPairs(src, info); // tables de synthèse
  if (pairs.length) return { filter: (r) => pairs.every(([sc, tc]) => same(r[tc], srcRow[sc])) };
  return null;
}

/* ---------- Rendu ---------- */
const HEIGHTS = { mini: 130, compact: 200, grand: 460, tresgrand: 640 };
// gridPlacement — Position d'un bloc dans la grille de 6 colonnes (largeur, colonne de départ, nombre de rangées).
function gridPlacement(b, kind) {
  const start = b.newLine ? 1 : b.start || 0;
  const w = Math.min(b.width || DEFAULT_WIDTH[kind] || 3, start ? 7 - start : 6);
  let st = `grid-column:${start ? `${start} / span ${w}` : `span ${w}`};`;
  if ((b.rows || 1) > 1 && !S.cfg.masonry) st += `grid-row:span ${b.rows};align-self:stretch;`;
  return st;
}
// fluxPlacement — Largeur d'un bloc en mode ultracompact (flux) : ajustée au contenu ou en sixièmes.
function fluxPlacement(b, kind) {
  const n = b.fw || 0;
  if (n) return `flex:0 0 calc(${n} * (100% + var(--gap)) / 6 - var(--gap));min-width:0;`;
  if (kind === "chart" || kind === "custom") return "flex:1 1 320px;min-width:260px;max-width:100%;";
  if (kind === "detail") return "flex:1 1 480px;max-width:100%;";
  if (kind === "single") return "flex:0 1 auto;width:max-content;max-width:min(100%, 560px);";
  return "flex:0 1 auto;width:max-content;max-width:100%;";
}
// placement — Placement CSS d'un bloc selon le mode de mise en page.
function placement(b, kind, flux) {
  return flux ? fluxPlacement(b, kind) : gridPlacement(b, kind);
}
// blockStyle — Variables CSS du bloc (hauteur, largeur des fiches, nombre de rangées) + placement.
function blockStyle(b, kind) {
  const CW = { s: 180, m: 240, l: 340, xl: 460 };
  return (
    placement(b, kind, !!S.cfg.flux) +
    (HEIGHTS[b.height] ? `--h:${HEIGHTS[b.height]}px;` : "") +
    (CW[b.cardW] ? `--cw:${CW[b.cardW]}px;` : "") +
    (!S.cfg.flux && (b.rows || 1) > 1 ? `--rows:${b.rows};` : "") +
    (!S.cfg.flux ? `--span:${Math.min(b.width || DEFAULT_WIDTH[kind] || 3, 6)};` : "") // largeur à l'impression
  );
}
// état replié initial : option du bloc, sinon graphiques repliés (cartes et autres vues dépliées)
function initialFold(b, info) {
  if (b.startFold === "fold") return true;
  if (b.startFold === "open") return false;
  return (
    info.kind === "chart" ||
    (info.kind === "custom" && !isMapSection(info.sec) && !isMarkdownSection(info.sec) && !isSelector(b))
  );
}
/* ---------- Filtre rapide (un par bloc) ----------
   Chaque bloc peut recevoir, dans son en-tête, un sélecteur « Tous | valeur 1 | valeur 2… » sur un champ
   choisi dans sa configuration (b.qfField, ex. « Reseau »), avec une valeur à l'ouverture (b.qfDefault).
   Le filtre n'agit que sur l'affichage du bloc, pas sur les liaisons. */
const QF_KINDS = ["record", "detail", "chart", "custom"]; // + fiches affichées en liste
const QF_ICON = '<svg class="qf-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4-2v-4z"/></svg>';
// fitQf — Choisit la présentation du filtre rapide de chaque bloc selon la place disponible dans l'en-tête :
//   on garde au titre au moins 140 px (ou sa largeur entière s'il est plus court).
function fitQf(root = document) {
  for (const q of root.querySelectorAll(".bh .qf")) {
    const h2 = q.closest(".bh").querySelector(".bt");
    const need = () => h2.clientWidth < Math.min(h2.scrollWidth, 140);
    // beaucoup de valeurs : jamais de boutons côte à côte, mais la valeur active et sa liste (comme sur petit écran)
    for (const mode of q.dataset.many ? ["compact", "icon"] : ["full", "compact", "icon"]) {
      q.classList.remove("full", "compact", "icon");
      q.classList.add(mode);
      if (!need()) break;
    }
  }
}
// qfClose — Ferme la liste ouverte d'un filtre rapide compact.
function qfClose() {
  document.querySelectorAll(".qf.open").forEach((q) => q.classList.remove("open"));
}
// qfToggle — Ouvre la liste verticale des options sous le bouton (position fixe : non coupée par le bloc).
function qfToggle(btn) {
  const q = btn.closest(".qf"),
    was = q.classList.contains("open");
  qfClose();
  if (was) return;
  q.classList.add("open");
  const r = btn.getBoundingClientRect(),
    opts = q.querySelector(".qf-opts");
  opts.style.top = `${r.bottom + 2}px`;
  opts.style.left = `${Math.max(4, Math.min(r.right - opts.offsetWidth, window.innerWidth - opts.offsetWidth - 4))}px`;
}
new ResizeObserver(() => fitQf()).observe(document.documentElement); // largeur du widget modifiée
document.addEventListener("mousedown", (e) => { if (!e.target.closest(".qf")) qfClose(); });
window.addEventListener("scroll", qfClose, true);
// qfCol — Colonne du filtre rapide dans la table d'un bloc (null si le champ est absent ou non configuré).
// Deux filtres rapides par bloc (0.8.10.1) : emplacement k = 1 (qfField, qfDefault) ou 2 (qfField2, qfDefault2).
// 3ᵉ filtre, « libre » (0.9.4.7, option qfFree) : la colonne est choisie par l'utilisateur dans l'en-tête du bloc
const qfFieldOf = (b, k = 1) => (k === 3 ? (b.qfFree ? S.qfFreeCol?.[b.id] : "") : k === 2 ? b.qfField2 : b.qfField);
const qfKey = (b, k = 1) => (k === 3 ? `${b.id}:3` : k === 2 ? `${b.id}:2` : b.id); // clé du choix de l'utilisateur dans S.qf
// valeurs exclues par l'administrateur (0.8.11.1) : retirées des boutons ET des lignes affichées
const qfExclOf = (b, k = 1) => (k === 3 ? [] : (k === 2 ? b.qfExclude2 : b.qfExclude) || []);
const qfExcluded = (b, k, text) => qfExclOf(b, k).some((x) => qfSame(x, text));
function qfCol(b, info, k = 1) {
  const id = qfFieldOf(b, k);
  if (!id || !(QF_KINDS.includes(info.kind) || (info.kind === "single" && b.asList))) return null;
  return (S.meta.colsByTable.get(info.sec.tableRef) || []).find((c) => c.colId === id) || null;
}
// qfText — Valeur d'une ligne pour le filtre rapide, telle qu'affichée (« (vide) » si vide).
const qfText = (col, r) => String(textOf(col, parseJSON(col.widgetOptions), r[col.colId]) ?? "").trim() || "(vide)";
// qfSame — Égalité de deux valeurs sans tenir compte des majuscules ni des accents (« Privé » = « PRIVE »).
const qfSame = (a, b) => a.localeCompare(b, "fr", { sensitivity: "base" }) === 0;
// qfCur — Valeur active pour un bloc : choix de l'utilisateur pendant la session, sinon valeur à l'ouverture
//   du bloc, sinon « Tous » (""). S.qf est vidé à chaque enregistrement de la configuration.
function qfCur(b, k = 1) {
  const key = qfKey(b, k);
  return S.qf[key] !== undefined ? S.qf[key] : k === 3 ? "" : (k === 2 ? b.qfDefault2 : b.qfDefault) || "";
}
// qfSync — Applique la valeur choisie à tous les blocs de la page dont le filtre rapide porte sur le même
//   champ (même identifiant de colonne ou même libellé) : clic milieu ou Maj+clic sur une valeur.
let qfLast = null; // dernier choix d'une valeur de filtre rapide (détection du double clic / double toucher)
function qfSync(fromId, v, fromK = 1) {
  const src = S.cfg.blocks.find((x) => x.id === fromId),
    srcInfo = src && getInfo(src.id),
    col = src && srcInfo && qfCol(src, srcInfo, fromK);
  if (!col) return;
  let n = 0;
  for (const b of S.cfg.blocks) {
    const info = getInfo(b.id);
    if (!info) continue;
    for (const k of [1, 2]) {
      const c = qfCol(b, info, k);
      if (c && (c.colId === col.colId || (c.label && c.label === col.label))) {
        S.qf[qfKey(b, k)] = v;
        n++;
      }
    }
  }
  qfClose();
  scheduleRender();
  // message après le rendu (qui efface la ligne d'état)
  setTimeout(() => status(`Filtre « ${col.label || col.colId} » : ${v || "Tous"} — appliqué à ${n} bloc${n > 1 ? "s" : ""}`), 400);
  setTimeout(() => status(""), 3500);
}
// qfValuesOf — Valeurs connues d'un champ pour la configuration : choix déclarés dans Grist + données déjà chargées.
function qfValuesOf(cols) {
  const vals = new Set();
  for (const c of cols) {
    for (const ch of parseJSON(c.widgetOptions)?.choices || []) vals.add(String(ch));
    const t = S.meta.tables.get(c.parentId)?.tableId;
    for (const r of S.byId[t]?.values() || []) vals.add(qfText(c, r));
  }
  vals.delete("(vide)");
  return [...vals].sort(COLL.compare).slice(0, 200);
}
// qfApply — Ne garde que les lignes dont le champ vaut la valeur choisie pour ce bloc.
function qfApply(b, info, rows) {
  // les filtres se cumulent : 1er, 2ᵉ, puis filtre libre
  return qfApplyOne(b, info, qfApplyOne(b, info, qfApplyOne(b, info, qfDropExcluded(b, info, rows), 1), 2), 3);
}
// qfDropExcluded — Retire les lignes dont un champ de filtre rapide vaut une valeur exclue.
function qfDropExcluded(b, info, rows) {
  for (const k of [1, 2]) {
    const col = qfCol(b, info, k);
    if (col && qfExclOf(b, k).length) rows = rows.filter((r) => !qfExcluded(b, k, qfText(col, r)));
  }
  return rows;
}
function qfApplyOne(b, info, rows, k) {
  if (k === 3) {
    // filtre libre : plusieurs valeurs cochées
    const c3 = qfCol(b, info, 3),
      list = qf3List(b);
    return c3 && list.length ? rows.filter((r) => list.some((x) => qfSame(qfText(c3, r), x))) : rows;
  }
  const col = qfCol(b, info, k),
    v = qfCur(b, k);
  if (!col || !v) return rows;
  const texts = rows.map((r) => qfText(col, r));
  if (texts.some((t) => qfSame(t, v))) return rows.filter((r, i) => qfSame(texts[i], v)); // valeur présente : égalité
  // valeur absente de ce bloc (filtre synchronisé depuis un autre bloc) : on rapproche par le début du texte,
  // mot entier. « Privé » garde « Privé sous contrat » et « Privé hors contrat » ; à l'inverse,
  // « Privé sous contrat » garde « Privé ».
  const n = qfNorm(v);
  return rows.filter((r, i) => {
    const t = qfNorm(texts[i]);
    return t.startsWith(`${n} `) || n.startsWith(`${t} `);
  });
}
// qfNorm — Texte sans majuscules ni accents, espaces simplifiés (pour le rapprochement par le début).
const qfNorm = (x) =>
  String(x)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
// qfHtml — Sélecteurs de l'en-tête : boutons « Tous | valeurs » ; au-delà de 4 valeurs, valeur active et liste au clic.
function qfHtml(b, info, allRows) {
  return qfHtmlOne(b, info, allRows, 1) + qfHtmlOne(b, info, allRows, 2);
}
// qfRowHtml — Seconde ligne de l'en-tête (0.9.4.9) : filtre libre (colonne, puis valeurs à cocher).
const qfRowHtml = (b, info, allRows) => qfFreeHtml(b, info) + qfMultiHtml(b, info, allRows);
// qf3List — Valeurs cochées du filtre libre (tableau ; vide = toutes).
const qf3List = (b) => (Array.isArray(S.qf[qfKey(b, 3)]) ? S.qf[qfKey(b, 3)] : []);
// qfMultiHtml — Filtre libre : bouton « valeurs ▾ » et liste à cocher (plusieurs valeurs possibles), appliquée à la
//   fermeture de la liste ou par « Appliquer ».
function qfMultiHtml(b, info, allRows) {
  const col = qfCol(b, info, 3);
  if (!col) return "";
  const cur = qf3List(b);
  const vals = [...new Set(allRows.map((r) => qfText(col, r)))].sort((x, y) => (x === "(vide)") - (y === "(vide)") || COLL.compare(x, y));
  const shown = (v) => (v === "(vide)" ? "(sans valeur)" : v);
  const name = col.label || col.colId;
  const label = !cur.length ? "Toutes les valeurs" : cur.length <= 2 ? cur.map(shown).join(", ") : `${cur.length} valeurs`;
  const pr = cur.length ? `<span class="qf-print">${esc(name)} : ${esc(cur.map(shown).join(", "))}</span>` : "";
  return `${pr}<span class="qf3m${cur.length ? " active" : ""}" data-qf3box="${b.id}">
    <button type="button" class="qf3-tog" data-qf3tog="${b.id}" title="Valeurs de « ${esc(name)} » à afficher (plusieurs possibles)" aria-haspopup="true">${QF_ICON}<span class="qf-lab">${esc(label)}</span><span class="qf-caret">▾</span></button>
    <span class="qf3-panel" hidden><span class="qf3-act"><button type="button" data-qf3all="${b.id}">Toutes</button><button type="button" class="primary" data-qf3ok="${b.id}">Appliquer</button></span>${vals
      .map((v) => `<label><input type="checkbox" data-qf3="${b.id}" value="${esc(v)}" ${cur.some((x) => qfSame(x, v)) ? "checked" : ""}> ${esc(shown(v))}</label>`)
      .join("")}</span></span>`;
}
// qf3Open / qf3Close — Ouvre la liste à cocher (position fixe, non coupée par le bloc) ; à la fermeture, les cases
//   cochées deviennent le filtre (rendu seulement si le choix a changé).
function qf3Open(btn) {
  const box = btn.closest(".qf3m"),
    panel = box.querySelector(".qf3-panel");
  const was = !panel.hidden;
  qf3Close();
  if (was) return;
  panel.hidden = false;
  box.classList.add("open");
  const r = btn.getBoundingClientRect();
  panel.style.top = `${r.bottom + 2}px`;
  panel.style.left = `${Math.max(4, Math.min(r.left, window.innerWidth - panel.offsetWidth - 4))}px`;
}
function qf3Close() {
  for (const box of document.querySelectorAll(".qf3m.open")) {
    box.classList.remove("open");
    box.querySelector(".qf3-panel").hidden = true;
    const id = Number(box.dataset.qf3box),
      b = S.cfg.blocks.find((x) => x.id === id);
    if (!b) continue;
    const list = [...box.querySelectorAll("[data-qf3]:checked")].map((x) => x.value);
    const old = qf3List(b);
    if (list.length !== old.length || list.some((v) => !old.some((x) => qfSame(x, v)))) {
      S.qf[qfKey(b, 3)] = list;
      scheduleRender();
    }
  }
}
document.addEventListener("mousedown", (e) => {
  if (!e.target.closest(".qf3m")) qf3Close();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") qf3Close();
});
// qfFreeCandidates — Colonnes d'une table utilisables par le filtre libre (ni techniques, ni pièces jointes).
const qfFreeCandidates = (tableRef) =>
  (S.meta.colsByTable.get(tableRef) || [])
    .filter((c) => !c.colId.startsWith("gristHelper_") && c.colId !== "manualSort" && baseType(c) !== "Attachments")
    .sort((x, y) => COLL.compare(x.label || x.colId, y.label || y.colId));
// qfFreeHtml — Filtre libre : liste des colonnes de la table, au choix de l'utilisateur (« Filtrer sur… ») ;
//   seulement celles cochées dans la configuration (qfFreeCols), toutes si aucune ne l'est.
function qfFreeHtml(b, info) {
  if (!b.qfFree || !(QF_KINDS.includes(info.kind) || (info.kind === "single" && b.asList))) return "";
  const cur = S.qfFreeCol?.[b.id] || "";
  const only = b.qfFreeCols?.length ? new Set(b.qfFreeCols) : null;
  const cols = qfFreeCandidates(info.sec.tableRef).filter((c) => !only || only.has(c.colId));
  return `<select class="qffree" data-qfcol="${b.id}" title="Filtrer ce bloc sur une colonne de votre choix, puis sur une de ses valeurs" aria-label="Filtrer sur une colonne">
    <option value="">${cur ? "✕ Retirer le filtre" : "Filtrer sur…"}</option>${cols
      .map((c) => `<option value="${esc(c.colId)}" ${c.colId === cur ? "selected" : ""}>${esc(c.label || c.colId)}</option>`)
      .join("")}</select>`;
}
function qfHtmlOne(b, info, allRows, k) {
  const col = qfCol(b, info, k);
  if (!col) return "";
  const cur = qfCur(b, k);
  // lignes sans valeur : 1er filtre → option « (SO) » (sans objet), placée en dernier ;
  // 2nd filtre → pas d'option (ces lignes restent visibles avec « Tous »)
  // bloc sans aucune donnée : le filtre reste affiché, avec les valeurs connues du champ (choix Grist, table chargée)
  const noData = !allRows.length;
  const vals = [...new Set(noData ? qfValuesOf([col]).filter((v) => !qfExcluded(b, k, v)) : qfDropExcluded(b, info, allRows).map((r) => qfText(col, r)))]
    .filter((v) => k === 1 || v !== "(vide)")
    .sort((x, y) => (x === "(vide)") - (y === "(vide)") || COLL.compare(x, y));
  const shown = (v) => (v === "(vide)" ? "(SO)" : v); // libellé affiché
  // valeur synchronisée absente de ce bloc (« Privé » alors que le bloc a « Privé sous contrat »…) :
  // pas de bouton supplémentaire ; les valeurs rapprochées sont surlignées (voir qfApply)
  const exact = !cur || vals.some((x) => qfSame(x, cur));
  const isOn = (v) =>
    exact ? qfSame(v, cur) : qfNorm(v).startsWith(`${qfNorm(cur)} `) || qfNorm(cur).startsWith(`${qfNorm(v)} `);
  // une seule valeur dans le bloc : le filtre ne sert à rien (« Public » = « Tous »), sauf si une valeur
  // différente lui a été appliquée (synchronisation) : il reste alors affiché pour pouvoir revenir à « Tous »
  if (!noData && vals.length < 2 && (!cur || vals.every(isOn))) return "";
  const name = col.label || col.colId;
  const tip = `Filtrer ce bloc sur « ${name} »`;
  // aide au survol de chaque valeur : clic sur ce bloc, clic milieu (ou Maj+clic) sur tous les blocs
  const sync = `\nDouble clic, double toucher, clic milieu ou Maj+clic : appliquer à tous les blocs de la page filtrés sur « ${name} »`;
  const pr = cur ? `<span class="qf-print">${esc(name)} : ${esc(shown(vals.find((x) => qfSame(x, cur)) || cur))}</span>` : ""; // impression
  // trois présentations, choisies par fitQf() selon la place dans l'en-tête :
  //   « full » boutons côte à côte · « compact » seule l'option active, les autres en liste au clic
  //   · « icon » icône de filtre (pastille si un filtre est actif), liste au clic
  const label = cur ? shown(vals.find((x) => qfSame(x, cur)) || cur) : "Tous"; // valeur rapprochée : son propre texte
  const many = vals.length > 4; // au-delà de 4 valeurs : valeur active + liste au clic, comme sur petit écran
  return `${pr}<span class="qf ${many ? "compact" : "full"}${cur ? " active" : ""}${k === 3 ? " qf3" : ""}"${many ? ' data-many="1"' : ""} title="${esc(tip)}">
    <button type="button" class="qf-cur" data-qftog="${b.id}" data-qk="${k}" aria-haspopup="true" aria-label="${esc(tip)} : ${esc(label)}">${QF_ICON}<span class="qf-lab">${esc(label)}</span><span class="qf-caret">▾</span></button>
    <span class="qf-opts">${[["", "Tous"], ...vals.map((v) => [v, shown(v)])]
      .map(([v, l]) => `<button type="button" data-qf="${b.id}" data-qk="${k}" data-qv="${esc(v)}" class="${(v ? cur && isOn(v) : !cur) ? "on" : ""}" title="${esc(`Clic : ${v ? `n'afficher que « ${l} »` : "tout afficher"} dans ce bloc${sync}`)}">${esc(l)}</button>`)
      .join("")}</span></span>`;
}

const TOG_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>'; // chevron (tourné quand déplié)
// blockShell — (0.9.4.27 : icône du type de vue devant le titre d'un bloc replié) Crée le cadre d'un bloc : en-tête (titre, compteur, recherche, export, plein écran) et zone de contenu vide.
function blockShell(b, info, badge, extraHead = "", extraRow = "") {
  if (S.collapsed[b.id] === undefined) S.collapsed[b.id] = initialFold(b, info);
  const w = b.width || DEFAULT_WIDTH[info.kind] || 3;
  const el = document.createElement("section");
  el.className =
    "block" +
    (S.collapsed[b.id] && S.maxed !== b.id ? " collapsed" : "") +
    (!S.cfg.flux && (b.rows || 1) > 1 ? " tall" : "") +
    (S.maxed === b.id ? " maxed" : "") +
    (b.sticky && S.maxed !== b.id ? " sticky" : "");
  el.setAttribute("style", blockStyle(b, info.kind));
  el.dataset.sec = b.id;
  // en-tête : titre (h3, ou h2 si b.hLevel === 2) et, si b.subDesc, la description de la vue Grist en sous-titre
  //   (0.9.6.11 ; elle remplace alors le ⓘ) à gauche, chevron de pliage à droite ; un clic sur
  //   l'en-tête plie ou déplie le bloc
  const sub = b.subDesc ? String(info.sec?.description || "").trim() : "";
  el.innerHTML = `<div class="bh">
    <span class="foldico">${kindIcon(info.sec, b)}</span><div class="bht"><${b.hLevel === 2 ? "h2" : "h3"} class="bt">${esc(info.title)}</${b.hLevel === 2 ? "h2" : "h3"}>${sub ? `<div class="bsub">${esc(sub)}</div>` : ""}</div>${sub ? "" : secDescMark(info)}${extraHead}<span class="badge"></span>
    <button class="max" data-max="${b.id}" title="${S.maxed === b.id ? "Réduire (Échap)" : "Plein écran"}">${S.maxed === b.id ? "✕" : "⛶"}</button><button class="tog" data-tog="${b.id}" title="Replier / déplier" aria-label="Replier / déplier">${TOG_ICON}</button></div>${extraRow ? `<div class="bh2">${extraRow}</div>` : ""}<div class="bb"></div>`;
  return el;
}

// secDescMark — ⓘ après le titre d'un bloc quand la vue Grist a une description (« Description du widget »),
// affichée au survol (infobulle commune #tip, comme les descriptions de colonnes).
const secDescMark = (info) => {
  const d = String(info.sec?.description || "").trim();
  return d ? `<span class="info secinfo" data-desc="${esc(d)}" tabindex="0" aria-label="${esc(d)}">ⓘ</span>` : "";
};
// tableClasses — Classes CSS d'un tableau selon les options de la vue (lignes alternées, bordures…).
function tableClasses(info) {
  const o = info.opts; // valeurs par défaut de Grist : quadrillage horizontal et vertical, pas de zébrures
  return [
    o.zebraStripes ? "zebra" : "",
    o.horizontalGridlines === false ? "nohgrid" : "",
    "" /* quadrillage vertical volontairement ignoré */,
  ].join(" ");
}
let measureCtx = null;
// fitColumns — Répartit la largeur disponible entre les colonnes d'un tableau, sans ascenseur horizontal si possible.
function fitColumns(t) {
  const wrap = t.closest(".tbl-wrap");
  const avail = (S.cfg.flux ? t.closest(".grid")?.clientWidth : wrap?.clientWidth) || 0;
  const ths = [...t.querySelectorAll("thead th")];
  if (!avail || !ths.length) return false; // bloc replié : on attendra qu'il soit déplié
  measureCtx ??= document.createElement("canvas").getContext("2d");
  const firstTd = t.querySelector("tbody td");
  const bodyFont = firstTd ? getComputedStyle(firstTd).font : "12.5px Marianne, Arial, sans-serif";
  const headFont = getComputedStyle(ths[0]).font;
  const W = (txt, font) => {
    measureCtx.font = font;
    return measureCtx.measureText(txt).width;
  };
  const rows = [...t.querySelectorAll("tbody tr")].slice(0, 300);
  const cols = ths.map((th, i) => {
    const words = (th.querySelector(".ths")?.textContent || th.textContent)
      .replace(/[▲▼ⓘ]/g, "")
      .trim()
      .split(/\s+/);
    // le bouton de filtre se superpose à l'en-tête : il ne compte pas dans la largeur
    const headMin =
      Math.max(...words.map((w) => W(w, headFont))) +
      14 +
      (th.querySelector(".info") ? 10 : 0) +
      (th.querySelector(".arr")?.textContent ? 10 : 0);
    let content = 0,
      extra = 0;
    for (const tr of rows) {
      const td = tr.children[i];
      if (!td) continue;
      // liste de valeurs : la largeur minimale se règle sur la plus longue (les autres se suivent s'il reste de la place)
      const parts = td.classList.contains("multi")
        ? [...td.querySelectorAll(".chip")].map((c) => c.textContent.trim())
        : [td.textContent.trim()];
      for (const t of parts)
        content = Math.max(content, W(t, bodyFont) + (td.classList.contains("multi") ? 14 : 0));
      if (!extra && td.querySelector(".rlink")) extra += 16;
      if (td.dataset.kind === "sel") extra = Math.max(extra, 18);
    }
    const need = Math.min(Math.ceil(content) + 16 + extra, 380);
    const isWrap = th.dataset.wrap === "1";
    const min = Math.max(Math.ceil(headMin), 34);
    const full = Math.max(need, min);
    // contenu court (codes, années, nombres) : la colonne garde toujours sa largeur utile
    const floor = full <= 120 ? full : Math.max(min, isWrap ? 110 : 90);
    return { need: full, min, floor, isWrap, isText: !th.classList.contains("num") && content > 30 };
  });
  let ws = cols.map((c) => c.need);
  let total = ws.reduce((a, b) => a + b, 0);
  if (total > avail) {
    // trop large : on réduit les colonnes larges, jamais sous leur plancher
    const room = cols.map((c, i) => Math.max(0, ws[i] - Math.min(c.floor, ws[i])));
    const roomSum = room.reduce((a, b) => a + b, 0),
      excess = total - avail;
    if (roomSum > 0) ws = ws.map((w, i) => w - room[i] * Math.min(1, excess / roomSum));
  } else {
    // place disponible : elle va aux colonnes à retour à la ligne (moins de lignes)
    // à défaut, aux colonnes de texte, au prorata de leur largeur : le tableau occupe alors toute la largeur du bloc
    // (un tableau uniquement numérique garde des colonnes serrées)
    const wraps = cols.map((c, i) => (c.isWrap ? i : -1)).filter((i) => i >= 0);
    const texts = cols.map((c, i) => (c.isText ? i : -1)).filter((i) => i >= 0);
    const spare = avail - total - 2;
    if (wraps.length)
      wraps.forEach((i) => {
        ws[i] += spare / wraps.length;
      });
    else if (texts.length) {
      // les colonnes de texte grandissent d'abord, mais sans excès (au plus +120 px et 2,5 × leur besoin) ;
      // le reste est réparti sur toutes les colonnes au prorata : le tableau reste équilibré sur grand écran
      let left = spare;
      const base = texts.reduce((a, i) => a + ws[i], 0);
      texts.forEach((i) => {
        const add = Math.min((spare * ws[i]) / base, 120, ws[i] * 1.5);
        ws[i] += add;
        left -= add;
      });
      if (left > 0) {
        const all = ws.reduce((a, w) => a + w, 0);
        ws = ws.map((w) => w + (left * w) / all);
      }
    }
  }
  ws = ws.map((w) => Math.floor(w));
  const cg = document.createElement("colgroup");
  cg.innerHTML = ws.map((w) => `<col style="width:${w}px">`).join("");
  t.querySelector("colgroup")?.remove();
  t.prepend(cg);
  t.style.tableLayout = "fixed";
  t.style.width = `${ws.reduce((a, b) => a + b, 0)}px`;
  t.dataset.locked = "1";
  return true;
}
new ResizeObserver(() =>
  document.documentElement.style.setProperty("--toph", `${$("#top").offsetHeight}px`),
).observe($("#top"));
new ResizeObserver(() =>
  document.documentElement.style.setProperty("--barw", `${$(".bar").offsetWidth}px`),
).observe($(".bar"));
// renderForms — Liens de la page vers des formulaires Grist (ouverts dans un nouvel onglet).
function renderForms() {
  $("#forms").innerHTML = (S.cfg.forms || [])
    .filter((f) => safeBase(f.url))
    .map(
      (f) =>
        `<a class="tb formlink" href="${esc(safeBase(f.url))}" target="_blank" rel="noopener noreferrer"${f.tab ? "" : ` data-fmodal="${esc(f.label || "Formulaire")}"`} data-tip="${esc(f.tip || `${f.label || "Formulaire"} : ${f.tab ? "ouvre le formulaire dans un nouvel onglet" : "ouvre le formulaire"}`)}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l3 3v15H6zM9 9h6M9 13h6M9 17h4" /></svg><span class="lbl">${esc(f.label || "Formulaire")}</span></a>`,
    )
    .join("");
}
/* Formulaire dans une fenêtre : il se ferme avec ✕, Échap ou un clic à côté, et tout seul après l'envoi.
   L'envoi est repéré de deux façons, car le formulaire vient d'un autre site (son contenu est illisible) :
   - le cadre change de page (formulaire réglé dans Grist pour « rediriger après l'envoi ») ;
   - une nouvelle ligne apparaît dans la table du formulaire (si l'utilisateur peut la lire). */
const FM = { timer: 0, loads: 0, done: false };
// formTables — Tables où arrivent les réponses : celle du formulaire publié (…/forms/clé/N), ou celles
// des vues d'une page du document (…/p/N), si le lien vise bien ce document.
async function formTables(url) {
  const m = S.meta;
  const sec = Number(/\/forms\/[^/]+\/(\d+)/.exec(url)?.[1]);
  if (sec) return [m?.tables.get(m.sections.get(sec)?.tableRef)?.tableId].filter(Boolean);
  const pm = /\/(?:doc\/)?([A-Za-z0-9]{8,})(?:\/[^/?#]*)?\/p\/(\d+)/.exec(url);
  if (!pm || !m) return [];
  const docId = /\/doc\/([^/?#]+)/.exec(await guessDocUrl())?.[1] || "";
  if (!docId || !(docId.startsWith(pm[1]) || pm[1].startsWith(docId))) return []; // autre document
  return [
    ...new Set((m.sectionsByView.get(Number(pm[2])) || []).map((x) => m.tables.get(x.tableRef)?.tableId).filter(Boolean)),
  ];
}
// formRows — Empreinte des tables surveillées (nombre de lignes et plus grand identifiant de chacune).
async function formRows(tids) {
  if (!tids?.length) return null;
  const out = [];
  for (const tid of tids) {
    try {
      const ids = (await grist.docApi.fetchTable(tid)).id || [];
      out.push(`${ids.length}:${Math.max(0, ...ids)}`);
    } catch {
      out.push("?"); // table non lisible
    }
  }
  return out.every((x) => x === "?") ? null : out.join("|");
}
async function openFormModal(url, label) {
  const m = $("#fmodal"),
    fr = $("#fmFrame");
  FM.loads = 0;
  FM.done = false;
  $("#fmTitle").textContent = label;
  $("#fmTab").href = url;
  $("#fmodal .fmmsg").textContent = "";
  fr.src = url;
  m.hidden = false;
  $("#fmClose").focus();
  clearInterval(FM.timer);
  const tids = await formTables(url);
  const base = await formRows(tids);
  if (base && !m.hidden)
    FM.timer = setInterval(async () => {
      const now = await formRows(tids);
      if (now && now !== base) formSubmitted();
    }, 2000);
}
function closeFormModal() {
  clearInterval(FM.timer);
  $("#fmodal").hidden = true;
  $("#fmFrame").src = "about:blank";
  if (FM.done) refreshAll(); // la nouvelle réponse apparaît dans la page
}
function formSubmitted() {
  if (FM.done || $("#fmodal").hidden) return;
  FM.done = true;
  clearInterval(FM.timer);
  $("#fmodal .fmmsg").textContent = "✓ Réponse envoyée";
  setTimeout(() => !$("#fmodal").hidden && closeFormModal(), 1500); // le temps de lire le message de Grist
}
$("#fmFrame").addEventListener("load", () => {
  if ($("#fmFrame").src === "about:blank" || $("#fmodal").hidden) return;
  if (++FM.loads >= 2) formSubmitted(); // 2e page chargée : redirection après l'envoi
});
$("#fmClose").addEventListener("click", closeFormModal);
$("#fmodal").addEventListener("mousedown", (e) => {
  if (e.target.id === "fmodal") closeFormModal(); // clic à côté de la fenêtre
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !$("#fmodal").hidden) closeFormModal();
});
$("#forms").addEventListener("click", (e) => {
  const a = e.target.closest("a[data-fmodal]");
  if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1) return; // Ctrl+clic : nouvel onglet
  e.preventDefault();
  openFormModal(a.href, a.dataset.fmodal);
});
// menuToggle — Ouvre / ferme le menu hamburger de la barre d'outils.
function menuToggle(open = $("#tbMenu").hidden) {
  $("#tbMenu").hidden = !open;
  $("#btnMenu").setAttribute("aria-expanded", String(open));
  tip.classList.remove("on");
  if (open) $("#tbMenu .tb:not([hidden])")?.focus();
}
$("#btnMenu").addEventListener("click", (e) => {
  e.stopPropagation();
  menuToggle();
});
$("#tbMenu").addEventListener("click", (e) => {
  if (e.target.closest(".tb")) menuToggle(false); // une action choisie ferme le menu
  const a = e.target.closest("#navbtns [data-gocfg]"); // page du menu placée en bouton (0.9.6.7)
  if (a && !(e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1)) {
    e.preventDefault();
    switchConfig(a.dataset.gocfg);
  }
});
document.addEventListener("mousedown", (e) => {
  if (!$("#tbMenu").hidden && !e.target.closest("#tbMenu, #btnMenu")) menuToggle(false);
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !$("#tbMenu").hidden) {
    menuToggle(false);
    $("#btnMenu").focus();
  }
});
// infobulle immédiate des boutons quand leur texte est masqué (écran réduit), au survol comme au toucher
function tbTip(btn) {
  // les liens vers des formulaires montrent toujours leur commentaire, même quand leur libellé est visible
  if (!btn.classList.contains("formlink") && btn.id !== "btnMenu" && getComputedStyle(btn.querySelector(".lbl")).display !== "none") return;
  tip.textContent = btn.dataset.tip;
  tip.classList.add("on");
  const r = btn.getBoundingClientRect();
  tip.style.top = `${r.bottom + 4}px`;
  tip.style.left = `${Math.max(4, Math.min(r.left + r.width / 2 - tip.offsetWidth / 2, window.innerWidth - tip.offsetWidth - 4))}px`;
}
$(".bar").addEventListener("mouseover", (e) => {
  const b = e.target.closest(".tb");
  if (b) tbTip(b);
});
$(".bar").addEventListener("mouseout", (e) => {
  if (e.target.closest(".tb")) tip.classList.remove("on");
});
$(".bar").addEventListener(
  "touchstart",
  (e) => {
    const b = e.target.closest(".tb");
    if (b) {
      tbTip(b);
      setTimeout(() => tip.classList.remove("on"), 1500);
    }
  },
  { passive: true },
);
/* Blocs « figés à l'écran » : sans réglage, ils se colleraient tous au même endroit sous l'en-tête et se
   recouvriraient (un graphique figé glisserait sur la carte figée au-dessus). Chaque bloc figé se colle donc
   sous ceux, figés aussi, qui le précèdent dans la même colonne. Un bloc qui n'a plus la place de montrer son
   en-tête n'est plus figé, et passe alors sous les blocs figés. */
let stickyRO = null,
  stickyRaf = 0;
// stackSticky — Calcule la position de collage (top) de chaque bloc figé, colonne par colonne.
function stackSticky(grid = $("#grid")) {
  stickyRO?.disconnect();
  const els = [...grid.querySelectorAll(":scope > .block.sticky")];
  if (!els.length) return maskSticky();
  const apply = () => {
    const toph = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--toph")) || 0;
    const gap = 8,
      placed = [];
    els.forEach((el, i) => {
      const r = el.getBoundingClientRect();
      const above = placed.filter((p) => p.l < r.right - 1 && p.r > r.left + 1); // même colonne (chevauchement horizontal)
      const top = above.reduce((t, p) => Math.max(t, p.top + p.h + gap), toph + 6);
      // plus assez de place pour montrer au moins l'en-tête du bloc : il n'est plus figé. Sinon le bloc reste
      // figé quelle que soit sa hauteur (déplié ou non) : max-height le limite à la place restante et son
      // contenu défile à l'intérieur
      const head = el.querySelector(".bh")?.offsetHeight || 34;
      const tooLow = top + head + 40 > window.innerHeight;
      el.style.position = tooLow ? "relative" : "";
      el.style.top = tooLow ? "" : `${top}px`;
      el.style.maxHeight = tooLow ? "" : `calc(100vh - ${Math.round(top + 8)}px)`;
      // superposition : les blocs figés passent devant le reste, le premier figé devant les suivants ;
      // un bloc qui n'est plus figé passe SOUS les blocs figés (sinon il glisserait par-dessus la carte)
      el.style.zIndex = tooLow ? "1" : String(Math.max(3, 11 - i));
      if (!tooLow) placed.push({ l: r.left, r: r.right, top, h: el.offsetHeight });
    });
  };
  apply();
  maskSticky();
  stickyRO = new ResizeObserver(() => {
    cancelAnimationFrame(stickyRaf);
    stickyRaf = requestAnimationFrame(() => {
      apply(); // pliage, dépliage, contenu chargé
      maskSticky();
    });
  });
  els.forEach((el) => stickyRO.observe(el));
  stickyRO.observe($("#top")); // hauteur de l'en-tête
}
window.addEventListener("resize", () => stackSticky());
/* maskSticky — Masque blanc sous les blocs figés côte à côte. Quand deux blocs figés voisins n'ont pas la même
   hauteur, un bloc qui défile dessous passait derrière le plus haut mais restait visible sous le plus court.
   Les blocs figés voisins (qui se touchent ou presque horizontalement) forment un groupe ; un masque fixe couvre
   toute la largeur du groupe jusqu'au bas du plus haut : le contenu disparaît sur une même ligne. Le masque
   passe sous les blocs figés (z-index 2) et devant le reste. */
let maskRaf = 0;
function maskSticky() {
  let box = $("#stickyMask");
  if (!box) {
    box = document.createElement("div");
    box.id = "stickyMask";
    document.body.append(box);
  }
  const grid = $("#grid");
  const stuck = [...(grid?.querySelectorAll(":scope > .block.sticky") || [])]
    .filter((el) => el.offsetParent && el.style.position !== "relative" && getComputedStyle(el).position === "sticky")
    .map((el) => ({ el, r: el.getBoundingClientRect(), top: parseFloat(el.style.top) || 0 }))
    .filter((o) => o.r.top <= o.top + 1.5 && o.r.bottom > 0) // collé (ou repoussé vers le haut en fin de page)
    .sort((a, b) => a.r.left - b.r.left);
  // regroupe les blocs collés voisins (écart horizontal ≤ 24 px, soit la gouttière de la grille)
  const groups = [];
  stuck.forEach((o) => {
    const g = groups.find((g) => o.r.left <= g.r + 24 && o.r.right >= g.l - 24);
    if (g) {
      g.l = Math.min(g.l, o.r.left);
      g.r = Math.max(g.r, o.r.right);
      g.b = Math.max(g.b, o.r.bottom);
      g.n++;
    } else groups.push({ l: o.r.left, r: o.r.right, b: o.r.bottom, n: 1 });
  });
  const toph = $("#top")?.getBoundingClientRect().bottom || 0;
  box.innerHTML = groups
    .filter((g) => g.n > 1) // un bloc seul n'a pas besoin de masque (son liseré suffit)
    .map((g) => `<div style="left:${Math.round(g.l) - 4}px;width:${Math.round(g.r - g.l) + 8}px;top:${Math.round(toph)}px;height:${Math.max(0, Math.round(g.b - toph) + 8)}px"></div>`)
    .join("");
}
window.addEventListener(
  "scroll",
  () => {
    cancelAnimationFrame(maskRaf);
    maskRaf = requestAnimationFrame(maskSticky);
  },
  { passive: true },
);
/* chaque bloc réserve dans la grille un nombre de rangées de 2 px égal à sa hauteur réelle */
function setupMasonry(grid) {
  S.masonRO?.disconnect();
  if (!grid.classList.contains("masonry")) return;
  const gap = parseFloat(getComputedStyle(grid).getPropertyValue("--gap")) || 10;
  const fit = (el) => {
    if (!el.classList.contains("maxed"))
      el.style.gridRowEnd = `span ${Math.max(1, Math.ceil((el.offsetHeight + gap) / 2))}`;
  };
  S.masonRO = new ResizeObserver((es) => es.forEach((e) => fit(e.target)));
  grid.querySelectorAll(":scope > .block").forEach((el) => {
    fit(el);
    S.masonRO.observe(el);
  });
}
let refitTimer = null;
window.addEventListener("resize", () => {
  // largeur du widget modifiée : on réajuste les tableaux
  clearTimeout(refitTimer);
  refitTimer = setTimeout(() => {
    document.querySelectorAll("#grid table[data-fit]").forEach((t) => {
      delete t.dataset.locked;
      fitColumns(t);
    });
    freezeColumns($("#grid"));
  }, 200);
});
// lockColumns — Fige la largeur des colonnes une fois affichées (le survol ou l'édition ne les font plus bouger).
function lockColumns(root) {
  // fige la largeur des colonnes : survol, saisie ou ajout de lignes ne les font plus bouger
  root.querySelectorAll("table[data-fit]:not([data-locked])").forEach(fitColumns);
  root.querySelectorAll("table:not([data-locked])").forEach((t) => {
    const ths = [...t.querySelectorAll("thead th")];
    const ws = ths.map((th) => th.getBoundingClientRect().width);
    if (!ths.length || ws.some((w) => !w)) return; // bloc replié : on attendra qu'il soit déplié
    const cg = document.createElement("colgroup");
    cg.innerHTML = ws.map((w) => `<col style="width:${w}px">`).join("");
    t.prepend(cg);
    t.style.width = `${t.getBoundingClientRect().width}px`;
    t.style.tableLayout = "fixed";
    t.dataset.locked = "1";
  });
}
// freezeColumns — Colonnes figées à gauche (option « colonnes figées » de la vue Grist).
function freezeColumns(root) {
  root.querySelectorAll("table[data-frozen]").forEach((t) => {
    const n = Number(t.dataset.frozen);
    if (!n) return;
    const ths = [...t.querySelectorAll("thead th")].slice(0, n);
    let left = 0;
    ths.forEach((th, i) => {
      const x = left;
      left += th.getBoundingClientRect().width;
      t.querySelectorAll(`tr > :nth-child(${i + 1})`).forEach((c) => {
        c.classList.add("frz");
        c.style.left = `${x}px`;
      });
    });
  });
}
/* ---------- Tri et filtres des en-têtes de tableau ---------- */
const keyText = (f, r) => textOf(f.col, f.opts, r[f.colId]) || "(vide)";
// applyUserView — Applique le tri et les filtres choisis dans les en-têtes du tableau (en plus de ceux de la vue).
function applyUserView(info, rows, exceptCol = null) {
  const uf = S.ufilt[info.secId] || {};
  for (const [colId, ex] of Object.entries(uf)) {
    if (colId === exceptCol) continue;
    const f = info.fields.find((x) => x.colId === colId);
    if (!f) continue;
    rows = rows.filter((r) => !ex.has(keyText(f, r)));
  }
  const us = S.usort[info.secId];
  const f = us && info.fields.find((x) => x.colId === us.colId);
  if (f && exceptCol === null) {
    const t = baseType(f.col),
      raw = ["Numeric", "Int", "Date", "DateTime", "Bool"].includes(t);
    rows = rows
      .map((r) => ({ r, k: raw ? r[f.colId] : textOf(f.col, f.opts, r[f.colId]) }))
      .sort((a, b) => {
        const c = cmp(a.k, b.k);
        return us.desc ? -c : c;
      })
      .map((x) => x.r);
  }
  return rows;
}
// openFilter — Ouvre la petite fenêtre de filtre d'une colonne (cases à cocher des valeurs).
async function openFilter(btn, secId, colId) {
  document.querySelector(".fpop")?.remove();
  const info = getInfo(secId),
    f = info.fields.find((x) => x.colId === colId);
  const { rows } = await rowsFor(secId, { rows: new Map() });
  const counts = new Map();
  for (const r of applyUserView(info, rows, colId)) {
    const k = keyText(f, r);
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  const t = baseType(f.col),
    raw = ["Numeric", "Int", "Date", "DateTime"].includes(t);
  const byText = new Map(rows.map((r) => [keyText(f, r), r[f.colId]]));
  const keys = [...counts.keys()].sort((a, b) => (raw ? cmp(byText.get(a), byText.get(b)) : COLL.compare(a, b)));
  const ex = new Set(S.ufilt[secId]?.[colId] || []);
  const box = document.createElement("div");
  box.className = "fpop";
  box.innerHTML = `<input class="ed-input" type="text" placeholder="Rechercher une valeur…">
    <div class="fbtn"><button data-all>Tout</button><button data-none>Aucun</button></div>
    <ul>${keys
.slice(0, 1000)
.map(
  (k) =>
    `<li><label><input type="checkbox" value="${esc(k)}" ${ex.has(k) ? "" : "checked"}> <span>${esc(k)}</span> <small>${counts.get(k)}</small></label></li>`,
)
.join("")}</ul>
    ${keys.length > 1000 ? `<div class="msg">${keys.length - 1000} valeurs supplémentaires non listées</div>` : ""}
    <div class="fbtn"><button class="btn" data-cancel>Annuler</button><button class="btn primary" data-apply>Appliquer</button></div>`;
  document.body.append(box);
  const r = btn.getBoundingClientRect();
  box.style.top = `${Math.min(r.bottom + 4, window.innerHeight - box.offsetHeight - 4)}px`;
  box.style.left = `${Math.max(4, Math.min(r.left - 160, window.innerWidth - box.offsetWidth - 4))}px`;
  const inp = box.querySelector("input[type=text]");
  inp.addEventListener("input", () => {
    const q = inp.value.toLowerCase();
    box.querySelectorAll("li").forEach((li) => {
      li.hidden = !!q && !li.textContent.toLowerCase().includes(q);
    });
  });
  const visibleBoxes = () => [...box.querySelectorAll("li:not([hidden]) input")];
  const close = () => {
    box.remove();
    document.removeEventListener("mousedown", outside, true);
  };
  const outside = (e) => {
    if (!box.contains(e.target)) close();
  };
  setTimeout(() => document.addEventListener("mousedown", outside, true), 0);
  box.addEventListener("click", (e) => {
    if (e.target.closest("[data-all]"))
      visibleBoxes().forEach((c) => {
        c.checked = true;
      });
    if (e.target.closest("[data-none]"))
      visibleBoxes().forEach((c) => {
        c.checked = false;
      });
    if (e.target.closest("[data-cancel]")) close();
    if (e.target.closest("[data-apply]")) {
      const off = new Set([...box.querySelectorAll("li input")].filter((c) => !c.checked).map((c) => c.value));
      for (const k of ex) if (!counts.has(k)) off.add(k); // valeurs déjà masquées absentes de la liste
      S.ufilt[secId] ??= {};
      if (off.size) S.ufilt[secId][colId] = off;
      else delete S.ufilt[secId][colId];
      close();
      scheduleRender();
    }
  });
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Escape") close();
    if (e.key === "Enter") box.querySelector("[data-apply]").click();
  });
  inp.focus();
}

// renderTable — Affiche une vue tableau. Rendu progressif : 400 lignes d'abord, le reste par paquets (jobs).
function renderTable(info, rows, body, selId, jobs = []) {
  const FIRST = 400,
    CHUNK = 1500,
    ed = blockEditable(info.secId);
  const us = S.usort[info.secId],
    uf = S.ufilt[info.secId] || {};
  const head = info.fields
    .map((f) => {
      const arrow = us?.colId === f.colId ? (us.desc ? " ▼" : " ▲") : "";
      return (
        `<th class="${isNumCol(f.col) ? "num" : ""}"${f.opts.wrap ? ' data-wrap="1"' : ""} style="${headerCss(f)}"${colDesc(f) ? descAttr(f) : ` title="${esc(f.label)} — cliquer pour trier"`}>` +
        `<span class="ths" data-sort="${esc(f.colId)}">${esc(f.label)}${infoMark(f)}<b class="arr">${arrow}</b></span>` +
        `<button class="thf${uf[f.colId] ? " on" : ""}" data-filt="${esc(f.colId)}" title="Filtrer cette colonne">⏷</button></th>`
      );
    })
    .join("");
  diagRowRules(info, rows);
  const line = (r) => {
    const txt = info.fields
      .map((f) => textOf(f.col, f.opts, r[f.colId]))
      .join(" ")
      .toLowerCase();
    const rs = rowStyle(info, r);
    const cells = info.fields
      .map((f) => {
        const t = textOf(f.col, f.opts, r[f.colId]);
        return `<td class="${isNumCol(f.col) ? "num" : ""}${["RefList", "ChoiceList"].includes(baseType(f.col)) ? " multi" : ""}" style="${cellStyle(f, r, rs)}" title="${esc(t)}"${edAttr(ed, f, r)}>${htmlOf(f, r[f.colId])}</td>`;
      })
      .join("");
    return `<tr data-row="${r.id}" data-text="${esc(txt)}" class="${r.id === selId ? "sel" : ""}">${cells}</tr>`;
  };
  const lines = rows.slice(0, FIRST).map(line).join("");
  // largeurs des colonnes : celles réglées dans la vue Grist (par défaut), ou calcul automatique
  const blk = S.cfg.blocks.find((x) => x.id === info.secId) || {};
  const ws = info.fields.map((f) => Number(f.field?.width) || 0);
  const useGrist = blk.colWidths === "grist" && ws.some((w) => w > 0);
  const fit = !blk.colWidths; // par défaut : colonnes ajustées au contenu et à la largeur du bloc
  const colgroup = useGrist
    ? `<colgroup>${ws.map((w) => `<col style="width:${w || 100}px">`).join("")}</colgroup>`
    : "";
  const tStyle = useGrist ? ` style="table-layout:fixed;width:${ws.reduce((a, w) => a + (w || 100), 0)}px"` : "";
  body.innerHTML = `<div class="tbl-wrap" style="--tmh:${S.cfg.tableMaxHeight}px;max-height:var(--h, var(--tmh))"><table class="${tableClasses(info)}"${useGrist ? ' data-locked="1"' : ""}${fit ? ' data-fit="1"' : ""}${tStyle} data-frozen="${Math.max(0, Number(info.opts.numFrozen) || 0)}">${colgroup}<thead><tr>${head}</tr></thead><tbody>${lines}</tbody></table></div>` +
    // nombre de lignes, en bas à droite comme dans Grist (mis à jour par la recherche du bloc)
    (blk.rowCount === false ? "" : `<div class="rowcount" data-total="${rows.length}">${rowCountText(rows.length)}</div>`);
  if (rows.length > FIRST)
    jobs.push(() => {
      // le reste est ajouté par paquets, sans bloquer l'affichage
      const tb = body.querySelector("tbody");
      let i = FIRST;
      const step = () => {
        if (!tb.isConnected) return;
        tb.insertAdjacentHTML(
          "beforeend",
          rows
            .slice(i, i + CHUNK)
            .map(line)
            .join(""),
        );
        i += CHUNK;
        if (S.search[info.secId]) applySearch(info.secId);
        if (i < rows.length) setTimeout(step, 0);
        else freezeColumns(body);
      };
      setTimeout(step, 0);
    });
}

// colDesc — Description d'une colonne (affichée en infobulle).
const colDesc = (f) => String(f.col.description || "").trim();
// descAttr — Attribut HTML portant la description d'une colonne.
const descAttr = (f) => (colDesc(f) ? ` data-desc="${esc(colDesc(f))}"` : "");
// infoMark — Petit ⓘ signalant qu'une colonne a une description.
const infoMark = (f) => (colDesc(f) ? '<span class="info">ⓘ</span>' : "");
/* ---------- Édition des champs (les règles d'accès de Grist restent souveraines) ---------- */
const EDIT_TYPES = [
  "Text",
  "Numeric",
  "Int",
  "Bool",
  "Date",
  "DateTime",
  "Choice",
  "Ref",
  "Any",
  "RefList",
  "ChoiceList",
];
S.canEdit = new URLSearchParams(location.search).get("readonly") !== "true"; // lecteur = lecture seule
// isEditableCol — Colonne modifiable dans le widget : données (pas formule), type géré.
function isEditableCol(col) {
  if (!col || ["id", "manualSort"].includes(col.colId) || col.colId.startsWith("gristHelper_")) return false;
  if (col.isFormula && String(col.formula || "").trim()) return false; // colonne calculée
  return EDIT_TYPES.includes(baseType(col));
}
// blockEditable — Vrai si le bloc autorise l'édition et que l'utilisateur n'est pas en lecture seule.
const blockEditable = (secId) => S.canEdit && !!S.cfg.blocks.find((x) => x.id === secId)?.editable;
// blockAddable — Vrai si le bloc (tableau ou fiches) propose « + Ajouter une ligne » : édition active et option cochée.
const blockAddable = (b, info) =>
  S.canEdit && !!b?.editable && !!b?.addable && ["record", "detail"].includes(info?.kind);
// addBtn — Bouton d'ajout d'une ligne en bas du bloc.
const addBtn = (b, del = true) =>
  `<div class="rowbtns"><button class="addrow" data-addrow="${b.id}" title="Ajouter un enregistrement dans la table">+ Ajouter une ligne</button>` +
  (del ? "" : "</div>") +
  (!del ? "" : `<button class="addrow delrow" data-delrow="${b.id}" title="Supprimer la ligne sélectionnée (deux clics : le premier demande confirmation)">− Supprimer la ligne</button></div>`);
// edAttr — Attributs HTML qui rendent une cellule éditable (double-clic).
const edAttr = (on, f, row) =>
  on && isEditableCol(f.col)
    ? ` data-ed="${f.col.id}" data-fld="${f.field?.id || ""}" data-rid="${row.id}" tabindex="0"${["Ref", "Choice", "RefList", "ChoiceList"].includes(baseType(f.col)) ? ' data-kind="sel"' : ""}`
    : "";
// tableOfCol — Identifiant de la table d'une colonne.
function tableOfCol(col) {
  return S.meta.tables.get(col.parentId)?.tableId;
}
/* ---------- Conditions de liste déroulante (formules « choice.X == $Y » de Grist) ---------- */
function compilePredicate(node) {
  const [op, ...a] = node;
  const all = (fn) => {
    const cs = a.map(compilePredicate);
    return (inp) => fn(cs.map((c) => c(inp)));
  };
  const incl = (h, n) =>
    Array.isArray(h) ? h.includes(n) : typeof h === "string" && typeof n === "string" ? h.includes(n) : false;
  switch (op) {
    case "And": {
      const cs = a.map(compilePredicate);
      return (i) => cs.every((c) => c(i));
    }
    case "Or": {
      const cs = a.map(compilePredicate);
      return (i) => cs.some((c) => c(i));
    }
    case "Add":
      return all(([x, y]) => x + y);
    case "Sub":
      return all(([x, y]) => x - y);
    case "Mult":
      return all(([x, y]) => x * y);
    case "Div":
      return all(([x, y]) => x / y);
    case "Mod":
      return all(([x, y]) => x % y);
    case "Not":
      return all(([x]) => !x);
    case "Eq":
    case "Is":
      return all(([x, y]) => x === y);
    case "NotEq":
    case "IsNot":
      return all(([x, y]) => x !== y);
    case "Lt":
      return all(([x, y]) => x < y);
    case "LtE":
      return all(([x, y]) => x <= y);
    case "Gt":
      return all(([x, y]) => x > y);
    case "GtE":
      return all(([x, y]) => x >= y);
    case "In":
      return all(([x, y]) => incl(y, x));
    case "NotIn":
      return all(([x, y]) => !incl(y, x));
    case "List":
      return all((v) => v);
    case "Const":
      return () => a[0];
    case "Comment":
      return compilePredicate(a[0]);
    case "Name": {
      const n = a[0];
      if (n === "user") throw new Error("user"); // l'utilisateur n'est pas accessible au widget
      if (!["rec", "choice"].includes(n)) throw new Error(`Variable inconnue ${n}`);
      return (i) => i[n];
    }
    case "Attr": {
      const base = compilePredicate(a[0]),
        attr = a[1];
      return (i) => {
        const v = base(i);
        if (v == null) throw new Error("valeur absente");
        if (typeof v === "string")
          return attr === "lower" ? () => v.toLowerCase() : attr === "upper" ? () => v.toUpperCase() : undefined;
        const x = attr === "id" ? v.id : v[attr];
        return isList(x) ? x.slice(1) : x; // listes Grist ["L", …] → tableaux
      };
    }
    case "Call": {
      const cs = a.map(compilePredicate);
      return (i) => {
        const f = cs[0](i);
        if (typeof f !== "function") throw new Error("non supporté");
        return f();
      };
    }
  }
  throw new Error(`Nœud non géré : ${op}`);
}
// dropdownFilter — Valeurs proposées dans une liste déroulante en tenant compte de sa condition (dropdownCondition).
function dropdownFilter(opts, rec, targetTable) {
  const dc = opts?.dropdownCondition;
  if (!dc?.text || !dc.parsed) return () => true;
  let pred;
  try {
    pred = compilePredicate(parseJSON(dc.parsed, null));
  } catch {
    return () => true;
  } // formule non gérée : liste complète
  return (choice) => {
    try {
      return !!pred({ rec, choice });
    } catch {
      return true;
    }
  };
}

// startEdit — Édition d'une cellule : champ de saisie, liste de choix ou sélecteur de référence selon le type.
function startEdit(el) {
  if (el.querySelector(".ed-input") || el.classList.contains("saving")) return;
  const col = S.meta.cols.get(Number(el.dataset.ed)),
    rid = Number(el.dataset.rid),
    tableId = tableOfCol(col);
  const row = S.byId[tableId]?.get(rid);
  if (!col || !row) return;
  const t = baseType(col),
    v = row[col.colId];
  const opts = S.fieldOpts.get(Number(el.dataset.fld)) || parseJSON(col.widgetOptions);
  const allowed = dropdownFilter(opts, row, refTarget(col)); // condition de liste déroulante définie dans Grist
  if (t === "Bool") return saveValue(el, tableId, rid, col, !v); // case à cocher : bascule directe
  if (t === "RefList" || t === "ChoiceList") {
    // plusieurs valeurs : liste à cases à cocher
    const cur = isList(v) ? v.slice(1) : [];
    const items =
      t === "ChoiceList"
        ? (opts.choices || [])
            .filter((c) => allowed(c) || cur.includes(c))
            .map((c) => ({ v: c, t: c, chip: true }))
        : [...(S.byId[refTarget(col)]?.values() || [])]
            .filter((r) => allowed(r) || cur.includes(r.id))
            .map((r) => ({ v: r.id, t: refText(col, r.id, 0) }))
            .sort((a, b) => COLL.compare(a.t, b.t));
    S.editing = true;
    const end = () => {
      S.editing = false;
      if (S.pendingRender) {
        S.pendingRender = false;
        scheduleRender();
      }
    };
    openMultiPicker(
      el,
      items,
      cur,
      t === "ChoiceList" ? opts : null,
      (list) => {
        S.editing = false;
        if (list.length === cur.length && list.every((x, i) => x === cur[i])) return end();
        saveValue(el, tableId, rid, col, list.length ? ["L", ...list] : null);
      },
      end,
    );
    return;
  }
  if (t === "Choice" || t === "Ref") {
    const items =
      t === "Choice"
        ? [
            { v: "", t: "" },
            ...(opts.choices || []).filter((c) => allowed(c)).map((c) => ({ v: c, t: c, chip: true })),
          ]
        : [
            { v: 0, t: "" },
            ...[...(S.byId[refTarget(col)]?.values() || [])]
              .filter((r) => allowed(r))
              .map((r) => ({ v: r.id, t: refText(col, r.id, 0) }))
              .sort((a, b) => COLL.compare(a.t, b.t)),
          ];
    S.editing = true;
    const end = () => {
      S.editing = false;
      if (S.pendingRender) {
        S.pendingRender = false;
        scheduleRender();
      }
    };
    openPicker(
      el,
      items,
      v ?? (t === "Ref" ? 0 : ""),
      t === "Choice" ? opts : null,
      (nv) => {
        S.editing = false;
        if (nv === (v ?? (t === "Ref" ? 0 : ""))) return end();
        saveValue(el, tableId, rid, col, nv);
      },
      end,
    );
    return;
  }
  let input;
  const pad = (n) => String(n).padStart(2, "0");
  if (t === "Choice") {
    input = document.createElement("select");
    input.innerHTML =
      `<option value=""></option>` +
      (opts.choices || []).map((c) => `<option ${c === v ? "selected" : ""}>${esc(c)}</option>`).join("");
  } else if (t === "Ref") {
    const target = refTarget(col),
      items = [...(S.byId[target]?.values() || [])]
        .map((r) => ({ id: r.id, t: refText(col, r.id, 0) }))
        .sort((a, b) => COLL.compare(a.t, b.t));
    input = document.createElement("select");
    input.innerHTML =
      `<option value="0"></option>` +
      items.map((x) => `<option value="${x.id}" ${x.id === v ? "selected" : ""}>${esc(x.t)}</option>`).join("");
  } else if (t === "Date") {
    input = document.createElement("input");
    input.type = "date";
    if (typeof v === "number") input.value = new Date(v * 1000).toISOString().slice(0, 10);
  } else if (t === "DateTime") {
    input = document.createElement("input");
    input.type = "datetime-local";
    if (typeof v === "number") {
      const d = new Date(v * 1000);
      input.value = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
  } else {
    const multi =
      (t === "Text" || t === "Any") &&
      (opts.wrap || String(v ?? "").includes("\n") || String(v ?? "").length > 60);
    input = document.createElement(multi ? "textarea" : "input");
    if (!multi) {
      input.type = "text";
      if (t === "Numeric" || t === "Int") input.inputMode = "decimal";
    }
    input.value = isErr(v) || v == null ? "" : String(v);
  }
  input.className = "ed-input";
  const old = el.innerHTML;
  el.innerHTML = "";
  el.append(input);
  S.editing = true;
  let done = false;
  const finish = (commit) => {
    if (done) return;
    done = true;
    S.editing = false;
    if (!commit) {
      el.innerHTML = old;
      if (S.pendingRender) {
        S.pendingRender = false;
        scheduleRender();
      }
      return;
    }
    let nv;
    const raw = input.value;
    if (t === "Numeric" || t === "Int") {
      nv = raw.trim() === "" ? null : toNum(raw);
      if (raw.trim() !== "" && !Number.isFinite(nv)) {
        status(`« ${raw} » n'est pas un nombre`, true);
        el.innerHTML = old;
        return;
      }
      if (t === "Int" && nv !== null) nv = Math.round(nv);
    } else if (t === "Ref") nv = Number(raw) || 0;
    else if (t === "Date")
      nv = raw ? Date.UTC(...raw.split("-").map((x, i) => Number(x) - (i === 1 ? 1 : 0))) / 1000 : null;
    else if (t === "DateTime") nv = raw ? new Date(raw).getTime() / 1000 : null;
    else nv = raw;
    if ((nv ?? "") === (v ?? "")) {
      el.innerHTML = old;
      if (S.pendingRender) {
        S.pendingRender = false;
        scheduleRender();
      }
      return;
    }
    saveValue(el, tableId, rid, col, nv);
  };
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      finish(false);
    } else if (e.key === "Enter" && !(input.tagName === "TEXTAREA" && e.shiftKey)) {
      e.preventDefault();
      finish(true);
    }
  });
  input.addEventListener("blur", () => finish(true));
  if (input.tagName === "SELECT") input.addEventListener("change", () => finish(true));
  input.addEventListener("click", (e) => e.stopPropagation());
  input.focus();
  if (input.select && input.tagName === "INPUT" && input.type === "text") input.select();
  if (input.tagName === "SELECT") {
    try {
      input.showPicker?.();
    } catch {
      /* navigateur sans showPicker : la liste s'ouvre au clic suivant */
    }
  }
}
/* Liste déroulante avec recherche, affichée par-dessus la page */
function openPicker(anchor, items, current, choiceOpts, onPick, onCancel) {
  document.querySelector(".picker")?.remove();
  const box = document.createElement("div");
  box.className = "picker";
  box.innerHTML = `<input class="ed-input" type="text" placeholder="Rechercher…"><ul role="listbox"></ul>`;
  document.body.append(box);
  const inp = box.querySelector("input"),
    ul = box.querySelector("ul");
  const r = anchor.getBoundingClientRect();
  box.style.minWidth = `${Math.max(220, r.width)}px`;
  box.style.left = `${Math.max(4, Math.min(r.left, window.innerWidth - box.offsetWidth - 4))}px`;
  const below = window.innerHeight - r.bottom > 220 || r.top < 220;
  box.style.top = below ? `${r.bottom + 2}px` : "";
  box.style.bottom = below ? "" : `${window.innerHeight - r.top + 2}px`;
  let shown = [],
    idx = 0,
    closed = false;
  const label = (x) =>
    x.t === "" ? '<span class="pk-empty">(vide)</span>' : x.chip && choiceOpts ? chip(x.t, choiceOpts) : esc(x.t);
  const draw = () => {
    const q = inp.value.trim().toLowerCase();
    shown = items.filter((x) => !q || x.t.toLowerCase().includes(q)).slice(0, 500);
    if (idx >= shown.length) idx = Math.max(0, shown.length - 1);
    ul.innerHTML =
      shown
        .map(
          (x, i) =>
            `<li role="option" data-i="${i}" class="${i === idx ? "on" : ""}${x.v === current ? " cur" : ""}">${label(x)}</li>`,
        )
        .join("") || '<li class="pk-none">Aucun résultat</li>';
    ul.querySelector("li.on")?.scrollIntoView({ block: "nearest" });
  };
  const close = (pick) => {
    if (closed) return;
    closed = true;
    document.removeEventListener("mousedown", outside, true);
    box.remove();
    pick ? onPick(pick.v) : onCancel();
  };
  const outside = (e) => {
    if (!box.contains(e.target)) close(null);
  };
  inp.addEventListener("input", () => {
    idx = 0;
    draw();
  });
  inp.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      idx = Math.min(shown.length - 1, idx + 1);
      draw();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      idx = Math.max(0, idx - 1);
      draw();
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (shown[idx]) close(shown[idx]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      close(null);
    }
  });
  ul.addEventListener("mouseover", (e) => {
    // la ligne sous le pointeur devient la ligne présélectionnée
    const li = e.target.closest("[data-i]");
    if (!li) return;
    const i = Number(li.dataset.i);
    if (i === idx) return;
    ul.querySelector("li.on")?.classList.remove("on");
    li.classList.add("on");
    idx = i;
  });
  ul.addEventListener("mousedown", (e) => {
    const li = e.target.closest("[data-i]");
    if (li) {
      e.preventDefault();
      close(shown[Number(li.dataset.i)]);
    }
  });
  setTimeout(() => document.addEventListener("mousedown", outside, true), 0);
  idx = Math.max(
    0,
    items.findIndex((x) => x.v === current),
  );
  draw();
  inp.focus();
}
/* Liste à choix multiples (Référence multiple, Liste de choix) */
function openMultiPicker(anchor, items, current, choiceOpts, onDone, onCancel) {
  document.querySelector(".picker")?.remove();
  const chosen = [...current]; // ordre conservé : valeurs existantes puis nouvelles
  const box = document.createElement("div");
  box.className = "picker multi";
  box.innerHTML = `<input class="ed-input" type="text" placeholder="Rechercher…"><ul role="listbox" aria-multiselectable="true"></ul>
    <div class="pk-foot"><span class="pk-count"></span><button class="btn" data-pkno>Annuler</button><button class="btn primary" data-pkok>Valider</button></div>`;
  document.body.append(box);
  const inp = box.querySelector("input"),
    ul = box.querySelector("ul"),
    cnt = box.querySelector(".pk-count");
  const r = anchor.getBoundingClientRect();
  box.style.minWidth = `${Math.max(260, r.width)}px`;
  box.style.left = `${Math.max(4, Math.min(r.left, window.innerWidth - box.offsetWidth - 4))}px`;
  const below = window.innerHeight - r.bottom > 280 || r.top < 280;
  box.style.top = below ? `${r.bottom + 2}px` : "";
  box.style.bottom = below ? "" : `${window.innerHeight - r.top + 2}px`;
  let shown = [],
    idx = 0,
    closed = false;
  const label = (x) => (x.chip && choiceOpts ? chip(x.t, choiceOpts) : esc(x.t || "(vide)"));
  const draw = () => {
    const q = inp.value.trim().toLowerCase();
    // valeurs cochées en tête, puis les autres
    shown = [...items.filter((x) => chosen.includes(x.v)), ...items.filter((x) => !chosen.includes(x.v))]
      .filter((x) => !q || x.t.toLowerCase().includes(q))
      .slice(0, 500);
    if (idx >= shown.length) idx = Math.max(0, shown.length - 1);
    ul.innerHTML =
      shown
        .map(
          (
            x,
            i,
          ) => `<li role="option" data-i="${i}" class="${i === idx ? "on" : ""}" aria-selected="${chosen.includes(x.v)}">
<input type="checkbox" tabindex="-1" ${chosen.includes(x.v) ? "checked" : ""}> ${label(x)}</li>`,
        )
        .join("") || '<li class="pk-none">Aucun résultat</li>';
    cnt.textContent = `${chosen.length} sélectionné${chosen.length > 1 ? "s" : ""}`;
    ul.querySelector("li.on")?.scrollIntoView({ block: "nearest" });
  };
  const toggle = (x) => {
    const k = chosen.indexOf(x.v);
    k >= 0 ? chosen.splice(k, 1) : chosen.push(x.v);
    draw();
  };
  const close = (ok) => {
    if (closed) return;
    closed = true;
    document.removeEventListener("mousedown", outside, true);
    box.remove();
    ok ? onDone(chosen) : onCancel();
  };
  const outside = (e) => {
    if (!box.contains(e.target)) close(true);
  }; // clic à côté = valider, comme dans Grist
  inp.addEventListener("input", () => {
    idx = 0;
    draw();
  });
  inp.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      idx = Math.min(shown.length - 1, idx + 1);
      draw();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      idx = Math.max(0, idx - 1);
      draw();
    } else if (e.key === " " && !inp.value) {
      e.preventDefault();
      if (shown[idx]) toggle(shown[idx]);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (e.ctrlKey || e.metaKey || !shown[idx]) close(true);
      else toggle(shown[idx]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      close(false);
    }
  });
  ul.addEventListener("mousedown", (e) => {
    const li = e.target.closest("[data-i]");
    if (li) {
      e.preventDefault();
      idx = Number(li.dataset.i);
      toggle(shown[idx]);
    }
  });
  ul.addEventListener("mouseover", (e) => {
    const li = e.target.closest("[data-i]");
    if (!li) return;
    ul.querySelector("li.on")?.classList.remove("on");
    li.classList.add("on");
    idx = Number(li.dataset.i);
  });
  box.querySelector("[data-pkok]").addEventListener("click", () => close(true));
  box.querySelector("[data-pkno]").addEventListener("click", () => close(false));
  setTimeout(() => document.addEventListener("mousedown", outside, true), 0);
  draw();
  inp.focus();
}
/* ---------- Avertissements en bas à droite, comme dans Grist (0.9.5.11) ----------
   Refus d'une modification : le commentaire de la règle d'accès (« memo », saisi dans les règles d'accès de Grist)
   est affiché quand Grist le transmet avec l'erreur ; sinon un texte par défaut. */
// toast — Message temporaire en bas à droite (kind : "err" ou "info"), fermé au clic ou après ms.
function toast(title, text = "", kind = "err", ms = 9000) {
  let box = $("#toasts");
  if (!box) {
    box = document.createElement("div");
    box.id = "toasts";
    box.setAttribute("aria-live", "assertive");
    document.body.appendChild(box);
  }
  const t = document.createElement("div");
  t.className = `toast ${kind}`;
  t.setAttribute("role", kind === "err" ? "alert" : "status");
  t.innerHTML = `<span class="toast-ico" aria-hidden="true">${kind === "err" ? "⚠" : "ℹ"}</span><div class="toast-body"><b>${esc(title)}</b>${text ? `<div>${esc(text)}</div>` : ""}</div><button type="button" class="toast-x" aria-label="Fermer">✕</button>`;
  const close = () => {
    t.classList.add("out");
    setTimeout(() => t.remove(), 250);
  };
  t.querySelector(".toast-x").addEventListener("click", close);
  box.appendChild(t);
  while (box.children.length > 3) box.firstElementChild.remove(); // trois messages au plus
  setTimeout(close, ms);
}
// aclMemo — Commentaire(s) de la règle d'accès qui a refusé l'action, si Grist les transmet avec l'erreur.
function aclMemo(e) {
  const d = e?.details || e?.cause?.details || {};
  const memos = [d.memos, d.memo, e?.memos].flat().filter((x) => typeof x === "string" && x.trim());
  return [...new Set(memos.map((x) => x.trim()))].join(" — ");
}
const isDenied = (e) => /access|acc[eè]s|permission|denied|blocked|refus/i.test(String(e?.message || e));
// actionFailed — Avertissement après un refus ou un échec d'enregistrement (what : « Modification », « Ajout »…).
function actionFailed(e, what, detail = "") {
  const memo = aclMemo(e);
  if (isDenied(e) || memo)
    toast(`${what} refusée`.replace("Ajout refusée", "Ajout refusé"), memo || `Vos droits ne permettent pas cette action${detail ? ` (${detail})` : ""}.`);
  else toast(`${what} impossible`, String(e?.message || e));
}
// saveValue — Enregistre une valeur dans Grist (UpdateRecord). Les règles d'accès de Grist peuvent refuser.
async function saveValue(el, tableId, rid, col, value) {
  el.classList.add("saving");
  try {
    await docActions([["UpdateRecord", tableId, rid, { [col.colId]: value }]]);
    // données à relire : la table modifiée et ses tables de synthèse (les formules en dépendent)
    const ref = col.parentId;
    for (const [id, t] of S.meta.tables)
      if (id === ref || t.summarySourceTable === ref) {
        delete S.cache[t.tableId];
        delete S.byId[t.tableId];
      }
    status("");
  } catch (e) {
    status("");
    actionFailed(e, "Modification", `colonne « ${col.label || col.colId} »`);
  }
  S.pendingRender = false;
  scheduleRender();
}
// ficheCell — HTML d'un champ dans une fiche (libellé + valeur).
// Liste de fiches (renderCards) : mêmes emplacements d'une fiche à l'autre — un champ vide masqué garde sa place
// (case vide invisible) et un champ est « long » (pleine largeur) pour toutes les fiches ou pour aucune.
// fwStyle — Largeur fixe d'un champ dans une liste de fiches sans disposition Grist (identique d'une fiche à l'autre).
const fwStyle = (f) => (ficheCtx?.widths?.has(f) ? ` style="flex:0 0 ${ficheCtx.widths.get(f)}"` : "");
let ficheCtx = null,
  ficheNoLab = false; // noms des champs masqués (option du bloc) : le nom reste en infobulle
function ficheCell(f, row, showEmpty = false, ed = false) {
  const v = row[f.colId];
  if (S.cfg.hideEmptyFields && !showEmpty && !(ed && isEditableCol(f.col)) && isEmpty(v))
    return ficheCtx && !ficheCtx.allEmpty.has(f) ? `<div class="vide${ficheCtx.longF.has(f) ? " long" : ""}"${fwStyle(f)} aria-hidden="true"></div>` : "";
  const t = textOf(f.col, f.opts, v);
  const long = ficheCtx ? ficheCtx.longF.has(f) : t.length > 60 || t.includes("\n");
  const css = cellStyle(f, row);
  return `<div class="${long ? "long" : ""}"${fwStyle(f)}${ficheNoLab ? ` title="${esc(f.label)}"` : ""}><dt${descAttr(f)}>${esc(f.label)}${infoMark(f)}</dt><dd class="${isNumCol(f.col) ? "num" : ""}${css.includes("background") ? " styled" : ""}" style="${css}"${edAttr(ed, f, row)}>${htmlOf(f, typeof v === "string" ? v.replace(/\s+$/, "") : v)}</dd></div>`;
}
/* Disposition de la fiche telle que construite dans Grist (layoutSpec) :
   niveaux alternés vertical / horizontal, feuilles = champs de la vue */
function layoutHTML(node, depth, byField, row, used, se, ed) {
  if (!node || typeof node !== "object") return "";
  if (node.leaf !== undefined && node.leaf !== null) {
    const f = byField.get(node.leaf);
    if (!f) return "";
    used.add(f);
    return ficheCell(f, row, se, ed);
  }
  const parts = (node.children || [])
    .map((c) => layoutHTML(c, depth + 1, byField, row, used, se, ed))
    .filter(Boolean);
  if (!parts.length) return "";
  if (parts.length === 1) return parts[0];
  return `<div class="${depth % 2 === 0 ? "lv" : "lh"}">${parts.join("")}</div>`;
}
// ficheHTML — HTML d'une fiche complète, en respectant la disposition de la vue Grist si elle existe.
function ficheHTML(info, row, ctx = null) {
  ficheCtx = ctx;
  try {
    return ficheHTMLIn(info, row);
  } finally {
    ficheCtx = null;
    ficheNoLab = false;
  }
}
function ficheHTMLIn(info, row) {
  const se = !!S.cfg.blocks.find((x) => x.id === info.secId)?.showEmpty; // option du bloc : afficher les champs vides
  ficheNoLab = !!S.cfg.blocks.find((x) => x.id === info.secId)?.hideLabels; // option : noms des champs masqués
  const nl = ficheNoLab ? " nolabels" : "";
  const ed = blockEditable(info.secId);
  const style = styleCss(rowStyle(info, row));
  const spec = parseJSON(info.sec.layoutSpec, null);
  if (spec && (spec.children || spec.leaf !== undefined)) {
    const byField = new Map(info.fields.map((f) => [f.field?.id, f]));
    const used = new Set();
    let html = layoutHTML(spec, 0, byField, row, used, se, ed);
    const rest = info.fields
      .filter((f) => !used.has(f))
      .map((f) => ficheCell(f, row, se, ed))
      .join(""); // champs absents de la disposition
    if (rest) html += `<div class="lh wrap">${rest}</div>`;
    return `<dl class="fiche lay${nl}" style="${style}">${html || '<div class="msg">Aucun champ renseigné</div>'}</dl>`;
  }
  const items = info.fields.map((f) => ficheCell(f, row, se, ed)).join("");
  return `<dl class="fiche${nl}" style="${style}">${items || '<div class="msg">Aucun champ renseigné</div>'}</dl>`;
}
// renderSingle — Affiche une vue fiche (un enregistrement, avec flèches précédent/suivant).
function renderSingle(info, rows, body, selId, el) {
  const idx = Math.max(
    0,
    rows.findIndex((r) => r.id === selId),
  );
  const row = S.byId[info.tableId]?.get(selId) || rows[idx];
  if (!row) {
    body.innerHTML = '<div class="msg">Aucun enregistrement</div>';
    return;
  }
  body.className = "bb pad";
  body.innerHTML = ficheHTML(info, row);
  if (rows.length > 1 && !info.sec.linkSrcSectionRef) {
    // une fiche pilotée par un autre widget ne se parcourt pas
    const nav = document.createElement("span");
    nav.className = "nav";
    nav.innerHTML = `<button data-nav="-1" data-sec="${info.secId}">◀</button>${idx + 1}/${rows.length}<button data-nav="1" data-sec="${info.secId}">▶</button>`;
    el.querySelector(".badge").replaceWith(nav);
  }
}
// renderCards — Affiche une liste de fiches (vue « fiches » de Grist, ou fiche en mode liste).
function renderCards(info, rows, body, selId, jobs = []) {
  const FIRST = 60,
    CHUNK = 200;
  // champs « longs » : décidés une fois pour toute la liste (au moins une valeur longue dans les lignes)
  const longF = new Set(
    info.fields.filter((f) =>
      rows.some((r) => {
        const t = textOf(f.col, f.opts, r[f.colId]);
        return t.length > 60 || t.includes("\n");
      }),
    ),
  );
  const allEmpty = new Set(info.fields.filter((f) => rows.every((r) => isEmpty(r[f.colId])))); // champ vide partout : retiré
  // sans disposition Grist : chaque champ a la même largeur dans toutes les fiches, celle de sa plus longue valeur
  // (et de son nom s'il est affiché), entre 6 et 40 caractères ; les champs « longs » prennent toute la ligne
  const spec = parseJSON(info.sec.layoutSpec, null);
  const widths = new Map();
  if (!(spec && (spec.children || spec.leaf !== undefined))) {
    const noLab = !!S.cfg.blocks.find((x) => x.id === info.secId)?.hideLabels;
    // largeur mesurée dans la police de la page (canevas), plus juste qu'un nombre de caractères
    const ctx2d = (renderCards.cv ??= document.createElement("canvas")).getContext("2d");
    const ff = getComputedStyle(document.body).fontFamily;
    const measure = (txt, px) => {
      ctx2d.font = `${px}px ${ff}`;
      return ctx2d.measureText(txt).width;
    };
    for (const f of info.fields) {
      if (longF.has(f) || allEmpty.has(f)) continue;
      let w = noLab ? 0 : measure(String(f.label || ""), 11);
      for (const r of rows.length > 2000 ? rows.slice(0, 2000) : rows)
        w = Math.max(w, measure(textOf(f.col, f.opts, r[f.colId]), 13));
      widths.set(f, `${Math.round(Math.min(360, Math.max(40, w + 6)))}px`);
    }
  }
  const card = (r) => {
    const txt = info.fields
      .map((f) => textOf(f.col, f.opts, r[f.colId]))
      .join(" ")
      .toLowerCase();
    return `<div class="mini ${r.id === selId ? "sel" : ""}" data-row="${r.id}" data-text="${esc(txt)}">${ficheHTML(info, r, { longF, allEmpty, widths })}</div>`;
  };
  body.innerHTML = `<div class="cartes">${rows.slice(0, FIRST).map(card).join("")}</div>`;
  if (rows.length > FIRST)
    jobs.push(() => {
      // les fiches suivantes arrivent par paquets
      const box = body.querySelector(".cartes");
      let i = FIRST;
      const step = () => {
        if (!box.isConnected) return;
        box.insertAdjacentHTML(
          "beforeend",
          rows
            .slice(i, i + CHUNK)
            .map(card)
            .join(""),
        );
        i += CHUNK;
        if (S.search[info.secId]) applySearch(info.secId);
        if (i < rows.length) setTimeout(step, 0);
      };
      setTimeout(step, 0);
    });
  // la fiche sélectionnée reste visible
  jobs.push(() => {
    // sans faire défiler la page elle-même
    const box = body.querySelector(".cartes"),
      el = box?.querySelector(".mini.sel");
    if (!el || box.scrollHeight <= box.clientHeight) return;
    const top = el.getBoundingClientRect().top - box.getBoundingClientRect().top + box.scrollTop;
    if (top < box.scrollTop || top + el.offsetHeight > box.scrollTop + box.clientHeight) box.scrollTop = top - 8;
  });
}


// renderChart — Affiche un graphique natif de Grist avec Chart.js (barres, lignes, secteurs, aires…).
function renderChart(info, rows, body, jobs) {
  const type = info.sec.chartType || "bar",
    o = info.opts,
    f = info.fields;
  const pie = type === "pie" || type === "donut";
  const multi = !!o.multiseries && !pie;
  if (f.length < (multi ? 3 : 2)) {
    body.innerHTML = '<div class="msg">Graphique incomplet (colonnes manquantes)</div>';
    return;
  }
  const [a, b, ...rest] = f;
  const groupF = multi ? a : null,
    xF = multi ? b : a,
    yFs = multi ? rest : [b, ...rest];
  const num = (v) => (typeof v === "number" ? v : Number(v) || 0);

  body.innerHTML = '<div class="chart-box"><canvas></canvas></div>';
  const canvas = body.querySelector("canvas");
  let data;

  if (type === "scatter") {
    data = {
      datasets: yFs.map((y, i) => ({
        label: y.label,
        backgroundColor: PALETTE[i % PALETTE.length],
        data: rows.map((r) => ({ x: num(r[xF.colId]), y: num(r[y.colId]) })),
      })),
    };
  } else {
    const xl = rows.map((r) => textOf(xF.col, xF.opts, r[xF.colId]) || "(vide)");
    const gl = multi ? rows.map((r) => textOf(groupF.col, groupF.opts, r[groupF.colId]) || "(vide)") : null;
    const labels = [...new Set(xl)];
    const series = [];
    if (multi) {
      for (const g of new Set(gl))
        for (const y of yFs) series.push({ label: yFs.length > 1 ? `${g} – ${y.label}` : g, y, g });
    } else {
      for (const y of pie ? yFs.slice(0, 1) : yFs) series.push({ label: y.label, y, g: null });
    }
    // couleurs : une par catégorie pour un camembert, sinon une par série (palette du widget)
    const catCols = pie ? labels.map((_, j) => PALETTE[j % PALETTE.length]) : null;
    const serieColor = (s, i) => PALETTE[i % PALETTE.length];
    const datasets = series.map((s, i) => {
      const sums = new Map(labels.map((l) => [l, 0]));
      rows.forEach((r, k) => {
        if (s.g === null || gl[k] === s.g) sums.set(xl[k], sums.get(xl[k]) + num(r[s.y.colId]));
      });
      const c = serieColor(s, i);
      return {
        label: s.label,
        data: labels.map((l) => sums.get(l)),
        backgroundColor: catCols || (type === "area" ? c + "55" : c),
        borderColor: pie ? cssVar("--carte") || "#fff" : catCols || c,
        fill: type === "area",
        tension: 0.2,
        pointRadius: type === "line" ? 2 : 0,
      };
    });
    data = { labels, datasets };
  }
  const stacked = !!o.stacked;
  const chartType =
    { pie: "pie", donut: "doughnut", line: "line", area: "line", scatter: "scatter", kaplan_meier: "line" }[
      type
    ] || "bar";
  jobs.push(() => {
    // couleurs des textes et des grilles : celles du thème (clair ou sombre)
    const tc = cssVar("--texte2") || "#3a3a3a",
      gc = cssVar("--bord-doux") || "#eee";
    S.charts.push(
      new Chart(canvas, {
        type: chartType,
        data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: false,
          indexAxis: o.orientation === "h" ? "y" : "x",
          plugins: {
            legend: {
              display: pie || data.datasets.length > 1,
              position: "bottom",
              labels: { boxWidth: 10, font: { size: 11 }, color: tc },
            },
          },
          scales: pie
            ? {}
            : {
                x: { stacked, ticks: { font: { size: 11 }, color: tc }, grid: { color: gc }, border: { color: gc } },
                y: { stacked, beginAtZero: true, ticks: { font: { size: 11 }, color: tc }, grid: { color: gc }, border: { color: gc } },
              },
        },
      }),
    );
  });
}

/* ---------- Carte (widget « Map » de Grist, Leaflet) ---------- */
/* Bibliothèques chargées à la demande : versions figées + empreinte d'intégrité (SRI).
   Si le fichier servi par le CDN a été modifié, le navigateur refuse de l'exécuter. */
const LIBS = {
  leafletCss: [
    "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css",
    "sha384-sHL9NAb7lN7rfvG5lfHpm643Xkcjzp4jFvuavGOndn6pjVqS6ny56CAt3nsEVT4H",
  ],
  leaflet: [
    "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js",
    "sha384-cxOPjt7s7Iz04uaHJceBmS+qpjv2JkIHNVcuOrM+YHwZOmJGBXI00mdUXEq65HTH",
  ],
  plotly: [
    "https://cdn.jsdelivr.net/npm/plotly.js-dist-min@2.35.2/plotly.min.js",
    "sha384-cCVCZkAjYNxaYKbM8lsArLznDF/SvMFr1jcZrvOpSTCa0W40ZAdLzHCEulnUa5i7",
  ],
  clip: [
    "https://cdn.jsdelivr.net/npm/polygon-clipping@0.15.7/dist/polygon-clipping.umd.min.js",
    "sha384-2gzcIyrtB96QDjrxsFcJ1O461CWiXJ8fiHgIkJLwTgy4WTktHXTOXt4dviXz9Y5Q",
  ],
  marked: [
    "https://cdn.jsdelivr.net/npm/marked@12.0.2/marked.min.js",
    "sha384-/TQbtLCAerC3jgaim+N78RZSDYV7ryeoBCVqTuzRrFec2akfBkHS7ACQ3PQhvMVi",
  ],
  purify: [
    "https://cdn.jsdelivr.net/npm/dompurify@3.2.6/dist/purify.min.js",
    "sha384-JEyTNhjM6R1ElGoJns4U2Ln4ofPcqzSsynQkmEc/KGy6336qAZl70tDLufbkla+3",
  ],
};
// loadPart — Charge une partie du widget à la demande (0.9.5) : "carte" (ux-carte.js) ou "config" (ux-config.js,
//   qui utilise aussi le code des cartes). Script du même site, même version (?v=) ; une seule fois par page.
const PARTS = { carte: "ux-carte.js", config: "ux-config.js" };
const partP = {};
function loadPart(name) {
  if (name === "config" && !partP.config) return loadPart("carte").then(() => loadPart1("config"));
  return loadPart1(name);
}
function loadPart1(name) {
  return (partP[name] ??= new Promise((ok, ko) => {
    const s = document.createElement("script");
    s.src = `${PARTS[name]}?v=${VERSION}`;
    s.onload = () => ok();
    s.onerror = () => {
      delete partP[name];
      ko(new Error(`${PARTS[name]} introuvable`));
    };
    document.head.appendChild(s);
  }));
}
// openConfig — Ouvre le panneau de configuration (bouton ⚙, menu de Grist) après chargement de ux-config.js.
async function openConfig() {
  try {
    await loadPart("config");
  } catch (e) {
    return status(`Configuration indisponible : ${e.message}`, true);
  }
  return openConfigPanel();
}
// loadLib — Charge un script ou une feuille de style externe avec son empreinte d'intégrité (SRI).
function loadLib([src, integrity], name, css = false) {
  return new Promise((res, rej) => {
    const el = document.createElement(css ? "link" : "script");
    if (css) {
      el.rel = "stylesheet";
      el.href = src;
    } else el.src = src;
    el.integrity = integrity;
    el.crossOrigin = "anonymous";
    el.onload = res;
    el.onerror = () => {
      el.remove();
      rej(new Error(`${name} n'a pas pu être chargé`));
    };
    document.head.append(el);
  });
}
let leafletP = null;
// loadLeaflet — Charge Leaflet (cartes) à la première carte affichée.
function loadLeaflet() {
  return (leafletP ??= (
    window.L
      ? Promise.resolve()
      : Promise.all([
          loadLib(LIBS.leafletCss, "Leaflet (styles)", true).catch(() => {}),
          loadLib(LIBS.leaflet, "Leaflet"),
        ])
  ).catch((e) => {
    leafletP = null;
    throw e;
  }));
}
/* Nettoyage du HTML des étiquettes (DOMPurify) : mise en forme conservée, scripts et gestionnaires retirés.
   Sans DOMPurify, on n'affiche que le texte (DOMParser n'exécute rien). */
let purifyP = null;
// loadPurify — Charge DOMPurify (nettoyage du HTML des étiquettes de carte).
const loadPurify = () =>
  (purifyP ??= (window.DOMPurify ? Promise.resolve() : loadLib(LIBS.purify, "DOMPurify")).catch(() => {}));
// safeHtml — HTML nettoyé (mise en forme conservée, scripts retirés). Sans DOMPurify : texte seul.
function safeHtml(html) {
  if (window.DOMPurify)
    return DOMPurify.sanitize(String(html), {
      FORBID_TAGS: ["style", "form", "input", "button", "iframe", "object", "embed"],
      FORBID_ATTR: ["srcset"],
    });
  return esc(new DOMParser().parseFromString(String(html), "text/html").body.textContent || "");
}
// looksHtml — Vrai si un texte contient des balises HTML.
const looksHtml = (t) => /<[a-z][\s\S]*>/i.test(String(t || ""));
// mapSpec — Lit la configuration d'un widget carte Grist : colonnes Nom/Latitude/Longitude, fond de carte. null si ce n'est pas une carte.
function mapSpec(sec) {
  const cv = parseJSON(parseJSON(sec.options).customView, null);
  if (!cv) return null;
  const mapping = parseJSON(cv.columnsMapping, {}) || {};
  const pick = (k) => {
    const v = mapping[k];
    return Array.isArray(v) ? v[0] : v;
  };
  const isMap = /map/i.test(cv.url || "") || ("Latitude" in mapping && "Longitude" in mapping);
  if (!isMap) return null;
  const wo = parseJSON(cv.widgetOptions, {}) || {};
  return {
    name: pick("Name"),
    lat: pick("Latitude"),
    lng: pick("Longitude"),
    tiles: wo.mapSource || "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: wo.mapCopyright || "&copy; contributeurs OpenStreetMap",
  };
}
// isMapSection — Vrai si la vue est un widget carte.
const isMapSection = (sec) => !!mapSpec(sec);
/* ---------- Widget Markdown de Grist : affichage, taille du texte réglable ; bloc-notes modifiable (0.9.4.25) ---------- */
// mdSpec — Colonne « Content » du widget Markdown (mapping par colId ou numéro de colonne), sinon null.
function mdSpec(sec) {
  const cv = parseJSON(parseJSON(sec?.options).customView, null);
  if (!cv) return null;
  // widget Markdown de Grist : reconnu par son adresse (ancienne installation) ou, depuis la galerie de widgets,
  // par son identifiant (« @gristlabs/widget-markdown », sans adresse) ; à défaut, par son unique champ « Content »
  const mapping = parseJSON(cv.columnsMapping, {}) || {};
  const ids = [cv.url, cv.widgetId, cv.pluginId, cv.widgetDef?.widgetId, cv.widgetDef?.name, cv.widgetDef?.url].filter(Boolean).join(" ");
  const keys = Object.keys(mapping);
  if (!/markdown/i.test(ids) && !(keys.length === 1 && keys[0] === "Content" && !/plotly|chart/i.test(ids))) return null;
  const v = mapping.Content;
  return { content: Array.isArray(v) ? v[0] : v };
}
const isMarkdownSection = (sec) => !!mdSpec(sec);
const MD_SIZES = [
  ["", "normale (13 px)"],
  [11, "petite (11 px)"],
  [12, "12 px"],
  [14, "14 px"],
  [16, "grande (16 px)"],
  [18, "18 px"],
  [20, "très grande (20 px)"],
  [24, "24 px"],
];
// renderMarkdown — Texte Markdown de la ligne sélectionnée (comme le widget Grist), mis en forme par marked puis
// nettoyé par DOMPurify. Les liens s'ouvrent dans un nouvel onglet.
async function renderMarkdown(info, rows, body, selId, b) {
  const cols = S.meta.colsByTable.get(info.sec.tableRef) || [];
  const col =
    colByKey(cols, mdSpec(info.sec)?.content) ||
    info.fields.find((f) => ["Text", "Any"].includes(baseType(f.col)))?.col ||
    cols.find((c) => baseType(c) === "Text" && !c.colId.startsWith("gristHelper_"));
  const row = rows.find((r) => r.id === selId) || rows[0];
  // bloc-notes sans ligne (table vide, ou rien de lié à la sélection) : la première saisie crée la ligne (0.9.4.26)
  if (!col || (!row && !((b.mdEdit ?? !!b.mdNote) && S.canEdit && isEditableCol(col)))) {
    body.innerHTML = `<div class="msg">${col ? "Aucun texte à afficher" : "Widget Markdown : colonne du texte introuvable"}</div>`;
    return;
  }
  await Promise.all([
    window.marked ? null : loadLib(LIBS.marked, "marked"),
    window.DOMPurify ? null : loadLib(LIBS.purify, "DOMPurify"),
  ]);
  const size = Number(b.mdSize) || 0;
  const text = String(row?.[col.colId] ?? "");
  const fs = size ? ` style="font-size:${size}px"` : "";
  // aspect bloc-notes (mdNote) et modification depuis la page (mdEdit) se règlent séparément depuis 0.9.4.26 ;
  // une configuration antérieure (mdNote seul) reste modifiable
  const editable = b.mdEdit ?? !!b.mdNote;
  if (!b.mdNote && !editable) {
    body.innerHTML = `<div class="mdview"${fs}>${DOMPurify.sanitize(marked.parse(text))}</div>`;
    body.querySelectorAll(".mdview a[href]").forEach((a) => Object.assign(a, { target: "_blank", rel: "noopener" }));
    return;
  }
  // bloc-notes : aspect papier ; ✎ (ou double-clic) ouvre le texte Markdown brut, enregistré dans la colonne
  const canWrite = editable && S.canEdit && isEditableCol(col);
  const look = b.mdNote ? "mdnote" : "mdnote mdplain";
  const show = () => {
    body.innerHTML =
      `<div class="${look}"${fs}>` +
      (canWrite ? `<button type="button" class="mdnote-edit" title="Modifier le bloc-notes (ou double-clic sur le texte)" aria-label="Modifier le bloc-notes">✎</button>` : "") +
      (text.trim()
        ? `<div class="mdview">${DOMPurify.sanitize(marked.parse(text))}</div>`
        : `<div class="mdnote-empty">${canWrite ? "Bloc-notes vide : cliquez sur ✎ pour écrire." : "Bloc-notes vide."}</div>`) +
      `</div>`;
    body.querySelectorAll(".mdview a[href]").forEach((a) => Object.assign(a, { target: "_blank", rel: "noopener" }));
    if (!canWrite) return;
    const note = body.querySelector(".mdnote");
    body.querySelector(".mdnote-edit").addEventListener("click", edit);
    note.addEventListener("dblclick", (e) => !e.target.closest("a") && edit());
  };
  const edit = () => {
    S.editing = true; // les rendus attendent la fin de la saisie
    body.innerHTML =
      `<div class="${look} editing"${fs}><textarea class="mdnote-ta" spellcheck="true" aria-label="Texte du bloc-notes (Markdown)"></textarea>` +
      `<div class="mdnote-bar"><span class="mdnote-hint"># titre · **gras** · *italique* · - liste · [lien](https://…) — Ctrl+Entrée : enregistrer · Échap : annuler</span>` +
      `<button type="button" class="mdnote-cancel">Annuler</button><button type="button" class="mdnote-save">Enregistrer</button></div></div>`;
    const ta = body.querySelector(".mdnote-ta");
    ta.value = text;
    const fit = () => {
      ta.style.height = "auto";
      ta.style.height = `${Math.max(120, ta.scrollHeight + 4)}px`;
    };
    fit();
    ta.addEventListener("input", fit);
    ta.focus();
    const end = () => {
      S.editing = false;
      if (S.pendingRender) {
        S.pendingRender = false;
        scheduleRender();
      }
    };
    const cancel = () => {
      show();
      end();
    };
    const save = () => {
      const v = ta.value;
      if (v === text) return cancel();
      S.editing = false;
      if (row) return saveValue(body.querySelector(".mdnote"), info.tableId, row.id, col, v);
      // pas encore de ligne : création, rattachée à la sélection liée comme « + Ajouter une ligne »
      docActions([["AddRecord", info.tableId, null, { ...(S.linkSet?.[info.secId] || {}), [col.colId]: v }]])
        .then((res) => {
          if (res?.retValues?.[0]) S.sel[info.secId] = res.retValues[0];
          delete S.cache[info.tableId];
          delete S.byId[info.tableId];
        })
        .catch((e) => actionFailed(e, "Modification", "bloc-notes"))
        .finally(() => scheduleRender());
    };
    body.querySelector(".mdnote-save").addEventListener("click", save);
    body.querySelector(".mdnote-cancel").addEventListener("click", cancel);
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        save();
      } else if (e.key === "Escape") {
        e.preventDefault();
        cancel();
      }
    });
  };
  show();
}
/* Le mapping d'un widget personnalisé est stocké par numéro de colonne (colRef) ou par colId */
const colByKey = (cols, k) =>
  k == null || k === ""
    ? null
    : cols.find((c) => c.colId === k) || cols.find((c) => c.id === Number(k) && /^\d+$/.test(String(k))) || null;
// toNum — Nombre depuis une valeur ou un texte (« 48,39 » accepté).
const toNum = (v) =>
  typeof v === "number"
    ? v
    : Number(
        String(v ?? "")
          .trim()
          .replace(/\s/g, "")
          .replace(",", "."),
      );

/* Couleurs des points : couleurs des choix Grist si définies, palette par valeur, ou classes pour un nombre */
/* Couleurs bien distinctes pour la carte : 12 teintes choisies (ni rouge ni gris, réservés),
   puis des teintes générées par l'angle d'or, avec luminosité alternée */
const MAP_COLORS = [
  "#000091",
  "#E4794A",
  "#68A532",
  "#A558A0",
  "#C8AA39",
  "#009099",
  "#8D533E",
  "#6A6AF4",
  "#CE70CC",
  "#FFCA00",
  "#1F5F3A",
  "#4BA3E3",
];
// distinctColor — i-ème couleur bien distincte (palette choisie, puis teintes générées).
function distinctColor(i) {
  if (i < MAP_COLORS.length) return MAP_COLORS[i];
  const k = i - MAP_COLORS.length;
  let h = (k * 137.508 + 20) % 360;
  if (h < 15 || h > 345) h = (h + 30) % 360; // on évite le rouge des valeurs invalides
  return `hsl(${Math.round(h)}, ${k % 2 ? 55 : 70}%, ${[38, 52, 64][k % 3]}%)`;
}

/* ---------- Graphique avancé (widget Plotly de Grist) : chargement de Plotly ---------- */
let plotlyP = null;
// loadPlotly — Charge Plotly (graphiques avancés) au premier besoin.
function loadPlotly() {
  return (plotlyP ??= (window.Plotly ? Promise.resolve() : loadLib(LIBS.plotly, "Plotly")).catch((e) => {
    plotlyP = null;
    throw e;
  }));
}
/* ---------- Listes de sélection intégrées ---------- */
function isSelector(b) {
  if (b.asSelect === true) return true;
  if (b.asSelect === false) return false;
  const sec = S.meta.sections.get(b.id);
  if (sec?.parentKey !== "custom") return false;
  const cv = parseJSON(parseJSON(sec.options).customView, null);
  return /drop-?down/i.test(cv?.url || "");
}
// selectorColumn — Colonne affichée par une liste de sélection.
function selectorColumn(b, info) {
  const cols = (S.meta.colsByTable.get(info.sec.tableRef) || []).filter(
    (c) => !c.colId.startsWith("gristHelper_") && c.colId !== "manualSort",
  );
  if (b.selCol) {
    const c = cols.find((x) => x.colId === b.selCol);
    if (c) return c;
  }
  const cv = parseJSON(parseJSON(info.sec.options).customView, null);
  const mapped = Object.values(parseJSON(cv?.columnsMapping, {}) || {})
    .map((v) => (Array.isArray(v) ? v[0] : v))
    .find(Boolean);
  if (mapped) {
    const c = colByKey(cols, mapped);
    if (c) return c;
  }
  return info.fields[0]?.col || cols[0];
}
/* Synchronisation entre pages (même principe que le drop-down de Varamil : un ID de session commun) */
function selectorSyncId(b) {
  if (b.syncId !== undefined && b.syncId !== "") return String(b.syncId);
  const sec = S.meta.sections.get(b.id);
  const cv = parseJSON(parseJSON(sec?.options).customView, null);
  return String(parseJSON(cv?.widgetOptions, {})?.sessionid || "");
}
/* Clé de stockage d'une sélection partagée (0.8.9) : document + table de la liste + identifiant.
   - le document : le stockage de session est commun à tout l'onglet, donc à tous les documents Grist ouverts
     successivement (sans lui, la sélection d'un autre document, par exemple sa copie de développement,
     s'imposait) ;
   - la table : un numéro de ligne n'a de sens que dans sa table (deux listes de tables différentes portant
     le même identifiant se « synchronisaient » sur des lignes sans rapport). */
const SYNC_PREFIX = "uxwg_sync_";
function syncKey(b) {
  const sid = selectorSyncId(b);
  if (!sid) return "";
  const tid = getInfo(b.id)?.tableId || "";
  return `${SYNC_PREFIX}${S.docKey || ""}:${tid}:${sid}`;
}
// readSync — Lit la sélection partagée (0 si aucune).
function readSync(key) {
  try {
    return Number(sessionStorage.getItem(key)) || 0;
  } catch {
    return 0;
  }
}
// writeSync — Enregistre la sélection partagée.
function writeSync(key, rowId) {
  try {
    sessionStorage.setItem(key, String(rowId));
  } catch {
    /* stockage indisponible */
  }
}
window.addEventListener("storage", (ev) => {
  // autre widget ouvert dans le même onglet (autre page Grist) : même clé = même document, table et identifiant
  if (!ev.key?.startsWith(SYNC_PREFIX) || !S.meta || !ev.newValue) return;
  let hit = false;
  for (const b of S.cfg.blocks)
    if (isSelector(b) && syncKey(b) === ev.key && S.sel[b.id] !== Number(ev.newValue)) {
      S.sel[b.id] = Number(ev.newValue);
      hit = true;
    }
  if (hit) scheduleRender();
});

// renderSelectors — Affiche les listes de sélection dans l'en-tête (avec regroupement et ordre).
// pageIcon — Icône de la page affichée : celle de son lien dans le menu des pages (0.9.4.0), nettoyée par safeSvg.
//   Classe au choix : « ticon » (devant le titre), « picon » (devant les listes, page sans titre), « phicon » (impression).
function pageIcon(cls = "picon") {
  const it = (S.nav?.items || []).find((x) => x.icon && x.cfg && x.cfg === S.cfg?.name);
  const svg = it ? safeSvg(it.icon) : "";
  return svg ? svg.replace('class="nico"', `class="${cls}"`) : "";
}
async function renderSelectors(sels, ctx) {
  const box = $("#filters");
  const parts = [];
  // icône de la page, avant les listes (ou seule s'il n'y a pas de liste) — seulement si la page n'affiche pas de titre
  const ico = String(S.cfg?.title || "").trim() ? "" : pageIcon();
  if (ico) parts.push(ico);
  for (const b of sels) {
    const info = getInfo(b.id);
    const key = syncKey(b);
    try {
      const { rows } = await rowsFor(b.id, ctx);
      // sélection partagée : elle fait foi à chaque affichage (choix fait sur une autre page, y compris
      // une page du widget déjà visitée), à condition que la ligne figure dans cette liste
      if (key) {
        const v = readSync(key);
        if (v && rows.some((r) => r.id === v)) S.sel[b.id] = v;
      }
      const col = selectorColumn(b, info);
      const gcol = b.selGroup
        ? (S.meta.colsByTable.get(info.sec.tableRef) || []).find((c) => c.colId === b.selGroup)
        : null;
      await ensureRefTables(gcol ? [col, gcol] : [col]);
      const opts = parseJSON(col.widgetOptions),
        gopts = gcol ? parseJSON(gcol.widgetOptions) : null;
      const cmpFr = (x, y) => COLL.compare(x, y);
      let items = rows.map((r, i) => ({
        id: r.id,
        i,
        t: textOf(col, opts, r[col.colId]) || "(vide)",
        g: gcol ? textOf(gcol, gopts, r[gcol.colId]) || "(sans valeur)" : "",
      }));
      // groupe d'abord (ex. commune), puis ordre alphabétique du texte affiché, ou ordre de la vue Grist si choisi
      const viewOrder = b.selOrder === "vue",
        gDir = b.selGroupOrder === "desc" ? -1 : 1; // intertitres : A → Z, ou Z → A
      items.sort(
        (a, c) => (gcol ? gDir * cmpFr(a.g, c.g) : 0) || (viewOrder ? a.i - c.i : cmpFr(a.t, c.t) || a.i - c.i),
      );
      const cur = await selectedRowId(b.id, ctx);
      const opt = (x) => `<option value="${x.id}" ${x.id === cur ? "selected" : ""}>${esc(x.t)}</option>`;
      let inner = "";
      if (gcol) {
        let last = null;
        for (const x of items) {
          if (x.g !== last) {
            if (last !== null) inner += "</optgroup>";
            inner += `<optgroup label="${esc(x.g)}">`;
            last = x.g;
          }
          inner += opt(x);
        }
        if (last !== null) inner += "</optgroup>";
      } else inner = items.map(opt).join("");
      // une seule entrée possible (selon les droits) : la liste est masquée, mais sa sélection s'applique
      // et reste lisible à l'impression (selectionSummary lit aussi les listes masquées)
      const solo = items.length <= 1;
      const cap = esc(info.title);
      parts.push(
        `<label class="${solo ? "solo" : ""}" title="${cap}"><span class="fl">${cap}</span><select data-selector="${b.id}" aria-label="${cap}">${inner || "<option>(aucun choix)</option>"}</select></label>`,
      );
    } catch (e) {
      parts.push(`<label>${esc(info?.title || "")}<span class="msg err">${esc(e.message || e)}</span></label>`);
    }
  }
  const focused = document.activeElement?.dataset?.selector; // garder le focus clavier pendant le redessin
  box.innerHTML = parts.join("");
  if (focused) box.querySelector(`[data-selector="${focused}"]`)?.focus();
}
// onSelectorChange — Changement d'une liste de sélection : met à jour la sélection et relance le rendu.
function onSelectorChange(ev) {
  const t = ev.target.closest("[data-selector]");
  if (!t) return;
  if (S.sel[Number(t.dataset.selector)] === Number(t.value)) return; // « input » et « change » peuvent se suivre
  const id = Number(t.dataset.selector),
    rowId = Number(t.value);
  S.sel[id] = rowId;
  const b = S.cfg.blocks.find((x) => x.id === id),
    key = b && syncKey(b);
  if (key) {
    writeSync(key, rowId);
    for (const o of S.cfg.blocks) if (o.id !== id && isSelector(o) && syncKey(o) === key) S.sel[o.id] = rowId;
  }
  const all = [...document.querySelectorAll("#filters [data-selector]")];
  if (all.length && all[all.length - 1] === t) S.scrollTop = true; // dernière liste : on remonte en haut de page
  scheduleRender();
}
$("#filters").addEventListener("input", onSelectorChange);
$("#filters").addEventListener("change", onSelectorChange);

// advChartSpec — Lit la définition d'un graphique avancé (widget Plotly de Grist) et ses sources de données.
function advChartSpec(sec) {
  const cv = parseJSON(parseJSON(sec.options).customView, null);
  if (!cv) return null;
  const wo = parseJSON(cv.widgetOptions, {});
  const cands = [wo, ...Object.values(wo)]
    .map((x) => parseJSON(x, null))
    .filter((x) => x && typeof x === "object");
  for (const c of cands) {
    for (const d of [c, parseJSON(c.figure, null), parseJSON(c.chart, null)].filter(Boolean)) {
      const data = parseJSON(d.data, null);
      if (Array.isArray(data)) return { data, layout: parseJSON(d.layout, {}) };
    }
  }
  return { data: null, url: cv.url || "", keys: Object.keys(wo) };
}
// renderAdvChart — Affiche un graphique avancé avec Plotly, en remplaçant les références gristsrc par les données.
// fixAggregate — Transformations « Aggregate » de l'éditeur Plotly : regroupées par l'axe des catégories (x, ou y en
//   barres horizontales) quand le regroupement choisi est vide ou porte sur une colonne agrégée elle-même (par
//   exemple « Groups = Défavorisé » pour la moyenne de Défavorisé) : regrouper par la valeur à agréger n'agrège
//   rien, chaque ligne restait une barre. C'est ce qu'affiche le graphique avancé de Grist.
function fixAggregate(data, src) {
  data.forEach((t, ti) => {
    const t0 = src?.[ti] || {};
    (t?.transforms || []).forEach((tr, k) => {
      if (tr?.type !== "aggregate") return;
      const g0 = t0.transforms?.[k]?.groupssrc;
      const aggSrcs = (tr.aggregations || []).filter((a) => a && a.enabled !== false).map((a) => t0[`${a.target}src`]);
      const empty = !Array.isArray(tr.groups) || !tr.groups.length;
      if (!g0 || empty || aggSrcs.includes(g0)) {
        delete tr.groupssrc;
        tr.groups = t.orientation === "h" ? "y" : "x";
      }
      // étiquettes reprenant les valeurs (texte = colonne des valeurs) : celles du résultat agrégé, arrondies au
      // dixième, et non la première ligne de chaque groupe
      const vk = t.orientation === "h" ? "x" : "y";
      if (t0.textsrc && t0.textsrc === t0[`${vk}src`] && !t.texttemplate) t.texttemplate = `%{${vk}:.1~f}`;
    });
    aggMulti(t);
  });
}
// aggMulti — (0.9.6.13) Axe à catégories imbriquées (X ou Y sur plusieurs colonnes, ex. NIVEAU + RENTREE) avec une
//   transformation « Aggregate » : Plotly prend alors l'axe pour un tableau de 2 éléments et ne dessine que 2 barres.
//   L'agrégation est faite ici, par combinaison de catégories (ou par la colonne de regroupement choisie), puis la
//   transformation est retirée.
const AGG_FN = {
  count: (a) => a.length,
  sum: (a) => a.reduce((x, y) => x + (Number(y) || 0), 0),
  avg: (a) => (a.length ? AGG_FN.sum(a) / a.length : null),
  min: (a) => Math.min(...a.map(Number)),
  max: (a) => Math.max(...a.map(Number)),
  first: (a) => a[0],
  last: (a) => a[a.length - 1],
  median: (a) => {
    const v = a.map(Number).sort((x, y) => x - y),
      m = v.length >> 1;
    return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
  },
  range: (a) => AGG_FN.max(a) - AGG_FN.min(a),
  change: (a) => Number(a[a.length - 1]) - Number(a[0]),
};
function aggMulti(t) {
  const ck = t?.orientation === "h" ? "y" : "x",
    cats = t?.[ck];
  if (!Array.isArray(cats) || !cats.length || !cats.every(Array.isArray)) return;
  const trs = t.transforms || [],
    k = trs.findIndex((x) => x?.type === "aggregate" && x.enabled !== false);
  if (k < 0) return;
  const tr = trs[k],
    n = cats[0].length;
  const keyOf = Array.isArray(tr.groups) && tr.groups.length === n && !tr.groups.some(Array.isArray) ? (i) => String(tr.groups[i]) : (i) => cats.map((a) => a[i]).join("\u001f");
  const idx = new Map(); // groupe → numéros de lignes, dans l'ordre de première apparition
  for (let i = 0; i < n; i++) {
    const g = keyOf(i);
    if (!idx.has(g)) idx.set(g, []);
    idx.get(g).push(i);
  }
  const groups = [...idx.values()];
  const fn = new Map((tr.aggregations || []).filter((a) => a && a.enabled !== false).map((a) => [a.target, AGG_FN[a.func] || AGG_FN.first]));
  // étiquettes reprenant les valeurs (texte = colonne des valeurs) : même calcul que les valeurs
  const vk = ck === "x" ? "y" : "x";
  if (!fn.has("text") && fn.has(vk) && Array.isArray(t.text) && Array.isArray(t[vk]) && t.text.length === n && t.text.every((x, i) => x === t[vk][i])) fn.set("text", fn.get(vk));
  const walk = (obj, path) => {
    for (const [key, v] of Object.entries(obj)) {
      if (key === "transforms") continue;
      const p = path ? `${path}.${key}` : key;
      if (Array.isArray(v) && v.length === n && !v.some(Array.isArray)) {
        const f = fn.get(p) || AGG_FN.first;
        obj[key] = groups.map((ix) => f(ix.map((i) => v[i])));
      } else if (Array.isArray(v) && v.length && v.every((a) => Array.isArray(a) && a.length === n)) {
        obj[key] = v.map((a) => groups.map((ix) => a[ix[0]])); // catégories imbriquées : celles du groupe
      } else if (v && typeof v === "object" && !Array.isArray(v)) walk(v, p);
    }
  };
  walk(t, "");
  t.transforms = trs.filter((_, i) => i !== k);
  if (!t.transforms.length) delete t.transforms;
}
async function renderAdvChart(info, rows, body, jobs) {
  const spec = advChartSpec(info.sec);
  if (!spec?.data) {
    // diagnostic : description du widget dans Grist (sans ses options, parfois volumineuses)
    const cv = parseJSON(parseJSON(info.sec.options).customView, null);
    const raw = cv ? JSON.stringify({ ...cv, widgetOptions: undefined }).slice(0, 400) : "aucune description";
    body.innerHTML = `<div class="msg">Widget personnalisé non reconnu (ni graphique avancé, ni texte Markdown, ni carte)${spec ? ` — url : ${esc(spec.url) || "aucune"} ; options : ${esc(spec.keys.join(", ") || "aucune")}` : ""}<br><small style="font-family:monospace;word-break:break-all">${esc(raw)}</small></div>`;
    return;
  }
  const cols = S.meta.colsByTable.get(info.sec.tableRef) || [];
  await ensureRefTables(cols);
  const byName = new Map();
  for (const c of cols) {
    if (c.label && !byName.has(c.label)) byName.set(c.label, c);
  }
  for (const c of cols) byName.set(c.colId, c);
  const conv = (c, v) => {
    const t = baseType(c);
    if (isErr(v)) return null;
    if (t === "Numeric" || t === "Int" || t === "Bool") return v;
    if (t === "Date" && typeof v === "number") return new Date(v * 1000).toISOString().slice(0, 10);
    if (t === "DateTime" && typeof v === "number") return new Date(v * 1000).toISOString();
    return textOf(c, parseJSON(c.widgetOptions), v);
  };
  const seen = [],
    matched = [];
  const fill = (obj) => {
    // remplace chaque « xxxsrc: 'Colonne' » par les valeurs de la colonne
    if (!obj || typeof obj !== "object") return;
    for (const [k, v] of Object.entries(obj)) {
      const srcs = k.endsWith("src")
        ? typeof v === "string"
          ? [v]
          : Array.isArray(v) && v.every((x) => typeof x === "string")
            ? v
            : null
        : null;
      if (srcs) {
        seen.push(`${k}=${srcs.join("+")}`);
        const cols = srcs.map((x) => {
          const m = /^gristsrc:(\d+)$/.exec(x);
          return m ? S.meta.cols.get(Number(m[1])) : byName.get(x);
        });
        if (cols.every(Boolean)) {
          matched.push(...srcs);
          const arrs = cols.map((c) => rows.map((r) => conv(c, r[c.colId])));
          // une colonne → tableau simple ; plusieurs → axe à catégories imbriquées (ex. NIVEAU puis RENTREE)
          obj[k.slice(0, -3)] = arrs.length === 1 ? arrs[0] : arrs;
        }
      } else if (typeof v === "object") fill(v);
    }
  };
  const data = JSON.parse(JSON.stringify(spec.data));
  data.forEach(fill);
  fixAggregate(data, spec.data);
  // nom d'une série : celui de la trace, sinon le libellé de la colonne de ses valeurs (graphique converti depuis
  // un graphique natif : les traces n'ont souvent pas de nom, Plotly affiche « trace 0 »)
  const srcLabel = (t0) => {
    const v = t0?.[t0?.orientation === "h" ? "xsrc" : "ysrc"];
    if (typeof v !== "string") return "";
    const m = /^gristsrc:(\d+)$/.exec(v);
    const c = m ? S.meta.cols.get(Number(m[1])) : byName.get(v);
    return c ? c.label || c.colId : v;
  };
  // traces sans nom : le libellé de leur colonne de valeurs (légende lisible au lieu de « trace 0 »)
  data.forEach((t, ti) => {
    if (t && t.type !== "pie" && !t.name && data.length > 1) {
      const n = srcLabel(spec.data[ti]);
      if (n) t.name = n;
    }
  });
  // camemberts : les étiquettes longues passent à la ligne (Plotly ne le fait pas) et la marge s'agrandit au
  // besoin pour les étiquettes placées à l'extérieur, qui étaient coupées au bord du bloc
  const wrapLabel = (l, max = 14) => {
    const words = String(l ?? "").split(/\s+/).filter(Boolean);
    if (String(l ?? "").length <= max || words.length < 2) return l;
    const lines = [];
    for (const w of words) {
      const last = lines[lines.length - 1];
      if (last && (last + " " + w).length <= max) lines[lines.length - 1] = last + " " + w;
      else lines.push(w);
    }
    return lines.join("<br>");
  };
  for (const t of data)
    if (t?.type === "pie") {
      t.automargin = true;
      // le nom des parts sur le graphique passe par « text » (coupé en lignes) ; « labels » reste intact pour la
      // légende et les couleurs
      const ti = String(t.textinfo || "percent");
      if (Array.isArray(t.labels) && /label/.test(ti) && !t.text) {
        t.text = t.labels.map((l) => (Array.isArray(l) ? l.join(" ") : wrapLabel(l)));
        t.textinfo = ti.replace("label", "text");
      }
    }
  if (!matched.length) {
    body.innerHTML =
      `<div class="msg">Graphique avancé : aucune colonne reconnue.<br>Références trouvées : ${esc(seen.join(" · ") || "aucune")}<br>` +
      `Traces : ${esc(JSON.stringify(spec.data).slice(0, 300))}</div>`;
    return;
  }
  const layout = {
    ...JSON.parse(JSON.stringify(spec.layout || {})),
    autosize: true,
    margin: { l: 45, r: 10, t: spec.layout?.title ? 34 : 10, b: 40 },
    font: { family: "Marianne, Arial, sans-serif", size: 11, color: cssVar("--texte2") || "#3a3a3a" },
    paper_bgcolor: cssVar("--carte") || "#fff",
    plot_bgcolor: cssVar("--carte") || "#fff",
  };
  // axes : grilles et traits aux couleurs du thème, sauf réglage explicite du graphique
  for (const k of ["xaxis", "yaxis", ...Object.keys(layout).filter((x) => /^[xy]axis\d+$/.test(x))]) {
    const ax = (layout[k] = { ...(layout[k] || {}) });
    ax.gridcolor ??= cssVar("--bord-doux") || "#eee";
    ax.zerolinecolor ??= cssVar("--bord") || "#ddd";
    ax.linecolor ??= cssVar("--bord") || "#ddd";
  }
  // axe de catégories (texte, ou catégories imbriquées sur plusieurs colonnes) : la plage enregistrée avec le
  //   graphique (xaxis.range) date du moment du réglage ; si le nombre de barres a changé depuis (liaison, filtre),
  //   elle n'en montrait qu'une partie (0.9.6.14). Elle est recalculée d'après les données.
  for (const t of data) {
    for (const d of ["x", "y"]) {
      const v = t?.[d];
      const cat = Array.isArray(v) && v.length && (v.every(Array.isArray) || v.some((x) => typeof x === "string" && x.trim() !== "" && !Number.isFinite(Number(x)) && Number.isNaN(Date.parse(x))));
      if (!cat) continue;
      const ax = layout[`${d}axis${String(t[`${d}axis`] || d).slice(1)}`];
      if (ax && (ax.type === undefined || ax.type === "category" || ax.type === "multicategory")) {
        delete ax.range;
        ax.autorange = true;
      }
    }
  }
  delete layout.width;
  // camemberts : quand les parts portent déjà leur nom, la légende fait double emploi et recouvrait les étiquettes
  // placées à l'extérieur : elle est masquée (sauf si la légende est explicitement demandée dans le graphique)
  const pies = data.filter((t) => t?.type === "pie");
  if (pies.length && pies.every((t) => /text|label/.test(String(t.textinfo || ""))) && spec.layout?.showlegend !== true)
    layout.showlegend = false;
  body.innerHTML = '<div class="plot-box"></div>';
  const el = body.querySelector(".plot-box");
  delete layout.height;
  jobs.push(async () => {
    await loadPlotly();
    new ResizeObserver(() => {
      if (!el.isConnected || !el.data || el._uxPrinting) return;
      Plotly.Plots.resize(el);
    }).observe(el);
    await Plotly.newPlot(el, data, layout, { displayModeBar: false, responsive: true });
  });
}
// graphiques avancés à l'impression : redessinés à la largeur du bloc sur le papier (A4 paysage, 277 mm utiles)
window.addEventListener("beforeprint", () => {
  if (!window.Plotly) return;
  const pageW = (277 * 96) / 25.4;
  document.querySelectorAll(".plot-box").forEach((el) => {
    if (!el.data) return;
    const blk = el.closest(".block");
    const span = Number(getComputedStyle(blk || el).getPropertyValue("--span")) || 6;
    const wide = blk?.classList.contains("printwide");
    el._uxPrinting = true;
    // largeur du bloc sur le papier : le graphique y est redessiné (sinon il garde sa largeur d'écran et se coupe)
    const w = Math.round(wide ? pageW - 20 : (pageW * span) / 6 - 24);
    try {
      Plotly.relayout(el, { width: w });
    } catch {
      /* graphique non dessiné */
    }
  });
});
window.addEventListener("afterprint", () => {
  if (!window.Plotly) return;
  document.querySelectorAll(".plot-box").forEach((el) => {
    if (!el._uxPrinting) return;
    el._uxPrinting = false;
    try {
      Plotly.relayout(el, { width: null, autosize: true }).then(() => Plotly.Plots.resize(el));
    } catch {
      /* graphique retiré */
    }
  });
});

/* Sélection des widgets natifs de la page (ex. listes déroulantes en cascade).
   Grist transmet au widget la ligne choisie dans le widget qu'il « sélectionne par » ;
   on l'applique aux sections de même table, puis on remonte la chaîne de liaisons. */
function ancestorSections() {
  const set = new Set();
  for (const b of S.cfg.blocks) {
    let s = S.meta.sections.get(b.id),
      g = 0;
    while (s?.linkSrcSectionRef && g++ < 12) {
      if (!isRendered(s.linkSrcSectionRef)) set.add(s.linkSrcSectionRef);
      s = S.meta.sections.get(s.linkSrcSectionRef);
    }
  }
  return set;
}
// computeExtSel — Sélection reçue de Grist (ligne courante du widget) propagée vers les vues sources absentes de la page.
async function computeExtSel() {
  S.extSel = new Map();
  if (!S.ext.rowId || !S.ext.tableId) return;
  for (const secId of ancestorSections()) {
    if (getInfo(secId)?.tableId === S.ext.tableId) await propagateUp(secId, S.ext.rowId, 0);
  }
}
// propagateUp — Remonte une sélection le long de la chaîne de liaisons.
async function propagateUp(secId, rowId, depth) {
  S.extSel.set(secId, rowId);
  const info = getInfo(secId),
    sec = info?.sec,
    srcId = sec?.linkSrcSectionRef;
  if (!srcId || depth > 10 || isRendered(srcId) || S.extSel.has(srcId)) return;
  const src = getInfo(srcId);
  if (!src?.tableId) return;
  const row = (await fetchRows(info.tableId), S.byId[info.tableId].get(rowId));
  if (!row) return;
  const srcRows = await fetchRows(src.tableId);
  const sCol = sec.linkSrcColRef ? S.meta.cols.get(sec.linkSrcColRef)?.colId : null;
  const tCol = sec.linkTargetColRef ? S.meta.cols.get(sec.linkTargetColRef)?.colId : null;
  const first = (v) => (isList(v) ? v[1] : v);
  let srcRowId = 0;
  if (tCol && !sCol) srcRowId = first(row[tCol]);
  else if (tCol && sCol) srcRowId = srcRows.find((r) => same(first(r[sCol]), first(row[tCol])))?.id;
  else if (sCol)
    srcRowId = srcRows.find((r) => {
      const v = r[sCol];
      return isList(v) ? v.includes(rowId) : v === rowId;
    })?.id;
  else if (src.tableId === info.tableId) srcRowId = rowId;
  else {
    const pairs = summaryPairs(src, info);
    if (pairs.length) srcRowId = srcRows.find((r) => pairs.every(([sc, tc]) => same(r[sc], row[tc])))?.id;
  }
  if (srcRowId) await propagateUp(srcId, srcRowId, depth + 1);
}

// render — RENDU PRINCIPAL. Recalcule toute la page ; un rendu plus récent annule le précédent (renderSeq).
async function render() {
  if (!S.ready || !S.meta || S.choosing || S.gated) return;
  fixColIds(S.cfg); // colonnes renommées dans Grist depuis l'enregistrement de la configuration
  if (S.editing) {
    S.pendingRender = true;
    return;
  }
  const my = (S.renderSeq = (S.renderSeq || 0) + 1); // un rendu plus récent annule celui-ci
  const stale = () => my !== S.renderSeq;
  applyTheme(S.nav?.theme); // apparence DSFR ou neutre (peut changer à l'enregistrement de la configuration)
  // titre de la page, précédé de son icône de menu (comme sur le lien du menu) ; sans titre, l'icône va devant les listes
  $("#title").innerHTML = String(S.cfg.title || "").trim() ? `${pageIcon("ticon")}<span>${esc(S.cfg.title)}</span>` : "";
  renderForms();
  const setNoTitle = () =>
    $("#top").classList.toggle(
      "notitle",
      !String(S.cfg.title || "").trim() && !!($("#pnav").childElementCount || $("#filters").childElementCount),
    );
  renderNav();
  const grid = $("#grid");
  const scrolls = {};
  grid.querySelectorAll("[data-sec] .tbl-wrap").forEach((w) => {
    scrolls[w.closest("[data-sec]").dataset.sec] = w.scrollTop;
  });
  const winY = window.scrollY;

  const blocks = S.cfg.blocks.filter((b) => S.meta.sections.has(b.id));
  if (!blocks.length) {
    status(
      S.isAdmin
        ? "Aucune vue sélectionnée. Cliquer sur ⚙ pour choisir les vues à afficher."
        : "Cette page n'est pas encore configurée.",
    );
    grid.replaceChildren();
    $("#filters").replaceChildren();
    return;
  }
  status("");
  try {
    await computeExtSel();
  } catch {
    S.extSel = new Map();
  }
  grid.classList.toggle("dense", S.cfg.dense !== false && !S.cfg.flux);
  grid.classList.toggle("masonry", !!S.cfg.masonry && !S.cfg.flux);
  grid.classList.toggle("flux", !!S.cfg.flux);
  grid.style.setProperty("--ch", `${S.cfg.chartHeight || 260}px`);
  const ctx = { rows: new Map() },
    frag = document.createDocumentFragment(),
    jobs = [];
  // toutes les tables en parallèle avant le calcul des blocs ; code des cartes chargé si la page en a une (0.9.5)
  const needMap = blocks.some((b) => isMapSection(getInfo(b.id)?.sec));
  await Promise.all([
    prefetch(S.cfg, SPL.on ? (k, n) => splashStep(`Lecture des données : ${k} / ${n}`, 0.35 + (0.5 * k) / n) : null),
    needMap ? loadPart("carte").catch((e) => status(`Cartes indisponibles : ${e.message}`, true)) : null,
  ]);
  if (stale()) return;
  await renderSelectors(blocks.filter(isSelector), ctx);
  setNoTitle();

  let current = "",
    shown = 0,
    splashI = 0, // blocs mis en forme (progression de l'écran de chargement)
    withData = 0; // blocs qui ont au moins une ligne (option « seulement si la page a d'autres données »)
  const dataNames = []; // leurs titres, pour le diagnostic de la console
  let
    interrupted = false;
  const skipped = { unsupported: [], empty: [] }; // diagnostic : pourquoi un bloc n'est pas affiché
  const t0 = performance.now();
  const watch = setInterval(() => {
    if (current) status(`Calcul en cours : « ${current} »…`);
  }, 700);
  try {
    for (const b of blocks.filter((x) => !isSelector(x))) {
      const info = getInfo(b.id);
      if (!SUPPORTED.includes(info.kind)) {
        skipped.unsupported.push(`${info.title} (${info.kind})`);
        continue;
      }
      current = info.title;
      if (SPL.on) splashStep(`Mise en forme : ${info.title}`, 0.85 + (0.13 * ++splashI) / blocks.length);
      await new Promise((r) => setTimeout(r, 0)); // rend la main : l'indicateur et les clics restent actifs
      if (stale()) {
        interrupted = true;
        return;
      }
      const tb = performance.now();
      if (S.cfg.flux && b.newLine) {
        const br = document.createElement("div");
        br.className = "brk";
        frag.append(br);
      }
      try {
        let { rows } = await rowsFor(b.id, ctx);
        if (info.kind === "record") rows = applyUserView(info, rows); // tri et filtres choisis dans les en-têtes
        const qcs = [qfCol(b, info, 1), qfCol(b, info, 2), qfCol(b, info, 3)].filter(Boolean);
        if (qcs.length) await ensureRefTables(qcs); // champ du filtre rapide de type référence : texte affiché
        const before = rows.length; // lignes avant le filtre rapide
        const qfCtl = qfHtml(b, info, rows); // filtre rapide : sélecteur calculé sur toutes les lignes (affiché même sans données)…
        const isMapBlk = info.kind === "custom" && isMapSection(info.sec);
        // seconde ligne de l'en-tête : filtre libre et outils de la carte (le titre garde la place)
        const row2 = qfRowHtml(b, info, qfApplyOne(b, info, qfApplyOne(b, info, qfDropExcluded(b, info, rows), 1), 2)) + (isMapBlk ? mapCtlHtml(b) : "");
        rows = qfApply(b, info, rows); // …puis seules les lignes choisies sont affichées
        const selId = await selectedRowId(b.id, ctx);
        const isSingle = info.kind === "single";
        const noteBlk = (b.mdEdit ?? !!b.mdNote) && S.canEdit && info.kind === "custom" && isMarkdownSection(info.sec); // texte modifiable sans ligne : saisie possible
        if (!rows.length && !noteBlk && !(isSingle && S.byId[info.tableId]?.get(selId))) {
          // diagnostic : table complète vs filtrée, et origine de la liaison
          try {
            const total = (await fetchRows(info.tableId)).length,
              srcId = info.sec.linkSrcSectionRef,
              src = srcId ? getInfo(srcId) : null;
            const srcSel = src ? await selectedRowId(srcId, ctx) : 0;
            const srcRow = src ? S.byId[src.tableId]?.get(srcSel) : null;
            const how = !src
              ? "aucune liaison"
              : `lié à « ${src.title} »${isRendered(srcId) ? "" : " (vue absente de la page"}${!isRendered(srcId) ? (S.extSel.has(srcId) ? ", sélection reçue de Grist)" : ", pas de sélection reçue de Grist)") : ""}, ligne sélectionnée : ${srcSel || "aucune"}${srcRow ? "" : srcSel ? " (introuvable)" : ""}`;
            skipped.detail = (skipped.detail || []).concat(
              `${info.title} : 0 ligne sur ${total} dans ${info.tableId} — ${how}`,
            );
          } catch {
            /* diagnostic facultatif */
          }
          // bloc masqué s'il n'a aucune donnée ; il reste affiché seulement si c'est le filtre rapide qui l'a vidé
          // (pour pouvoir revenir à « Tous »)
          if (S.cfg.hideEmptyBlocks && !(before && (qfCur(b) || qfCur(b, 2))) && !blockAddable(b, info)) {
            skipped.empty.push(info.title);
            continue;
          }
          const el = blockShell(b, info, KIND[info.kind], qfCtl, row2); // le filtre reste affiché pour revenir à « Tous »
          el.classList.add("empty");
          if (b.needOthers) el.classList.add("needothers"); // retiré après coup si aucun autre bloc n'a de données
          el.querySelector(".bb").textContent = "Aucune donnée";
          if (blockAddable(b, info)) el.querySelector(".bb").insertAdjacentHTML("beforeend", addBtn(b, false));
          frag.append(el);
          continue;
        }
        if (rows.length) {
          withData++;
          dataNames.push(`${info.title} (${rows.length})`);
        }
        const searchable =
          (info.kind === "record" || info.kind === "detail" || (info.kind === "single" && b.asList)) &&
          rows.length > 12;
        const search = searchable
          ? `<input class="search" data-search="${b.id}" placeholder="Filtrer…" value="${esc(S.search[b.id] || "")}">`
          : "";
        const badge =
          info.kind === "chart"
            ? KIND.chart
            : info.kind === "custom"
              ? isMarkdownSection(info.sec)
                ? "Texte"
                : "Graphique avancé"
              : `${rows.length} ligne${rows.length > 1 ? "s" : ""}`;
        const el = blockShell(b, info, badge, qfCtl + search, row2);
        const body = el.querySelector(".bb");
        if (info.kind === "record") renderTable(info, rows, body, selId, jobs);
        else if (isSingle && b.asList)
          renderCards(info, rows, body, selId, jobs); // fiche affichée comme liste de fiches
        else if (isSingle) renderSingle(info, rows, body, selId, el);
        else if (info.kind === "detail") renderCards(info, rows, body, selId, jobs);
        else if (info.kind === "chart") renderChart(info, rows, body, jobs);
        else if (info.kind === "custom" && isMapSection(info.sec))
          await renderMap(info, rows, body, jobs, selId, b);
        else if (info.kind === "custom" && isMarkdownSection(info.sec)) await renderMarkdown(info, rows, body, selId, b);
        else if (info.kind === "custom") await renderAdvChart(info, rows, body, jobs);
        if (blockAddable(b, info)) body.insertAdjacentHTML("beforeend", addBtn(b));
        frag.append(el);
        shown++;
        const ms = Math.round(performance.now() - tb);
        if (ms > 300)
          console.info(
            `[UX widget] « ${info.title} » (${KIND[info.kind] || info.kind}) : ${rows.length} lignes, ${ms} ms`,
          );
      } catch (e) {
        const el = blockShell(b, info, "erreur");
        el.querySelector(".bb").innerHTML = `<div class="msg err">${esc(e.message || e)}</div>`;
        frag.append(el);
      }
    }
    // bloc vide réglé « seulement si la page a d'autres données » (0.9.5.5) : retiré quand aucun autre bloc n'en a
    if (!withData)
      [...frag.children]
        .filter((el) => el.classList.contains("needothers"))
        .forEach((el) => {
          skipped.empty.push(el.querySelector(".bt")?.textContent || "");
          el.remove();
        });
  } finally {
    clearInterval(watch);
    if (current) status("");
    console.info(
      `[UX widget] page « ${S.cfg.name} » ${interrupted ? "interrompue (un rendu plus récent a pris le relais)" : "calculée"} en ${Math.round(performance.now() - t0)} ms` +
        ` — blocs : ${blocks.length} configurés, ${blocks.filter(isSelector).length} liste(s) de sélection, ${shown} affichés` +
        (skipped.empty.length ? `, ${skipped.empty.length} vides masqués [${skipped.empty.join(" ; ")}]` : "") +
        (skipped.unsupported.length
          ? `, ${skipped.unsupported.length} non pris en charge [${skipped.unsupported.join(" ; ")}]`
          : "") +
        ` — widget posé sur ${S.ext.tableId || "?"}, ligne Grist ${S.ext.rowId || "aucune"}` +
        ` — blocs avec des lignes : ${dataNames.length ? dataNames.join(" ; ") : "aucun"}` +
        (skipped.detail?.length ? `\n  ${skipped.detail.join("\n  ")}` : ""),
    );
  }
  if (stale()) return;
  insertSeparators(frag);
  // jamais de page blanche : message simple (le détail reste dans la console)
  if (!frag.childElementCount) {
    const d = document.createElement("div");
    d.className = "msg";
    d.style.padding = "24px";
    d.textContent =
      skipped.unsupported.length && !skipped.empty.length
        ? `Type de vue non pris en charge : ${skipped.unsupported.join(", ")}`
        : "Aucune donnée, pas d'élément sélectionné";
    frag.append(d);
  }
  S.charts.forEach((c) => c.destroy());
  S.charts = [];
  if (window.Plotly) grid.querySelectorAll(".plot-box").forEach((el) => Plotly.purge(el));
  S.mapTeardown = true; // les fenêtres fermées par la suppression des cartes seront rouvertes
  S.maps.forEach((m) => m.remove());
  S.mapTeardown = false;
  S.maps = [];
  grid.replaceChildren(frag);
  renderNativeLinks(blocks);
  if (S.maxed && !grid.querySelector(".maxed")) {
    // bloc plein écran disparu (vue retirée, bloc vide masqué…)
    S.maxed = null;
    $("#backdrop")?.classList.remove("on");
    document.body.style.overflow = "";
  }
  lockColumns(grid);
  fitQf(grid); // filtres rapides : présentation selon la place
  freezeColumns(grid);
  setupMasonry(grid);
  stackSticky(grid); // blocs figés empilés les uns sous les autres
  updateFoldButton();
  if (!S.prefetchedOthers) {
    S.prefetchedOthers = true;
    prefetchOthers();
  }
  jobs.forEach((j) =>
    Promise.resolve()
      .then(j)
      .catch((e) => status(e.message || String(e), true)),
  );
  grid.querySelectorAll("[data-sec] .tbl-wrap").forEach((w) => {
    const s = scrolls[w.closest("[data-sec]").dataset.sec];
    if (s) w.scrollTop = s;
  });
  for (const id of Object.keys(S.search)) applySearch(Number(id));
  // filtre libre : colonne qui vient d'être choisie → sa liste de valeurs s'ouvre aussitôt
  if (S.qf3Auto) {
    const tog = grid.querySelector(`[data-qf3tog="${S.qf3Auto}"]`);
    S.qf3Auto = null;
    if (tog) requestAnimationFrame(() => qf3Open(tog));
  }
  if (S.scrollTop) {
    S.scrollTop = false;
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else window.scrollTo(0, winY);
}
// insertSeparators — (0.9.7.0) Séparateurs de la page (b.sep : nom, commentaire, largeur), placés devant la
//   première vue affichée qui les suit. Un séparateur sans vue affichée avant le suivant (droits, blocs vides
//   masqués) n'apparaît pas. Il commence toujours une nouvelle rangée.
function insertSeparators(frag) {
  const els = new Map([...frag.children].filter((e) => e.dataset.sec).map((e) => [e.dataset.sec, e]));
  let pending = null;
  for (const b of S.cfg.blocks) {
    if (b.sep) {
      pending = b;
      continue;
    }
    const el = els.get(String(b.id));
    if (!el || !pending) continue;
    const d = document.createElement("div");
    d.className = "usep";
    d.setAttribute("style", S.cfg.flux ? "flex:0 0 100%;" : `grid-column:1 / span ${Math.min(Number(pending.width) || 6, 6)};--span:6;`);
    d.innerHTML = `${pending.name ? `<h2 class="usep-t">${esc(pending.name)}</h2>` : ""}${pending.note ? `<div class="usep-n">${esc(pending.note)}</div>` : ""}`;
    el.before(d);
    pending = null;
  }
}
// scheduleRender — Demande un rendu (regroupe les demandes rapprochées ; différé pendant une édition).
function scheduleRender() {
  if (S.editing) {
    S.pendingRender = true;
    return;
  }
  clearTimeout(S.renderTimer);
  S.renderTimer = setTimeout(() => render().catch((e) => status(e.message, true)), 60);
}

// applySearch — Filtre les lignes affichées d'un bloc selon le champ « Filtrer… ».
function applySearch(secId) {
  const q = (S.search[secId] || "").toLowerCase().trim();
  let shown = 0;
  document.querySelectorAll(`[data-sec="${secId}"] tbody tr, [data-sec="${secId}"] .mini`).forEach((tr) => {
    tr.hidden = !!q && !tr.dataset.text.includes(q);
    if (!tr.hidden) shown++;
  });
  const rc = document.querySelector(`[data-sec="${secId}"] .rowcount`);
  if (rc) rc.textContent = q ? `${shown.toLocaleString("fr-FR")} sur ${rowCountText(Number(rc.dataset.total))}` : rowCountText(Number(rc.dataset.total));
}
// rowCountText — « 1 ligne », « 686 lignes ».
const rowCountText = (n) => `${n.toLocaleString("fr-FR")} ligne${n > 1 ? "s" : ""}`;
// hasRenderedDependents — Vrai si d'autres blocs affichés dépendent de la sélection de cette vue.
function hasRenderedDependents(secId) {
  return S.cfg.blocks.some((b) => {
    let s = S.meta.sections.get(b.id),
      g = 0;
    while (s?.linkSrcSectionRef && g++ < 10) {
      if (s.linkSrcSectionRef === secId) return true;
      s = S.meta.sections.get(s.linkSrcSectionRef);
    }
    return false;
  });
}

/* ---------- Interactions ---------- */
function onRlink(ev) {
  const a = ev.target.closest(".rlink");
  if (!a) return false;
  ev.preventDefault();
  ev.stopPropagation();
  openRecordCard(a.dataset.rt, Number(a.dataset.rr));
  return true;
}
$("#rc").addEventListener("click", (ev) => {
  if (onRlink(ev)) return;
  if (ev.target.closest("[data-rcclose]")) return closeRecordCard();
  if (ev.target.closest("[data-rcback]")) {
    rcHist.pop();
    const [t, r] = rcHist[rcHist.length - 1];
    openRecordCard(t, r, false);
  }
});
$("#rcBack").addEventListener("click", closeRecordCard);
document.addEventListener(
  "keydown",
  (ev) => {
    if (ev.key === "Escape" && $("#rc").classList.contains("on")) {
      ev.stopPropagation();
      closeRecordCard();
    }
  },
  true,
);
// selectRow — Sélection d'une ligne au clic : marque la ligne et met à jour les blocs liés.
function selectRow(rowEl) {
  const block = rowEl?.closest("[data-sec]");
  if (!block) return;
  const id = Number(block.dataset.sec),
    rid = Number(rowEl.dataset.row);
  // la sélection est marquée tout de suite, même si un recalcul des blocs liés suit
  block.querySelectorAll(".sel").forEach((x) => x.classList.remove("sel"));
  rowEl.classList.add("sel");
  if (S.sel[id] === rid) return;
  S.sel[id] = rid;
  if (hasRenderedDependents(id)) scheduleRender();
}
// addRow — Ajoute un enregistrement dans la table du bloc (AddRecord), lié à la sélection en cours
// (liaison Grist), puis le sélectionne et ouvre la saisie de son premier champ modifiable.
async function addRow(secId, btn) {
  const b = S.cfg.blocks.find((x) => x.id === secId),
    info = getInfo(secId);
  if (!blockAddable(b, info)) return;
  btn.disabled = true;
  try {
    const res = await docActions([["AddRecord", info.tableId, null, { ...(S.linkSet?.[secId] || {}) }]]);
    const rid = res?.retValues?.[0];
    const ref = info.sec.tableRef;
    for (const [id, t] of S.meta.tables)
      if (id === ref || t.summarySourceTable === ref) {
        delete S.cache[t.tableId];
        delete S.byId[t.tableId];
      }
    if (rid) S.sel[secId] = rid;
    S.search[secId] = ""; // la nouvelle ligne (vide) ne serait pas trouvée par la recherche
    scheduleRender();
    setTimeout(() => status("Ligne ajoutée"), 400);
    // après l'affichage : on se place sur la nouvelle ligne et on ouvre la saisie du premier champ
    for (let i = 0; rid && i < 30; i++) {
      await new Promise((r) => setTimeout(r, 100));
      const c = document.querySelector(`#grid .block[data-sec="${secId}"] [data-rid="${rid}"][data-ed]`);
      if (c) {
        c.scrollIntoView({ block: "nearest" });
        startEdit(c);
        break;
      }
    }
  } catch (e) {
    actionFailed(e, "Ajout", "ajout de ligne");
    btn.disabled = false;
  }
}
// delRow — Supprime la ligne sélectionnée du bloc (RemoveRecord). Premier clic : demande de confirmation dans le
// bouton lui-même (pas de fenêtre) ; second clic dans les 4 s : suppression. Les règles d'accès de Grist s'appliquent.
async function delRow(secId, btn) {
  const b = S.cfg.blocks.find((x) => x.id === secId),
    info = getInfo(secId);
  if (!blockAddable(b, info)) return;
  const tr = document.querySelector(`#grid .block[data-sec="${secId}"] .sel[data-row]`);
  const rid = Number(tr?.dataset.row) || 0;
  if (!rid) return status("Sélectionner d'abord la ligne à supprimer (clic sur la ligne).");
  if (!btn.classList.contains("confirm")) {
    btn.classList.add("confirm");
    btn.textContent = "Confirmer la suppression ?";
    tr.classList.add("todel");
    setTimeout(() => {
      btn.classList.remove("confirm");
      btn.textContent = "− Supprimer la ligne";
      tr.classList.remove("todel");
    }, 4000);
    return;
  }
  btn.disabled = true;
  try {
    await docActions([["RemoveRecord", info.tableId, rid]]);
    const ref = info.sec.tableRef;
    for (const [id, t] of S.meta.tables)
      if (id === ref || t.summarySourceTable === ref) {
        delete S.cache[t.tableId];
        delete S.byId[t.tableId];
      }
    delete S.sel[secId];
    scheduleRender();
    setTimeout(() => status("Ligne supprimée"), 400);
  } catch (e) {
    actionFailed(e, "Suppression", "suppression de ligne");
    btn.disabled = false;
  }
}
$("#grid").addEventListener("click", (ev) => {
  const a = ev.target.closest("[data-addrow]");
  if (a) addRow(Number(a.dataset.addrow), a);
  const d = ev.target.closest("[data-delrow]");
  if (d) delRow(Number(d.dataset.delrow), d);
});
$("#grid").addEventListener("dblclick", (ev) => {
  const c = ev.target.closest("td[data-ed]");
  if (c) {
    ev.preventDefault();
    startEdit(c);
  }
});
$("#grid").addEventListener("keydown", (ev) => {
  // accessibilité : Entrée sur un champ éditable
  if (ev.key === "Enter" && ev.target.matches?.(".rlink")) {
    ev.preventDefault();
    openRecordCard(ev.target.dataset.rt, Number(ev.target.dataset.rr));
    return;
  }
  if (ev.key === "Enter" && ev.target.matches?.("[data-ed]")) {
    ev.preventDefault();
    startEdit(ev.target);
  }
});
$("#grid").addEventListener("click", (ev) => {
  const qt = ev.target.closest("[data-qftog]"); // filtre rapide compact : ouvrir / fermer la liste
  if (qt) {
    ev.stopPropagation();
    // second toucher juste après le choix d'une valeur dans la liste (refermée entre-temps) : double toucher
    if (qfLast && Date.now() - qfLast.t < 500 && qfLast.id === qt.dataset.qftog && qfLast.k === (Number(qt.dataset.qk) || 1)) {
      const l = qfLast;
      qfLast = null;
      return qfSync(Number(l.id), l.v, l.k);
    }
    qfToggle(qt);
    return;
  }
  const qb = ev.target.closest("[data-qf]"); // filtre rapide : bouton d'une valeur
  if (qb) {
    ev.stopPropagation();
    const k = Number(qb.dataset.qk) || 1;
    // Maj+clic, ou double clic / double toucher sur la même valeur (0.9.6.15, smartphone) : tous les blocs
    const dbl = qfLast && Date.now() - qfLast.t < 500 && qfLast.id === qb.dataset.qf && qfLast.k === k && qfLast.v === qb.dataset.qv;
    qfLast = dbl ? null : { id: qb.dataset.qf, k, v: qb.dataset.qv, t: Date.now() };
    if (ev.shiftKey || dbl) return qfSync(Number(qb.dataset.qf), qb.dataset.qv, k);
    S.qf[k === 3 ? `${qb.dataset.qf}:3` : k === 2 ? `${qb.dataset.qf}:2` : Number(qb.dataset.qf)] = qb.dataset.qv;
    scheduleRender();
    return;
  }
  const q3 = ev.target.closest("[data-qf3tog],[data-qf3all],[data-qf3ok]"); // filtre libre : liste à cocher
  if (q3) {
    ev.stopPropagation();
    if (q3.dataset.qf3tog) qf3Open(q3);
    else if (q3.dataset.qf3all) q3.closest(".qf3-panel").querySelectorAll("[data-qf3]").forEach((x) => (x.checked = false));
    else qf3Close();
    return;
  }
  if (ev.target.closest(".qf3-panel")) return; // case à cocher : appliquée à la fermeture
  const mb = ev.target.closest("[data-mprint],[data-mexport]"); // carte : imprimer seule, exporter
  if (mb) {
    ev.stopPropagation();
    if (mb.dataset.mprint) printMap(Number(mb.dataset.mprint));
    else exportMap(Number(mb.dataset.mexport));
    return;
  }
  const fb = ev.target.closest("[data-filt]");
  if (fb) {
    ev.stopPropagation();
    openFilter(fb, Number(fb.closest("[data-sec]").dataset.sec), fb.dataset.filt);
    return;
  }
  const sb = ev.target.closest("[data-sort]");
  if (sb) {
    // tri : croissant → décroissant → ordre de la vue Grist
    const id = Number(sb.closest("[data-sec]").dataset.sec),
      c = sb.dataset.sort,
      cur = S.usort[id];
    if (!cur || cur.colId !== c) S.usort[id] = { colId: c, desc: false };
    else if (!cur.desc) cur.desc = true;
    else delete S.usort[id];
    scheduleRender();
    return;
  }
  if (onRlink(ev)) return;
  // tableau : un clic sur une cellule éditable d'une ligne déjà sélectionnée ouvre la saisie
  // (le double-clic échoue quand la sélection redessine la page entre les deux clics)
  const tc = ev.target.closest("td[data-ed]");
  if (tc && !ev.target.closest(".ed-input")) {
    const tr = tc.closest("tr");
    if (tc.dataset.kind === "sel" || tr?.classList.contains("sel")) {
      selectRow(tr); // la ligne devient la ligne courante…
      startEdit(tc); // …et la cellule s'ouvre en saisie (liste déroulante pour Référence / Choix)
      return;
    }
  }
  const fe = ev.target.closest("dd[data-ed]");
  if (fe && !ev.target.closest(".ed-input")) {
    startEdit(fe);
    return;
  }
  const mx = ev.target.closest("[data-max]");
  if (mx) {
    setMaxed(S.maxed === Number(mx.dataset.max) ? null : Number(mx.dataset.max));
    return;
  }
  // un clic n'importe où sur l'en-tête d'un bloc le plie ou le déplie (0.9.6.8 ; avant : seulement replié),
  //   sauf sur ses commandes (filtres, recherche, liens) et en plein écran
  const ch = ev.target.closest(".block:not(.maxed) > .bh");
  const tog =
    ev.target.closest("[data-tog]") ||
    (ch && !ev.target.closest("button, input, select, label, a, .qf, .qfs, .search, .secinfo") ? ch.querySelector("[data-tog]") : null);
  if (tog) {
    const id = Number(tog.dataset.tog);
    S.collapsed[id] = !S.collapsed[id];
    tog.closest(".block").classList.toggle("collapsed", S.collapsed[id]);
    updateFoldButton();
    if (!S.collapsed[id]) {
      lockColumns(tog.closest(".block"));
      fitQf(tog.closest(".block")); // filtres masqués tant que le bloc était replié : présentation à recalculer
    }
    return;
  }
  const nav = ev.target.closest("[data-nav]");
  if (nav) {
    const id = Number(nav.dataset.sec),
      step = Number(nav.dataset.nav);
    rowsFor(id, { rows: new Map() }).then(async ({ rows }) => {
      const cur = await selectedRowId(id, { rows: new Map() });
      const i = rows.findIndex((r) => r.id === cur);
      const next = rows[(Math.max(0, i) + step + rows.length) % rows.length];
      if (next) {
        S.sel[id] = next.id;
        scheduleRender();
      }
    });
    return;
  }
  const rowEl = ev.target.closest("[data-row]");
  if (rowEl) selectRow(rowEl);
});
// clic milieu sur une valeur (ou sur la liste) d'un filtre rapide : synchroniser tous les blocs
$("#grid").addEventListener("mousedown", (ev) => {
  if (ev.button === 1 && ev.target.closest(".qf, [data-qfs]")) ev.preventDefault(); // pas de défilement auto
});
$("#grid").addEventListener("auxclick", (ev) => {
  if (ev.button !== 1) return;
  const qb = ev.target.closest("[data-qf]"),
    qs = ev.target.closest("[data-qfs]");
  if (!qb && !qs) return;
  ev.preventDefault();
  ev.stopPropagation();
  if (qb) qfSync(Number(qb.dataset.qf), qb.dataset.qv, Number(qb.dataset.qk) || 1);
  else qfSync(Number(qs.dataset.qfs), qs.value, Number(qs.dataset.qk) || 1);
});
$("#grid").addEventListener("change", (ev) => {
  const qs = ev.target.closest("[data-qfs]"); // filtre rapide au-delà de 4 valeurs
  if (qs) {
    const k = Number(qs.dataset.qk);
    S.qf[k === 3 ? `${qs.dataset.qfs}:3` : k === 2 ? `${qs.dataset.qfs}:2` : Number(qs.dataset.qfs)] = qs.value;
    scheduleRender();
  }
  const qc = ev.target.closest("[data-qfcol]"); // filtre libre : colonne choisie (valeur remise à « Tous »)
  if (qc) {
    (S.qfFreeCol ??= {})[qc.dataset.qfcol] = qc.value;
    delete S.qf[`${qc.dataset.qfcol}:3`];
    S.qf3Auto = qc.value ? qc.dataset.qfcol : null; // la liste des valeurs s'ouvrira après le rendu (0.9.7.0)
    scheduleRender();
  }
  const mz = ev.target.closest("[data-mzone]"); // carte : zonage choisi par l'utilisateur
  if (mz) {
    setUserZone(Number(mz.dataset.mzone), mz.value, Number(mz.dataset.mk) || 1);
    scheduleRender();
  }
});
$("#grid").addEventListener("input", (ev) => {
  const inp = ev.target.closest("[data-search]");
  if (inp) {
    const id = Number(inp.dataset.search);
    S.search[id] = inp.value;
    applySearch(id);
  }
});
const backdrop = document.createElement("div");
backdrop.id = "backdrop";
document.body.append(backdrop);
// setMaxed — Affiche un bloc en plein écran (ou revient à la page).
function setMaxed(id) {
  S.maxed = id || null;
  backdrop.classList.toggle("on", !!S.maxed);
  document.body.style.overflow = S.maxed ? "hidden" : "";
  scheduleRender();
}
backdrop.addEventListener("click", () => setMaxed(null));
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && S.maxed && $("#config").hidden) setMaxed(null);
});
window.addEventListener("scroll", () => $("#top").classList.toggle("stuck", window.scrollY > 4), {
  passive: true,
});
const tip = document.createElement("div");
tip.id = "tip";
document.body.append(tip);
$("#grid").addEventListener("mouseover", (ev) => {
  const d = ev.target.closest("[data-desc]"); // description de colonne (en-tête ou libellé de fiche)
  const h = d || ev.target.closest(".bh .bt"); // ou titre de bloc tronqué
  if (!h || (!d && h.scrollWidth <= h.clientWidth)) return;
  tip.textContent = d ? d.dataset.desc : h.textContent;
  tip.classList.add("on");
  const r = h.getBoundingClientRect();
  tip.style.top = `${r.bottom + 4}px`;
  tip.style.left = `${Math.max(4, Math.min(r.left, window.innerWidth - tip.offsetWidth - 4))}px`;
});
$("#grid").addEventListener("mouseout", (ev) => {
  if (ev.target.closest(".bh .bt, [data-desc]")) tip.classList.remove("on");
});
window.addEventListener(
  "scroll",
  (e) => {
    tip.classList.remove("on");
    if (!e.target.closest?.(".picker"))
      document.querySelector(".picker") && document.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
  },
  true,
);
$("#btnRefresh").addEventListener("click", () => refreshAll());
/* ---------- Impression / PDF ---------- */
function selectionSummary() {
  // « Département : Finistère · Circonscription : … »
  return [...document.querySelectorAll("#filters label")]
    .map((l) => {
      const sel = l.querySelector("select");
      return sel
        ? `${l.firstChild?.textContent?.trim() || ""} : ${sel.selectedOptions[0]?.textContent || ""}`
        : "";
    })
    .filter(Boolean)
    .join(" · ");
}
// printPage — Impression / PDF : tout déplier, attendre la fin de l'affichage, puis imprimer.
async function printPage() {
  const ph = $("#printhead"),
    sel = selectionSummary();
  ph.innerHTML = `${pageIcon("phicon")}<div><h1>${esc(S.cfg.title || S.cfg.name || "")}</h1>${sel ? `<p>${esc(sel)}</p>` : ""}<p>Édité le ${new Date().toLocaleDateString("fr-FR")}</p></div>`;
  // tout déplier, sortir du plein écran, et attendre la fin de l'affichage progressif des grands tableaux
  const saved = { ...S.collapsed },
    maxed = S.maxed;
  S.collapsed = Object.fromEntries(S.cfg.blocks.map((b) => [b.id, false]));
  S.maxed = null;
  $("#backdrop")?.classList.remove("on");
  document.body.style.overflow = "";
  document.querySelectorAll("#grid .block.collapsed").forEach((el) => el.classList.remove("collapsed"));
  document.querySelectorAll("#grid .block.maxed").forEach((el) => el.classList.remove("maxed"));
  // largeur d'une page A4 paysage : graphiques, cartes et tableaux se recalent avant l'impression
  document.documentElement.classList.add("printing");
  await new Promise((r) => setTimeout(r, 50));
  await new Promise((r) => setTimeout(r, 400));
  window.dispatchEvent(new Event("resize")); // graphiques et cartes à la bonne taille
  await new Promise((r) => setTimeout(r, 300));
  markPrintBig();
  const restore = () => {
    S.collapsed = saved;
    S.maxed = maxed;
    document.documentElement.classList.remove("printing");
    window.dispatchEvent(new Event("resize"));
    window.removeEventListener("afterprint", restore);
    scheduleRender();
  };
  window.addEventListener("afterprint", restore);
  window.print();
}
// markPrintBig — Repère les blocs plus hauts qu'une page : à l'impression ils partent à la ligne
// et se coupent d'une page à l'autre (contenu complet mesuré, sans la hauteur limitée de l'écran).
//   Bloc trop large (0.9.5.4) : un tableau plus large que la place du bloc sur le papier (A4 paysage, 277 mm utiles)
//   débordait sur les blocs voisins ; il prend alors toute la largeur de la page (printwide).
function markPrintBig() {
  const pageW = (277 * 96) / 25.4;
  document.querySelectorAll("#grid > .block").forEach((el) => {
    const inner = [...el.querySelectorAll(":scope > .bb, .tbl-wrap, .cartes")].map((x) => x.scrollHeight + 40);
    const h = Math.max(el.offsetHeight, ...inner);
    el.classList.toggle("printbig", h > 600);
    const span = Number(getComputedStyle(el).getPropertyValue("--span")) || 6;
    const room = (pageW * span) / 6 - 12;
    const wide =
      span < 6 && [...el.querySelectorAll(".tbl-wrap, .cartes")].some((x) => x.scrollWidth > x.clientWidth + 2 || x.scrollWidth > room);
    el.classList.toggle("printwide", wide);
  });
}
window.addEventListener("beforeprint", markPrintBig); // impression lancée par Ctrl+P
// chartColors — Couleurs des textes, grilles et fonds des graphiques : celles du thème, ou claires (impression en
//   mode sombre : la page imprimée est toujours claire, les graphiques déjà dessinés sont mis à jour)
function chartColors(light) {
  const v = light
    ? { t: "#3a3a3a", g: "#eee", c: "#fff" }
    : { t: cssVar("--texte2"), g: cssVar("--bord-doux"), c: cssVar("--carte") };
  if (window.Chart) {
    for (const ch of S.charts || []) {
      try {
        const o = ch.options;
        if (o.plugins?.legend?.labels) o.plugins.legend.labels.color = v.t;
        for (const sc of Object.values(o.scales || {})) {
          if (sc.ticks) sc.ticks.color = v.t;
          if (sc.grid) sc.grid.color = v.g;
          if (sc.border) sc.border.color = v.g;
        }
        ch.update("none");
      } catch {
        /* graphique déjà retiré */
      }
    }
  }
  if (window.Plotly)
    document.querySelectorAll(".plot-box").forEach((el) => {
      try {
        Plotly.relayout(el, { "font.color": v.t, paper_bgcolor: v.c, plot_bgcolor: v.c, "xaxis.gridcolor": v.g, "yaxis.gridcolor": v.g });
      } catch {
        /* graphique non dessiné */
      }
    });
}
let printLight = false;
window.addEventListener("beforeprint", () => {
  if (!isDark()) return;
  printLight = true;
  chartColors(true);
});
window.addEventListener("afterprint", () => {
  if (!printLight) return;
  printLight = false;
  chartColors(false);
});
$("#btnPrint").addEventListener("click", () => printPage());
// Plein écran : la page Grist qui contient ce widget, en mode page unique (sans les menus de Grist), nouvel onglet
$("#btnSingle").addEventListener("click", async () => {
  menuToggle(false);
  const base = safeBase(S.nav?.url) || safeBase(await guessDocUrl());
  const vid = hostView(S.cfg.name);
  if (!base || !vid) return status("Plein écran : page Grist du widget introuvable (adresse du document à renseigner dans la configuration).", true);
  window.open(pageUrl(base, vid, true), "_blank", "noopener");
});

/* ---------- Aide intégrée ----------
   Les fichiers Markdown du dépôt (à côté du widget sur GitHub Pages) sont lus à l'ouverture et affichés
   dans une fenêtre à onglets : déposer une nouvelle version sur GitHub met l'aide à jour.
   Mise en forme : marked ; HTML nettoyé par DOMPurify. Une pastille signale une nouvelle version. */
const HELP_DOCS = [
  { id: "guide", label: "Guide", file: "GUIDE-UTILISATEUR.md" },
  { id: "admin", label: "Administration", file: "GUIDE-ADMINISTRATEUR.md", admin: true }, // composer les pages
  { id: "news", label: "Nouveautés", file: "CHANGELOG.md" },
  { id: "about", label: "À propos", file: "README.md", admin: true }, // documentation technique : administrateurs
];
const SEEN_KEY = "uxwg_seen_version"; // dernière version dont l'utilisateur a vu les nouveautés (navigateur)
const helpCache = {};
let helpTab = "guide";
// seenVersion / markSeen — Version déjà vue (stockage local du navigateur, facultatif).
const seenVersion = () => {
  try {
    return localStorage.getItem(SEEN_KEY) || "";
  } catch {
    return VERSION; // stockage indisponible : pas de pastille
  }
};
const markSeen = () => {
  try {
    localStorage.setItem(SEEN_KEY, VERSION);
  } catch {
    /* facultatif */
  }
  updateHelpDot();
};
// updateHelpDot — Pastille « nouveau » sur le bouton Aide si la version a changé depuis la dernière visite.
function updateHelpDot() {
  const dot = $("#btnHelp .newdot"),
    isNew = seenVersion() !== VERSION;
  dot.hidden = !isNew;
  $("#btnMenu .newdot").hidden = !isNew; // visible aussi quand le menu est fermé
  $("#btnHelp").dataset.tip = isNew
    ? `Aide — nouvelle version ${VERSION} : voir les nouveautés`
    : `Aide : guide d'utilisation et nouveautés — UX widget grist ${VERSION}`;
  // infobulle du menu ☰ : version du widget (et rappel d'une nouvelle version)
  $("#btnMenu").dataset.tip = `Menu : actions de la page — UX widget grist ${VERSION}${isNew ? " (nouvelle version)" : ""}`;
}
// slug — Identifiant d'ancre d'un titre, comme GitHub (« 2. Composer une page » → « 2-composer-une-page »).
const slug = (t) =>
  t
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s_-]/gu, "")
    .replace(/\s/g, "-");
// helpLoad — Lit et met en forme un fichier Markdown (mis en cache pour la session).
function helpLoad(doc) {
  return (helpCache[doc.id] ??= Promise.all([
    window.marked ? null : loadLib(LIBS.marked, "marked"),
    window.DOMPurify ? null : loadLib(LIBS.purify, "DOMPurify"),
  ])
    .then(() => fetch(new URL(doc.file, location.href), { cache: "no-cache" }))
    .then((r) => {
      if (!r.ok) throw new Error(`${doc.file} introuvable (HTTP ${r.status})`);
      return r.text();
    })
    .then((md) => DOMPurify.sanitize(marked.parse(md)))
    .catch((e) => {
      delete helpCache[doc.id];
      throw e;
    }));
}
// newsForUsers — Nouveautés vues par un utilisateur : seules les rubriques « Utilisateurs » de chaque version
// (les rubriques « Administrateurs » et « Développeurs » sont retirées, puis les versions restées vides).
function newsForUsers(body) {
  const until = (el, stop) => {
    const out = [];
    for (let n = el.nextElementSibling; n && !stop(n); n = n.nextElementSibling) out.push(n);
    return out;
  };
  for (const h3 of [...body.querySelectorAll("h3")])
    if (/^(administrateurs|d[ée]veloppeurs)$/i.test(h3.textContent.trim())) {
      until(h3, (n) => /^H[123]$/.test(n.tagName) || n.tagName === "HR").forEach((n) => n.remove());
      h3.remove();
    }
  for (const h2 of [...body.querySelectorAll("h2")]) {
    if (!/^\[/.test(h2.textContent.trim())) continue; // en-têtes de version « [0.9.2.2] — … »
    const part = until(h2, (n) => n.tagName === "H2" || n.tagName === "HR");
    if (!part.some((n) => n.tagName === "H3")) {
      part.forEach((n) => n.remove());
      h2.remove();
    }
  }
  // l'en-tête du journal : la mention des trois rubriques ne concerne pas l'utilisateur
  body.querySelectorAll("p").forEach((p) => {
    if (/^Qui est concerné/.test(p.textContent.trim())) {
      if (p.nextElementSibling?.tagName === "UL") p.nextElementSibling.remove();
      p.remove();
    } else if (/^Dans l'onglet Nouveautés/.test(p.textContent.trim())) p.remove();
  });
}
/* ---------- Message d'accueil (0.9.3) ----------
   Texte Markdown réglé par l'administrateur (S.nav.welcome, ligne _Navigation de W_Composition), affiché au
   démarrage. À sa fermeture, le navigateur mémorise l'empreinte du texte : seul un texte modifié s'affiche de
   nouveau (0.9.4.10). Identifiant du document parfois inconnu (jeton d'accès lent) : l'empreinte est aussi gardée
   sous une clé de secours, pour que le message ne revienne pas à tort. */
const welcomeKey = () => `uxwg_welcome_${S.docKey || "doc"}`;
const welcomeKeys = () => [...new Set([welcomeKey(), "uxwg_welcome_doc"])];
const textHash = (t) => {
  let h = 0;
  for (let i = 0; i < t.length; i++) h = (Math.imul(31, h) + t.charCodeAt(i)) | 0;
  return String(h >>> 0);
};
// showWelcome — Affiche le message (force : aperçu depuis la configuration, même s'il a été masqué).
// mdFolds — Parties repliables du message d'accueil : une ligne « +++ Titre » ouvre une partie repliée (« +++! Titre » :
//   dépliée au départ), une ligne « +++ » seule la ferme ; parties imbriquables, fermeture implicite en fin de texte.
//   Converti en <details><summary> avant Markdown ; le contenu reste du Markdown (lignes vides autour).
function mdFolds(text) {
  let open = 0;
  const out = String(text)
    .split("\n")
    .map((line) => {
      const m = /^\s*\+\+\+(!?)\s*(.*?)\s*$/.exec(line);
      if (!m) return line;
      if (!m[2]) {
        if (!open) return line;
        open--;
        return "\n</details>\n";
      }
      open++;
      return `\n<details${m[1] ? " open" : ""}><summary>${marked.parseInline(m[2])}</summary>\n`;
    });
  while (open-- > 0) out.push("\n</details>\n");
  return out.join("\n");
}
async function showWelcome(force = false, text = S.nav?.welcome || "") {
  text = String(text || "").trim();
  if (!text) return force && status("Message d'accueil vide");
  const hash = textHash(text);
  let seen = null;
  try {
    seen = welcomeKeys().map((k) => localStorage.getItem(k)).find((v) => v === hash) || localStorage.getItem(welcomeKey());
  } catch {
    /* stockage indisponible : le message s'affiche à chaque fois */
  }
  if (!force && seen === hash) return;
  try {
    await Promise.all([
      window.marked ? null : loadLib(LIBS.marked, "marked"),
      window.DOMPurify ? null : loadLib(LIBS.purify, "DOMPurify"),
    ]);
  } catch {
    return; // bibliothèques indisponibles : pas de message plutôt qu'un texte brut
  }
  const box = $("#welcome");
  if (!box) return; // index.html antérieur à 0.9.3
  box.querySelector(".wbody").innerHTML = DOMPurify.sanitize(marked.parse(mdFolds(text)), { ADD_ATTR: ["open"] });
  box.querySelectorAll(".wbody a[href]").forEach((a) => Object.assign(a, { target: "_blank", rel: "noopener" }));
  box.dataset.hash = hash;
  box.hidden = false;
  $("#wClose").focus();
}
function closeWelcome() {
  const box = $("#welcome");
  if (!box || box.hidden) return;
  // vu une fois : il ne revient que si son texte change (0.9.4.10) — ni à la visite suivante, ni après une mise à
  // jour du widget ou un enregistrement de la configuration ; Aide → « Message d'accueil » le réaffiche
  try {
    for (const k of welcomeKeys()) localStorage.setItem(k, box.dataset.hash);
  } catch {
    /* stockage indisponible */
  }
  box.hidden = true;
}
$("#wClose")?.addEventListener("click", closeWelcome); // (absent d'un index.html antérieur à 0.9.3)
$("#welcome")?.addEventListener("click", (ev) => {
  if (ev.target.id === "welcome") closeWelcome(); // clic sur le fond
});
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && $("#welcome") && !$("#welcome").hidden) closeWelcome();
});
// openHelp — Ouvre la fenêtre d'aide sur un onglet (et une ancre éventuelle).
async function openHelp(tab = helpTab, anchor = "") {
  const docs = HELP_DOCS.filter((d) => !d.admin || S.isAdmin);
  const doc = docs.find((d) => d.id === tab) || docs[0];
  helpTab = doc.id;
  $("#help").hidden = false;
  $("#helpTitle").textContent = `Aide — UX widget grist ${VERSION} · Ligures`;
  $("#help .htabs").innerHTML =
    docs
      .map((d) => `<button role="tab" data-htab="${d.id}" class="${d.id === doc.id ? "on" : ""}" aria-selected="${d.id === doc.id}">${esc(d.label)}</button>`)
      .join("") +
    // message d'accueil : le revoir à tout moment
    (String(S.nav?.welcome || "").trim() && $("#welcome")
      ? `<button data-hwelcome="1" title="Afficher de nouveau le message d'accueil">Message d'accueil</button>`
      : "");
  const body = $("#help .hbody");
  body.innerHTML = '<p class="msg">Chargement…</p>';
  try {
    body.innerHTML = await helpLoad(doc);
    if (doc.id === "news" && !S.isAdmin) newsForUsers(body);
    body.querySelectorAll("h1, h2, h3, h4").forEach((h) => (h.id = slug(h.textContent)));
    body.querySelectorAll("a[href]").forEach((a) => {
      if (/^https?:/i.test(a.getAttribute("href"))) Object.assign(a, { target: "_blank", rel: "noopener" });
    });
    if (doc.id === "news") markSeen();
    const target = anchor && body.querySelector(`#${CSS.escape(anchor)}`);
    if (target) target.scrollIntoView();
    else body.scrollTop = 0;
  } catch (e) {
    body.innerHTML = `<p class="msg err">Aide indisponible : ${esc(e.message || e)}.</p>
      <p class="msg">Les fichiers ${HELP_DOCS.map((d) => `<code>${d.file}</code>`).join(", ")} doivent être déposés à côté du widget.</p>`;
  }
}
const closeHelp = () => ($("#help").hidden = true);
$("#btnHelp").addEventListener("click", () => openHelp("guide")); // le guide d'abord ; la pastille signale les nouveautés
$("#helpClose").addEventListener("click", closeHelp);
$("#help").addEventListener("click", (ev) => {
  if (ev.target.id === "help") return closeHelp(); // clic sur le fond
  if (ev.target.closest("[data-hwelcome]")) {
    closeHelp();
    return showWelcome(true);
  }
  const t = ev.target.closest("[data-htab]");
  if (t) return openHelp(t.dataset.htab);
  const a = ev.target.closest("a[href]");
  if (!a) return;
  const href = a.getAttribute("href");
  if (href.startsWith("#")) {
    // ancre dans le document affiché
    ev.preventDefault();
    $("#help .hbody").querySelector(`#${CSS.escape(decodeURIComponent(href.slice(1)))}`)?.scrollIntoView();
    return;
  }
  const m = /^(?:\.\/)?([\w.-]+\.md)(?:#(.*))?$/i.exec(href); // lien vers un autre fichier de l'aide
  const doc = m && HELP_DOCS.find((d) => d.file.toLowerCase() === m[1].toLowerCase());
  if (doc) {
    ev.preventDefault();
    openHelp(doc.id, m[2] ? decodeURIComponent(m[2]) : "");
  }
});
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && !$("#help").hidden) closeHelp();
});
updateHelpDot();

// updateFoldButton — Libellé du bouton « Tout replier / Tout déplier » selon l'état des blocs.
function updateFoldButton() {
  const any = S.cfg.blocks.some((b) => !b.sep && S.collapsed[b.id]);
  const t = any ? "Tout déplier" : "Tout replier";
  $("#btnFold .lbl").textContent = t;
  $("#btnFold").dataset.tip = t;
  $("#btnFold").setAttribute("aria-label", t);
  $("#btnFold svg").innerHTML = any
    ? '<path d="M7 9l5-5 5 5M7 15l5 5 5-5"/>'
    : '<path d="M7 4l5 5 5-5M7 20l5-5 5 5"/>';
}
$("#btnFold").addEventListener("click", () => {
  const any = S.cfg.blocks.some((b) => !b.sep && S.collapsed[b.id]);
  for (const b of S.cfg.blocks) if (!b.sep) S.collapsed[b.id] = !any;
  document.querySelectorAll("#grid .block").forEach((el) => {
    el.classList.toggle("collapsed", !any);
  });
  if (any) {
    lockColumns($("#grid"));
    fitQf($("#grid"));
  }
  updateFoldButton();
});
$("#btnConfig").addEventListener("click", () => openConfig());

/* Colonnes choisies dans la configuration : elles sont enregistrées par identifiant (colId), qui change quand
   on renomme une colonne dans Grist. On garde aussi leur numéro interne (colRef, stable) dans b._refs pour
   retrouver le nouvel identifiant automatiquement. */
const COL_FIELDS = ["mapLabel", "mapColor", "mapColor2", "mapRing", "mapCommune", "selCol", "selGroup", "zoneSum", "qfField", "qfField2", "legisCol", "collegeCol", "irisCol"];
const COL_SPECIAL = new Set(["", "__qpv", "__pos", "__pts"]); // valeurs qui ne sont pas des colonnes
// colFieldTable — Table d'une option de colonne (zoneKey / zoneVal : table choisie pour colorer les zones).
function colFieldTable(b, f) {
  if (f === "zoneKey" || f === "zoneVal") return [...S.meta.tables.values()].find((t) => t.tableId === b.zoneTable)?.id;
  const g = /^grp(\d?)(Key|Col)$/.exec(f); // colonnes d'un regroupement : dans sa table des communes
  if (g) return [...S.meta.tables.values()].find((t) => t.tableId === b[`grp${g[1]}Table`])?.id;
  return S.meta.sections.get(b.id)?.tableRef;
}
// rememberColRefs — À l'enregistrement : mémorise le colRef de chaque colonne choisie.
function rememberColRefs(cfg) {
  for (const b of cfg.blocks || []) {
    const refs = {};
    for (const f of [...COL_FIELDS, "zoneKey", "zoneVal", "grpKey", "grpCol", "grp2Key", "grp2Col", "grp3Key", "grp3Col"]) {
      if (COL_SPECIAL.has(b[f] ?? "")) continue;
      const c = (S.meta.colsByTable.get(colFieldTable(b, f)) || []).find((x) => x.colId === b[f]);
      if (c) refs[f] = c.id;
    }
    b._refs = refs;
  }
}
// fixColIds — Au chargement : remplace l'identifiant d'une colonne renommée par son nouvel identifiant.
function fixColIds(cfg) {
  let changed = false;
  for (const b of cfg?.blocks || []) {
    for (const [f, ref] of Object.entries(b._refs || {})) {
      const cols = S.meta.colsByTable.get(colFieldTable(b, f)) || [];
      if (cols.some((x) => x.colId === b[f])) continue; // toujours valide
      const c = S.meta.cols.get(ref);
      if (c && cols.includes(c)) {
        b[f] = c.colId;
        changed = true;
      }
    }
  }
  return changed;
}
// refreshAll — Bouton Actualiser : vide les caches et relit métadonnées, configuration et données.
async function refreshAll(silent = false) {
  // écran de maintenance ou d'accès fermé (0.9.6) : tout le démarrage est refait (la situation a pu changer)
  if (S.gated) {
    S.gated = null;
    document.documentElement.classList.remove("gated");
    S.cache = {};
    S.byId = {};
    return init();
  }
  S.cache = {};
  S.byId = {};
  S.navAccess = {}; // conditions « si accès à » du menu : relues (0.9.5.3)
  try {
    if (!silent) status("Rechargement…");
    await loadMeta();
    fixColIds(S.cfg); // colonnes renommées dans Grist
    await render();
  } catch (e) {
    status(e.message || String(e), true);
  }
}
// docActions — Modifie le document (applyUserActions).
async function docActions(actions) {
  const r = await grist.docApi.applyUserActions(actions);
  S.navAccess = {}; // une ligne créée ou supprimée peut faire apparaître ou disparaître une page du menu (0.9.5.3)
  return r;
}
/* ---------- Maintenance et accès fermé (0.9.6) ----------
   Table W_Messages (une ligne), laissée lisible par tous par une règle d'accès placée avant les autres :
   Maintenance (booléen), Message_maintenance, Fin_prevue (date et heure), Message_sans_acces (Markdown).
   - Maintenance cochée : les utilisateurs voient l'écran de maintenance ; les administrateurs voient le site, avec
     un bandeau « Maintenance active ».
   - Sans maintenance, un utilisateur qui ne peut lire aucune page configurée (tables techniques mises à part) voit
     l'écran « accès non ouvert ».
   Sans W_Messages : un texte par défaut, seulement quand rien n'est lisible du tout. */
const MSG_TABLE = "W_Messages";
// readMessages — Ligne de W_Messages, ou null si la table est absente ou illisible.
async function readMessages() {
  try {
    if (S.meta?.visibleTables && !S.meta.visibleTables.has(MSG_TABLE)) return null;
    const r = toRows(await grist.docApi.fetchTable(MSG_TABLE))[0];
    if (!r) return null;
    const txt = (v) => (typeof v === "string" ? v.trim() : "");
    return {
      maint: !!r.Maintenance,
      msgMaint: txt(r.Message_maintenance),
      fin: typeof r.Fin_prevue === "number" && r.Fin_prevue > 0 ? r.Fin_prevue : null,
      msgNo: txt(r.Message_sans_acces),
    };
  } catch {
    return null;
  }
}
// noReadablePage — Vrai si l'utilisateur ne peut lire aucune page configurée (ni rien du tout, sans W_Messages).
function noReadablePage(gate) {
  const pages = (S.stored || []).filter((x) => !x.name.startsWith("_") && x.cfg?.blocks?.length);
  if (pages.length) return !pages.some((x) => cfgReadable(x.name));
  // aucune configuration lisible : W_Composition est fermée à cet utilisateur (ou le document n'est pas configuré)
  const vis = [...(S.meta?.visibleTables || [])].filter((t) => t !== MSG_TABLE);
  return !!gate || !vis.length;
}
// finText — « Retour prévu : lundi 10 novembre 2026 à 14:00 ».
const finText = (sec) =>
  sec
    ? `Retour prévu : ${new Date(sec * 1000).toLocaleString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(" ", " ")}`
    : "";
// showGate — Écran de maintenance ou d'accès fermé, à la place des pages.
async function showGate(kind, g) {
  splashHide();
  S.ready = true;
  S.gated = kind;
  document.documentElement.classList.add("gated");
  const maint = kind === "maint";
  const text =
    (maint ? g?.msgMaint : g?.msgNo) ||
    (maint
      ? "Le document est en cours de maintenance. Réessayez dans quelques minutes."
      : "Votre compte n'a pas encore accès aux pages de ce document. Adressez-vous à un administrateur.");
  let html = esc(text).replace(/\n/g, "<br>");
  try {
    await Promise.all([
      window.marked ? null : loadLib(LIBS.marked, "marked"),
      window.DOMPurify ? null : loadLib(LIBS.purify, "DOMPurify"),
    ]);
    html = DOMPurify.sanitize(marked.parse(text));
  } catch {
    /* Markdown indisponible : texte brut */
  }
  let img = "";
  try {
    const sp = JSON.parse(localStorage.getItem(splashKey()) || "null"); // image de l'écran de chargement, si gardée
    if (sp?.img && /^data:image\/(gif|png|jpeg|webp);base64,/i.test(sp.img)) img = `<img class="spl-img" alt="" src="${esc(sp.img)}">`;
  } catch {
    /* rien */
  }
  $("#pnav").replaceChildren();
  $("#filters").replaceChildren();
  $("#grid").innerHTML = `<div class="gate"><div class="gate-card">${img}<div class="gate-ico" aria-hidden="true">${maint ? "🛠" : "🔒"}</div><h1>${maint ? "Maintenance en cours" : "Accès non ouvert"}</h1><div class="gate-msg mdview">${html}</div>${maint && g?.fin ? `<p class="gate-fin">${esc(finText(g.fin))}</p>` : ""}</div></div>`;
  $("#grid").querySelectorAll(".gate-msg a[href]").forEach((a) => Object.assign(a, { target: "_blank", rel: "noopener" }));
  status("");
}
// setMaintBanner — Bandeau des administrateurs pendant une maintenance (g : ligne de W_Messages, ou null).
function setMaintBanner(g) {
  const el = $("#maintBanner");
  if (!el) return;
  el.hidden = !g;
  el.textContent = g ? `🛠 Maintenance active : les utilisateurs voient le message de maintenance${g.fin ? ` (${finText(g.fin).toLowerCase()})` : ""}. Décochez « Maintenance » dans ${MSG_TABLE} pour rouvrir.` : "";
}
/* Droit de configurer : contrôlé par une table témoin W_Admin, protégée par une règle d'accès.
   - seuls ceux qui en lisent au moins une ligne peuvent configurer ;
   - exception : document encore sans configuration (installation). W_Admin est alors créée au premier
     enregistrement, avec une ligne : il reste à la protéger par une règle d'accès. */
const ADMIN_TABLE = "W_Admin";
// checkAdmin — L'utilisateur peut-il configurer ? (lit au moins une ligne de W_Admin, ou installation).
async function checkAdmin() {
  /* Fermé par défaut (0.8.10). Configurer est permis :
     - à qui lit au moins une ligne de W_Admin (table protégée par une règle d'accès) ;
     - sinon, seulement tant que le document n'a encore aucune configuration (installation).
     Avant, une table W_Admin invisible était prise pour une table absente, sauf si un témoin « _Securite »
     avait été posé dans W_Composition et restait lisible : sans ce témoin, un éditeur qui ne voyait pas W_Admin
     pouvait tout de même configurer. */
  try {
    const t = await grist.docApi.fetchTable(ADMIN_TABLE); // échoue si la table est absente ou interdite
    if ((t.id || []).length > 0) return true;
  } catch {
    /* absente ou non lisible : voir ci-dessous */
  }
  try {
    const tables = await grist.docApi.listTables();
    if (tables.includes(ADMIN_TABLE)) return false; // table visible mais vide pour cet utilisateur
    // tables cachées par les règles d'accès (Grist vide leur tableId) et W_Composition invisible : le document est
    // configuré mais fermé à cet utilisateur (maintenance, accès non ouvert) — jamais un mode installation (0.9.6)
    const hidden = [...(S.meta?.tables?.values() || [])].some((t) => !t.tableId);
    if (hidden && !tables.includes(CFG_TABLE)) return false;
    // installation : aucune configuration enregistrée (en dehors des lignes techniques « _… »)
    const stored = tables.includes(CFG_TABLE) ? toRows(await grist.docApi.fetchTable(CFG_TABLE)) : [];
    const configured = stored.some((r) => !String(r.Nom || "").startsWith("_"));
    if (!configured) S.adminHint = true; // rappel : créer et protéger W_Admin
    return !configured;
  } catch {
    return false;
  }
}

/* ---------- Navigation, enregistrement de la configuration et démarrage ---------- */
/* Sauvegarde durable de la configuration dans une table */
const CFG_TABLE = "W_Composition";
const NAV_NAME = "_Navigation";
/* ---------- Apparence : DSFR (services de l'État) ou neutre ----------
   Choix commun au document, rangé avec le menu commun (ligne _Navigation de W_Composition, nav.theme).
   Non choisi : apparence DSFR. Le choix se fait dans la configuration (section Affichage), par un administrateur. */
const NEUTRAL_BLUE = "#8c1c2c"; // rouge bordeaux (0.9.3.5) : distinct du bleu DSFR au premier coup d'œil
// Mode sombre (0.9.3.14) : suit le système (prefers-color-scheme) ; « clair » ou « sombre » l'imposent (nav.mode).
const darkMQ = window.matchMedia ? matchMedia("(prefers-color-scheme: dark)") : null;
const isDark = () => {
  const c = document.documentElement.classList;
  return c.contains("sombre") || (!c.contains("clair") && !!darkMQ?.matches);
};
// cssVar — Valeur d'une variable CSS de la page (couleurs du thème courant, pour les graphiques).
const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
function applyTheme(theme, mode = S.nav?.mode) {
  const neutre = theme === "neutre";
  const h = document.documentElement.classList;
  h.toggle("neutre", neutre);
  h.toggle("clair", mode === "clair");
  h.toggle("sombre", mode === "sombre");
  BRAND.c = neutre ? NEUTRAL_BLUE : "#000091";
  MAP_COLORS[0] = BRAND.c; // les cartes gardent un fond clair
  PALETTE[0] = isDark() ? (neutre ? "#e58e9a" : "#8585f6") : BRAND.c; // graphiques : couleur lisible sur fond sombre
}
// changement du réglage du système pendant l'utilisation : couleurs des graphiques recalculées
darkMQ?.addEventListener?.("change", () => {
  applyTheme(S.nav?.theme);
  if (S.cfg && !document.documentElement.classList.contains("clair") && !document.documentElement.classList.contains("sombre")) render();
});
// readNav — Lit le menu de navigation commun (ligne _Navigation de W_Composition).
async function readNav() {
  try {
    const tables = await grist.docApi.listTables();
    if (!tables.includes(CFG_TABLE)) return { url: "", items: [] };
    const row = toRows(await grist.docApi.fetchTable(CFG_TABLE)).find((r) => String(r.Nom || "") === NAV_NAME);
    const n = parseJSON(row?.Config, {})?.nav || {};
    return {
      url: n.url || "",
      singlePage: !!n.singlePage,
      inWidget: !!n.inWidget,
      items: Array.isArray(n.items) ? n.items : [],
      theme: n.theme === "neutre" || n.theme === "dsfr" ? n.theme : "", // "" : pas encore choisi
      mode: n.mode === "clair" || n.mode === "sombre" ? n.mode : "", // "" : comme le système
      home: n.home || "", // configuration ouverte à l'arrivée (mode « changer de page dans le widget »)
      welcome: typeof n.welcome === "string" ? n.welcome : "", // message d'accueil (Markdown)
      // écran de chargement : image (data:image/…, 300 Ko au plus), titre, texte
      ...(n.splash && typeof n.splash === "object"
        ? {
            splash: {
              img: typeof n.splash.img === "string" && n.splash.img.length < SPLASH_MAX * 1.4 ? n.splash.img : "",
              title: typeof n.splash.title === "string" ? n.splash.title : "",
              text: typeof n.splash.text === "string" ? n.splash.text : "",
            },
          }
        : {}),
    };
  } catch {
    return { url: "", items: [] };
  }
}
// guessDocUrl — Adresse du document déduite du jeton d'accès (proposée par défaut pour le menu).
async function guessDocUrl() {
  // adresse proposée par défaut : hôte + identifiant du document
  try {
    const t = await Promise.race([
      grist.docApi.getAccessToken({ readOnly: true }),
      new Promise((_, rej) => setTimeout(() => rej(), 3000)),
    ]);
    const m = /^(https?:\/\/[^/]+)\/api\/docs\/([^/?#]+)/.exec(t?.baseUrl || "");
    return m ? `${m[1]}/doc/${m[2]}` : "";
  } catch {
    return "";
  }
}
// safeBase — Adresse de base acceptée seulement en https (sécurité des liens du menu).
const safeBase = (u) => (/^https:\/\/[^\s"'<>\\]+$/i.test(String(u || "").trim()) ? String(u).trim() : ""); // https uniquement (pas de javascript:, data:…)
// pageUrl — Lien vers une page Grist du document.
const pageUrl = (base, viewId, single) =>
  `${String(base)
    .trim()
    .replace(/\/p\/\d+.*$/, "")
    .replace(/[?#].*$/, "")
    .replace(/\/+$/, "")}/p/${viewId}${single ? "?style=singlePage" : ""}`;
/* Sections nécessaires à une configuration : ses blocs + toute leur chaîne de liaisons */
function sectionsOf(cfg) {
  const ids = new Set();
  for (const b of cfg.blocks || []) {
    let s = S.meta.sections.get(b.id),
      g = 0;
    while (s && g++ < 12 && !ids.has(s.id)) {
      ids.add(s.id);
      s = s.linkSrcSectionRef ? S.meta.sections.get(s.linkSrcSectionRef) : null;
    }
  }
  return [...ids];
}
/* Charge en parallèle (au lieu d'une table après l'autre) toutes les tables utiles */
function prefetch(cfg, onStep) {
  const ids = sectionsOf(cfg);
  let k = 0;
  return Promise.all(
    ids.map((id) => {
      const info = getInfo(id);
      return Promise.resolve(info?.tableId ? prepareSection(info).catch(() => null) : null).then(() =>
        onStep?.(++k, ids.length),
      );
    }),
  );
}
// prefetchOthers — En tâche de fond : précharge les tables des autres pages du menu.
function prefetchOthers() {
  // en tâche de fond : les autres pages du menu, pour un changement instantané
  if (!S.nav?.inWidget) return;
  const others = (S.nav.items || [])
    .map((x) => (S.stored || []).find((c) => c.name === x.cfg))
    .filter((c) => c && c.name !== S.cfg.name);
  setTimeout(() => others.reduce((p, c) => p.then(() => prefetch(c.cfg)), Promise.resolve()), 800);
}
// switchConfig — Change de configuration dans le widget (menu « changer de page dans le widget »).
// pageKey — Page affichée dans cet onglet (0.9.5.8) : retrouvée si le widget redémarre (Grist recharge le widget
//   quand une modification change les droits, par exemple dans la table des attributs d'utilisateur).
const pageKey = () => `uxwg_page_${S.docKey || "doc"}`;
function switchConfig(name) {
  S.collapsed = {};
  const x = (S.stored || []).find((c) => c.name === name);
  if (!x || x.name === S.cfg.name) return;
  S.cfg = { ...DEFAULTS, ...x.cfg, name: x.name };
  try {
    sessionStorage.setItem(pageKey(), x.name);
  } catch {
    /* stockage indisponible */
  }
  S.maxed = null;
  $("#backdrop")?.classList.remove("on");
  document.body.style.overflow = "";
  window.scrollTo(0, 0);
  scheduleRender();
}
$("#pnav").addEventListener("click", (ev) => {
  if (ev.target.closest(".pnav-tog")) return pnavToggle();
  if (ev.target.closest("a")) pnavToggle(false); // page choisie : la liste se referme
  const a = ev.target.closest("[data-gocfg]");
  if (!a || ev.ctrlKey || ev.metaKey || ev.shiftKey || ev.button === 1) return; // clic normal : changement dans le widget
  ev.preventDefault();
  switchConfig(a.dataset.gocfg);
});
// cfgReadable — Une configuration est-elle lisible ? (au moins une table de ses blocs accessible à l'utilisateur)
function cfgReadable(name) {
  const c = (S.stored || []).find((x) => x.name === name)?.cfg,
    m = S.meta;
  if (!c || !m || !c.blocks?.length) return true;
  return c.blocks.some((b) => {
    const id = m.tables.get(m.sections.get(b.id)?.tableRef)?.tableId;
    return !!id && (!m.visibleTables || m.visibleTables.has(id));
  });
}
/* Une page du menu n'est proposée que si l'utilisateur peut lire au moins une table de ses vues (comme Grist) */
function viewReadable(vid) {
  const m = S.meta;
  if (!m) return true;
  const secs = m.sectionsByView.get(vid) || [];
  if (!secs.length) return true;
  return secs.some((s) => {
    const t = m.tables.get(s.tableRef),
      id = t?.tableId;
    return !!id && (!m.visibleTables || m.visibleTables.has(id));
  });
}
S.navAccess = {};
// renderNav — Affiche le menu des pages (masque celles que l'utilisateur ne peut pas lire).
// safeSvg — Icône SVG collée par l'administrateur (menu), nettoyée : seules les formes simples et leurs attributs
//   de dessin sont gardées (ni script, ni lien, ni style, ni image externe) ; les couleurs deviennent currentColor
//   pour suivre celle du lien (bleu sur la page courante). Résultat mis en cache.
const SVG_TAGS = new Set(["svg", "g", "path", "circle", "ellipse", "rect", "line", "polyline", "polygon"]);
const SVG_ATTRS = new Set(["viewbox", "d", "cx", "cy", "r", "rx", "ry", "x", "y", "x1", "y1", "x2", "y2", "width", "height", "points", "transform", "fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "fill-rule", "clip-rule", "opacity", "fill-opacity", "stroke-opacity"]);
const svgCache = new Map();
function safeSvg(src) {
  src = String(src || "").trim();
  // les fichiers téléchargés commencent souvent par <?xml …?>, un commentaire ou un DOCTYPE : on part de <svg
  const at = src.search(/<svg[\s>]/i);
  if (at < 0) return "";
  src = src.slice(at);
  if (svgCache.has(src)) return svgCache.get(src);
  let out = "";
  try {
    const doc = new DOMParser().parseFromString(src, "image/svg+xml");
    const root = doc.documentElement;
    if (root.nodeName.toLowerCase() === "svg" && !doc.querySelector("parsererror")) {
      // icônes « à classes » (Streamline Ultimate…) : <style>.a{fill:none;stroke:#000}</style> + class="a" →
      //   les déclarations des classes simples sont recopiées dans le style de chaque élément, avant nettoyage
      const css = [...doc.getElementsByTagName("style")].map((x) => x.textContent).join("\n");
      for (const [, sel, body] of css.matchAll(/([^{}]+)\{([^}]*)\}/g))
        for (const one of sel.split(",")) {
          const cls = /^\s*\.([\w-]+)\s*$/.exec(one)?.[1];
          if (cls) for (const el of root.querySelectorAll("*")) if (el.classList?.contains(cls)) el.setAttribute("style", `${body};${el.getAttribute("style") || ""}`);
        }
      const clean = (el) => {
        for (const c of [...el.children]) {
          // conteneurs sans dessin propre (<switch> des icônes Streamline Carbon, <a>) : remplacés par leur contenu
          if (c.nodeName === "switch" || c.nodeName === "a") {
            c.replaceWith(...c.childNodes);
            return clean(el);
          }
          SVG_TAGS.has(c.nodeName) ? clean(c) : c.remove();
        }
        // style="fill:#000;stroke-width:1.5" → attributs (le style lui-même n'est pas gardé)
        for (const d of String(el.getAttribute("style") || "").split(";")) {
          const [k, ...v] = d.split(":");
          const n = String(k || "").trim().toLowerCase();
          if (SVG_ATTRS.has(n) && !el.hasAttribute(n)) el.setAttribute(n, v.join(":").trim());
        }
        for (const a of [...el.attributes]) {
          const n = a.name.toLowerCase(), v = a.value;
          if (!SVG_ATTRS.has(n) || /url\(|javascript:|[<>]/i.test(v)) el.removeAttribute(a.name);
          else if ((n === "fill" || n === "stroke") && !/^(none|currentcolor)$/i.test(v)) el.setAttribute(n, "currentColor");
        }
      };
      clean(root);
      for (const n of [...root.childNodes]) if (n.nodeType === 3) n.remove();
      if (!root.hasAttribute("fill")) root.setAttribute("fill", "currentColor"); // noir par défaut → couleur du lien
      if (!root.getAttribute("viewBox")) root.setAttribute("viewBox", `0 0 ${parseFloat(root.getAttribute("width")) || 24} ${parseFloat(root.getAttribute("height")) || 24}`);
      root.removeAttribute("width");
      root.removeAttribute("height");
      root.setAttribute("class", "nico");
      root.setAttribute("aria-hidden", "true");
      out = new XMLSerializer().serializeToString(root);
    }
  } catch (e) {
    out = "";
  }
  svgCache.set(src, out);
  return out;
}
// icoPreview — Aperçu de l'icône dans la configuration du menu (« ? » rouge : code non reconnu).
const icoPreview = (v) => safeSvg(v) || (v ? '<span style="color:var(--rouge)" title="Code SVG non reconnu">?</span>' : "");
function renderNav() {
  const nav = $("#pnav"),
    n = S.nav || { items: [] };
  if (!n.items.length || (!n.url && !n.inWidget)) {
    nav.replaceChildren();
    $("#navbtns").replaceChildren();
    return;
  }
  // condition explicite : la page n'apparaît que si l'utilisateur voit au moins une ligne de la table choisie
  // (couvre les règles d'accès par ligne, qui laissent la table visible mais vide)
  const need = [...new Set(n.items.map((x) => x.needTable).filter((t) => t && !(t in S.navAccess)))];
  if (need.length) {
    for (const t of need) S.navAccess[t] = false;
    Promise.all(
      need.map((t) =>
        grist.docApi
          .fetchTable(t)
          .then((d) => {
            S.navAccess[t] = (d.id || []).length > 0;
          })
          .catch(() => {
            S.navAccess[t] = false;
          }),
      ),
    ).then(() => renderNav());
  }
  const DEF_ICO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3h9l3 3v12H8zM4 7v14h12" /></svg>'; // icône par défaut d'un bouton
  const bar = []; // liens « bouton de la barre d'outils » (0.9.6.7) : mêmes règles de visibilité que le menu
  const links = n.items
    .map((x) =>
      x.viewId && S.meta?.pageOfView.has(x.viewId) ? x : { ...x, viewId: hostView(x.cfg) || x.viewId, host: true },
    )
    .filter((x) => {
      const page = !!x.viewId && !!S.meta?.pageOfView.has(x.viewId); // la page Grist existe encore
      if (!page && !(n.inWidget && x.cfg)) return false; // ni page, ni configuration à afficher dans le widget
      if (x.needTable && !S.navAccess[x.needTable]) return false;
      return page && !x.host ? viewReadable(x.viewId) : cfgReadable(x.cfg); // « ce widget » : droits de sa config
    })
    .map((x) => {
      const page = !!x.viewId && !!S.meta?.pageOfView.has(x.viewId);
      const url = page && safeBase(n.url) ? pageUrl(safeBase(n.url), x.viewId, n.singlePage && !n.inWidget) : ""; // lien Grist (clic du milieu)
      // infobulle : celle saisie dans la configuration, sinon l'adresse (sauf navigation dans le widget)
      const tip = String(x.tip || "").trim() || (n.inWidget ? "" : url);
      const lab = esc(x.label || (page ? S.meta.pageOfView.get(x.viewId) : x.cfg) || "Page");
      if (x.inBar) {
        bar.push(`<a class="tb navbtn${x.cfg && x.cfg === S.cfg.name ? " cur" : ""}" href="${url ? esc(url) : "#"}" target="_top" role="menuitem"${n.inWidget && x.cfg ? ` data-gocfg="${esc(x.cfg)}"` : ""} data-tip="${tip ? esc(tip) : lab}" aria-label="${lab}">${safeSvg(x.icon) || DEF_ICO}<span class="lbl">${lab}</span></a>`);
        return "";
      }
      return `<a href="${url ? esc(url) : "#"}"${tip ? ` title="${esc(tip)}"` : ""} target="_top"${n.inWidget && x.cfg ? ` data-gocfg="${esc(x.cfg)}"` : ""} class="${x.cfg && x.cfg === S.cfg.name ? "cur" : ""}">${safeSvg(x.icon)}<span class="nlab">${esc(x.label || (page ? S.meta.pageOfView.get(x.viewId) : x.cfg) || "Page")}</span></a>`;
    })
    .filter(Boolean);
  $("#navbtns").innerHTML = bar.join("");
  if (!links.length) {
    nav.replaceChildren();
    return;
  }
  // sur smartphone, les pages sont regroupées derrière un bouton (à gauche, icône de pages et nom de la page
  // courante) — distinct du menu ☰ des actions, à droite
  const cur = /<span class="nlab">([^<]*)<\/span><\/a>$/.exec(links.find((l) => l.includes('class="cur"')) || "")?.[1];
  nav.innerHTML = `<button type="button" class="pnav-tog" aria-expanded="false" aria-controls="pnavList" title="Changer de page"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3h9l3 3v12H8zM4 7v14h12" /></svg><span>${cur || "Pages"}</span><span class="qf-caret">▾</span></button><span class="pnav-list" id="pnavList">${links.join("")}</span>`;
}
// hostView — Page Grist qui contient ce widget, pour un lien « — ce widget — » : de préférence celle dont le
//   widget affiche la configuration du lien, sinon la première page où le widget est installé. Elle sert au lien
//   réel (clic du milieu, nouvel onglet, mode page unique) ; le clic normal change de page dans le widget.
function hostView(cfgName) {
  const m = S.meta;
  if (!m) return 0;
  const here = (location.host + location.pathname).replace(/\/index\.html$/, "/").replace(/\/+$/, "");
  let first = 0;
  for (const sec of m.sections.values()) {
    const cv = parseJSON(parseJSON(sec.options).customView, null);
    const url = String(cv?.url || "")
      .replace(/^https?:\/\//, "")
      .replace(/[?#].*$/, "")
      .replace(/\/index\.html$/, "/")
      .replace(/\/+$/, "");
    if (!url || url !== here || !m.pageOfView.has(sec.parentId)) continue;
    const name = parseJSON(cv.widgetOptions, {})?.config?.name;
    if (cfgName && name === cfgName) return sec.parentId;
    first ||= sec.parentId;
  }
  return first;
}
// renderNativeLinks — Pied de page réservé aux administrateurs (0.9.5.10) : liens vers les pages natives de Grist
//   qui contiennent les vues affichées (une entrée par page, ses vues en infobulle). Adresse : celle du menu,
//   sinon celle du document déduite du jeton d'accès. Ouvre la page Grist à la place du widget (clic du milieu :
//   nouvel onglet).
function renderNativeLinks(blocks) {
  const el = $("#nativeLinks");
  if (!el) return;
  const base = safeBase(S.nav?.url) || safeBase(S.docUrl);
  const m = S.meta;
  if (!S.isAdmin || !base || !m) {
    el.hidden = true;
    return;
  }
  const byPage = new Map();
  for (const b of blocks) {
    const sec = m.sections.get(b.id);
    if (!sec || !m.pageOfView.has(sec.parentId)) continue; // vue hors des pages (données brutes, fiche)
    if (!byPage.has(sec.parentId)) byPage.set(sec.parentId, []);
    byPage.get(sec.parentId).push(getInfo(b.id)?.title || `#${b.id}`);
  }
  el.hidden = !byPage.size;
  el.innerHTML = byPage.size
    ? `<span class="nl-h" title="Réservé aux administrateurs : pages Grist qui contiennent les vues de cette page">Vues natives :</span> ` +
      [...byPage]
        .map(
          ([vid, titles]) =>
            `<a href="${esc(pageUrl(base, vid))}" target="_top" title="${esc(`Vues : ${titles.join(" ; ")}`)}">${esc(m.pageOfView.get(vid))}</a>`,
        )
        .join(" · ")
    : "";
}
// pnavToggle — Ouvre / ferme la liste des pages (smartphone).
function pnavToggle(open = !$("#pnav").classList.contains("open")) {
  $("#pnav").classList.toggle("open", open);
  $("#pnav .pnav-tog")?.setAttribute("aria-expanded", String(open));
}
document.addEventListener("mousedown", (e) => {
  if ($("#pnav").classList.contains("open") && !e.target.closest("#pnav")) pnavToggle(false);
});
// readStoredConfigs — Lit toutes les configurations enregistrées dans W_Composition.
async function readStoredConfigs() {
  try {
    const tables = await grist.docApi.listTables();
    if (!tables.includes(CFG_TABLE)) return [];
    return toRows(await grist.docApi.fetchTable(CFG_TABLE))
      .map((r) => ({ id: r.id, name: String(r.Nom || ""), cfg: parseJSON(r.Config, null) }))
      .filter((x) => x.cfg && Array.isArray(x.cfg.blocks));
  } catch {
    return [];
  }
}
// saveConfigToTable — Enregistre (crée ou met à jour) une configuration dans W_Composition.
async function saveConfigToTable(cfg) {
  const tables = await grist.docApi.listTables();
  if (!tables.includes(CFG_TABLE)) {
    await docActions([
      [
        "AddTable",
        CFG_TABLE,
        [
          { id: "Nom", type: "Text" },
          { id: "Config", type: "Text" },
        ],
      ],
    ]);
  }
  if (S.adminHint && !tables.includes(ADMIN_TABLE)) {
    // installation : la table des administrateurs est créée avec une ligne (à protéger par une règle d'accès)
    try {
      await docActions([
        ["AddTable", ADMIN_TABLE, [{ id: "Note", type: "Text" }]],
        ["AddRecord", ADMIN_TABLE, null, { Note: "Qui lit cette ligne peut configurer le widget : réserver la lecture aux administrateurs (règle d'accès)." }],
      ]);
      S.adminHint = false;
    } catch {
      /* droits insuffisants pour créer une table */
    }
  }
  const rows = toRows(await grist.docApi.fetchTable(CFG_TABLE));
  const hit = rows.find((r) => String(r.Nom || "") === cfg.name);
  const json = JSON.stringify(cfg, null, 1);
  await docActions([
    hit
      ? ["UpdateRecord", CFG_TABLE, hit.id, { Config: json }]
      : ["AddRecord", CFG_TABLE, null, { Nom: cfg.name, Config: json }],
  ]);
  S.stored = await readStoredConfigs();
}

// showConfigChooser — Plusieurs configurations possibles : propose de choisir celle de cette page.
function showConfigChooser(list) {
  S.choosing = true;
  $("#grid").replaceChildren();
  $("#filters").replaceChildren();
  const st = $("#status");
  st.className = "";
  st.innerHTML =
    `Quelle configuration afficher sur cette page ? ` +
    list
      .map((x) => `<button class="btn" data-pick="${x.id}" style="margin:2px 4px">${esc(x.name)}</button>`)
      .join("");
  st.querySelectorAll("[data-pick]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const x = list.find((y) => y.id === Number(btn.dataset.pick));
      S.cfg = { ...DEFAULTS, ...x.cfg, name: x.name, dataTable: S.ext.tableId };
      S.choosing = false;
      if (S.isAdmin && !S.nav?.home) {
        // le choix devient la page par défaut pour tous (plus de question au prochain chargement)
        S.nav = { ...(S.nav || { url: "", items: [] }), home: x.name };
        try {
          await saveConfigToTable({ name: NAV_NAME, nav: S.nav });
        } catch {
          /* droits insuffisants */
        }
      }
      status("");
      try {
        await grist.setOption("config", S.cfg);
      } catch {
        /* facultatif */
      }
      if (S.isAdmin) {
        try {
          await saveConfigToTable(S.cfg);
        } catch {
          /* droits insuffisants */
        }
      } // mémorise la table du widget
      await render();
    }),
  );
}
// init — Démarrage : métadonnées, configurations enregistrées, menu, droits, puis premier rendu.
/* ---------- Écran de chargement (0.9.5.9) ----------
   #splash (index.html) s'affiche à l'ouverture du widget et à chaque rechargement par Grist, seulement si le
   chargement dépasse 0,4 s (délai CSS) ; une fois visible, il le reste au moins 0,8 s. Il montre l'image, le titre et
   le texte réglés dans la configuration (nav.splash), l'étape en cours et une barre de progression. Le réglage
   arrive avec les données ; une copie gardée dans le navigateur (localStorage, par document) l'affiche dès le
   début aux ouvertures suivantes. Retiré à la fin du premier rendu, en cas d'erreur, ou au bout de 60 s. */
const SPL = { t0: performance.now(), on: true };
const SPLASH_MAX = 300 * 1024; // taille maximale de l'image (le réglage est relu à chaque ouverture)
const splashKey = () => `uxwg_splash_${S.docKey || "doc"}`;
const splashOk = (sp) => !!sp && typeof sp === "object";
// splashFill — Image, titre et texte de l'écran de chargement (el : #splash, ou l'aperçu de la configuration).
function splashFill(sp, el = $("#splash")) {
  if (!el || !splashOk(sp)) return;
  const img = el.querySelector(".spl-img"),
    h = el.querySelector(".spl-title"),
    p = el.querySelector(".spl-text");
  const okImg = typeof sp.img === "string" && /^data:image\/(gif|png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(sp.img);
  img.hidden = !okImg;
  if (okImg) img.src = sp.img;
  h.textContent = sp.title || "";
  h.hidden = !sp.title;
  p.textContent = sp.text || "";
  p.hidden = !sp.text;
}
// splashStep — Étape en cours et progression (0 à 1).
function splashStep(label, frac) {
  if (!SPL.on) return;
  const el = $("#splash");
  if (!el) return;
  el.querySelector(".spl-step").textContent = label;
  if (frac != null) el.querySelector(".spl-bar i").style.width = `${Math.round(Math.min(1, Math.max(0, frac)) * 100)}%`;
}
// splashHide — Retire l'écran : aussitôt s'il n'a pas encore paru, sinon après 0,8 s d'affichage au moins, en fondu.
function splashHide() {
  if (!SPL.on) return;
  SPL.on = false;
  const el = $("#splash");
  if (!el) return;
  const t = performance.now() - SPL.t0;
  if (t < 400) return el.remove();
  setTimeout(
    () => {
      el.classList.add("out");
      setTimeout(() => el.remove(), 350);
    },
    Math.max(0, 1200 - t),
  );
}
setTimeout(splashHide, 60000); // garde-fou : jamais bloqué sur l'écran de chargement
// splashPreview — Aperçu de l'écran de chargement depuis la configuration (3 s, ou clic pour fermer).
function splashPreview(sp) {
  const el = document.createElement("div");
  el.className = "splash spl-preview";
  el.innerHTML = SPLASH_HTML;
  splashFill(sp, el);
  el.querySelector(".spl-step").textContent = "Aperçu : lecture des données : 7 / 12";
  el.querySelector(".spl-bar i").style.width = "62%";
  document.body.appendChild(el);
  const close = () => el.remove();
  el.addEventListener("click", close);
  setTimeout(close, 4000);
}
const SPLASH_HTML = `<div class="spl-card"><img class="spl-img" alt="" hidden /><h1 class="spl-title" hidden></h1><p class="spl-text" hidden></p><div class="spl-bar"><i></i></div><div class="spl-step">Chargement…</div></div>`;
async function init() {
  try {
    // identifiant du document (sélections partagées, écran de chargement gardé pour ce document) : demandé tout de suite
    const keyP = guessDocUrl().then((u) => {
      S.docKey = /\/doc\/([^/?#]+)/.exec(u)?.[1] || "";
      S.docUrl = u || ""; // adresse du document (liens vers les pages natives, pied de page des administrateurs)
      try {
        if (SPL.on) splashFill(JSON.parse(localStorage.getItem(splashKey()) || "null"));
      } catch {
        /* copie absente ou illisible */
      }
    });
    splashStep("Lecture de la structure du document…", 0.05);
    await loadMeta();
    splashStep("Lecture des pages et du menu…", 0.2);
    // La table W_Composition fait foi : elle survit aux changements de code du widget
    S.stored = await readStoredConfigs();
    S.nav = await readNav();
    splashFill(S.nav.splash);
    keyP.then(() => {
      try {
        if (splashOk(S.nav.splash)) localStorage.setItem(splashKey(), JSON.stringify(S.nav.splash));
        else localStorage.removeItem(splashKey());
      } catch {
        /* stockage plein ou indisponible : l'écran s'affichera sans image au début */
      }
    });
    splashStep("Vérification des droits…", 0.3);
    S.isAdmin = await checkAdmin();
    await keyP; // pour les sélections partagées
    applyTheme(S.nav.theme);
    // maintenance et accès fermé (0.9.6) : table W_Messages, lisible par tous
    const gate = await readMessages();
    if (gate?.maint && !S.isAdmin) return showGate("maint", gate);
    if (!S.isAdmin && noReadablePage(gate)) return showGate("noaccess", gate);
    setMaintBanner(gate?.maint && S.isAdmin ? gate : null);
    $("#btnConfig").hidden = !S.isAdmin;
    $("#btnSingle").hidden = false; // plein écran : ouvert à tous depuis 0.9.6.6
    try {
      S.ext.tableId = await grist.selectedTable.getTableId();
    } catch {
      S.ext.tableId = null;
    }
    const opt = S.optCfg || {};
    let hit = opt.name ? S.stored.find((x) => x.name === opt.name) : null;
    // page d'accueil (réglée par l'administrateur, commune à tous) : elle s'impose en mode « changer de page
    // dans le widget », et sert de page par défaut quand le widget n'a pas de configuration enregistrée
    const home = S.nav.home && S.stored.find((x) => x.name === S.nav.home);
    if (home && cfgReadable(home.name) && (S.nav.inWidget || !hit)) hit = home;
    // pages changées dans le widget : après un redémarrage (rechargement par Grist, Ctrl+F5), la page où l'on était
    if (S.nav.inWidget) {
      let back = null;
      try {
        back = sessionStorage.getItem(pageKey());
      } catch {
        /* stockage indisponible */
      }
      const prev = back && S.stored.find((x) => x.name === back);
      if (prev && cfgReadable(prev.name)) hit = prev;
    }
    if (!hit && !opt.blocks?.length) {
      // options du widget absentes : on reconnaît la config par la table du widget
      const same = S.stored.filter((x) => x.cfg.dataTable && x.cfg.dataTable === S.ext.tableId);
      if (same.length === 1) hit = same[0];
      else if (S.stored.length === 1) hit = S.stored[0];
      else if (S.stored.length > 1) {
        // seul un administrateur choisit ; un utilisateur n'est jamais interrogé
        if (S.isAdmin) {
          S.ready = true;
          splashHide();
          return showConfigChooser(same.length ? same : S.stored);
        }
        hit = same[0] || S.stored.find((x) => cfgReadable(x.name)) || S.stored[0];
      }
    }
    if (hit) S.cfg = { ...DEFAULTS, ...hit.cfg, name: hit.name };
    S.ready = true;
    await render();
    splashHide();
    showWelcome(); // message d'accueil, s'il y en a un et s'il n'a pas été masqué
    const tot = S.fetchLog.reduce((x, [, ms]) => x + ms, 0);
    console.info(
      `[UX widget] premier chargement : ${S.fetchLog.length} lectures de tables, ${tot} ms cumulés — les plus longues : ` +
        [...S.fetchLog]
          .sort((x, y) => y[1] - x[1])
          .slice(0, 5)
          .map(([t, ms]) => `${t} ${ms} ms`)
          .join(", "),
    );
  } catch (e) {
    splashHide();
    status(e.message || String(e), true);
  }
}
// applyOptions — Reçoit les options du widget (grist.onOptions) une seule fois, puis lance init().
function applyOptions(o) {
  if (S.optsApplied) return; // ne réappliquer les options qu'une fois (onOptions refire à chaque setOption)
  S.optsApplied = true;
  S.optCfg = o?.config || null;
  S.cfg = { ...DEFAULTS, ...(o?.config || {}) };
  init();
}
grist.ready({ requiredAccess: "full", onEditOptions: () => openConfig() });
grist.onOptions((o) => applyOptions(o));
grist.onRecord((r) => {
  S.ext.rowId = r?.id || null;
  if (S.ready) scheduleRender();
});
grist.onRecords(() => {
  if (!S.ready) return;
  if (S.ext.tableId) {
    delete S.cache[S.ext.tableId];
  }
  scheduleRender();
});
setTimeout(() => applyOptions(null), 1500);
// Icône AIA de l'aide : retirée si le fichier aia.png est absent (remplace un attribut onerror, interdit par la CSP)
{
  const img = document.querySelector(".aia-mini");
  if (img) {
    if (img.complete && !img.naturalWidth) img.remove();
    else img.addEventListener("error", () => img.remove());
  }
}
